#!/usr/bin/env python3
"""
track.py — the camera as a second angle sensor. v1, 6 Sep 2026. Lives in the vault (wind-rig/video/), never in the play folder.

Sync — three ways, best first:
  · AUTOMATIC (firmware v3.1): the Mega's built-in LED is on whenever the motor is commanded on. 'autosync' reads the LED's
    brightness through the video (or motion in a region if the LED is not in frame), builds the motor schedule from the
    ledger + CSVs, cross-correlates, and prints the --sync string. No clock in frame needed.
  · the LCD on the Mega (firmware v3, optional): --sync "12.40=r021@123.45"  (video second 12.40 showed run 021 at LCD t=123.45)
  · the PC screen running play-kit/clock.py: --sync "12.40=18:02:00.221"  (video second 12.40 showed that wall time)
play.py stamps each run (observe.t0_epoch, observe.t0_ms), so any of these places every run's frames. The coarse sync is
then refined per run by correlating the camera angle with the pot signal (--no-refine to skip). A coloured marker on the arm tip, tracked relative to the pivot, gives angle vs time
from the camera — independent of the pot, the ground rail and the wiring.

  py -3 track.py autosync video.mp4 --ledger ledger.jsonl --csvdir ../sessions/session-2/play --led 512,80 [--roi x0,y0,x1,y1]
                                                                          # → prints e.g. --sync "0.00=19:12:41.350" and a confidence
  py -3 track.py frame  video.mp4 --t 12.4 --out f.png                    # dump one frame (to find the LED / pivot pixels)
  py -3 track.py sheet  video.mp4 --every 20 --out sheet.png              # contact sheet, one thumbnail every 20 s
  py -3 track.py probe  video.mp4 --t 12.4 --xy 512,380                   # HSV of a pixel (pick the marker colour)
  py -3 track.py track  video.mp4 --ledger ledger.jsonl --runs 021,022 --sync "12.40=18:02:00.221" [--sync2 "3600.0=19:02:00.9"]
                        --pivot 640,120 --hsv 35,80,80,85,255,255 --csvdir ../sessions/session-2 --out out/
      → out/run_021_cam.csv (t, angle_deg, px, py), out/run_021_compare.png (camera angle vs pot), and a fit pot = a + b·angle
        with residual RMS per run. Angle is 0 hanging straight down, positive when the marker is to the right in the image.

Requires: opencv-python (cv2), numpy; matplotlib for the plots. ffmpeg is not needed.
"""
import argparse, csv, json, math, os, sys
from datetime import datetime
import numpy as np
try:
    import cv2
except ImportError:
    sys.exit("pip install opencv-python-headless numpy")


# ----------------------------------------------------------------------------------------------- video helpers
def open_video(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened(): sys.exit(f"cannot open {path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0; n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    return cap, fps, n

def frame_at(cap, fps, t):
    cap.set(cv2.CAP_PROP_POS_FRAMES, int(round(t * fps)))
    ok, img = cap.read()
    return img if ok else None

def do_frame(a):
    cap, fps, n = open_video(a.video); img = frame_at(cap, fps, a.t)
    if img is None: sys.exit("no frame there")
    cv2.imwrite(a.out, img); print(f"wrote {a.out} (frame {int(round(a.t * fps))} of {n}, {fps:.2f} fps)")

def do_sheet(a):
    cap, fps, n = open_video(a.video); dur = n / fps
    times = list(np.arange(0, dur, a.every))[:a.max]
    tiles = []
    for t in times:
        img = frame_at(cap, fps, t)
        if img is None: continue
        th = cv2.resize(img, (320, int(320 * img.shape[0] / img.shape[1])))
        cv2.putText(th, f"{t:7.1f}s", (6, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
        tiles.append(th)
    if not tiles: sys.exit("no frames")
    cols = 4; h, w = tiles[0].shape[:2]
    rows_ = [np.hstack(tiles[i:i + cols] + [np.zeros_like(tiles[0])] * (cols - len(tiles[i:i + cols]))) for i in range(0, len(tiles), cols)]
    cv2.imwrite(a.out, np.vstack(rows_)); print(f"wrote {a.out}: {len(tiles)} thumbnails, video {dur:.0f} s at {fps:.2f} fps")

def do_probe(a):
    cap, fps, n = open_video(a.video); img = frame_at(cap, fps, a.t)
    x, y = [int(v) for v in a.xy.split(",")]
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    patch = hsv[max(0, y - 3):y + 4, max(0, x - 3):x + 4].reshape(-1, 3)
    lo, hi, med = patch.min(0), patch.max(0), np.median(patch, 0)
    print(f"HSV at ({x},{y}) ±3 px: median {med.astype(int).tolist()}  min {lo.tolist()}  max {hi.tolist()}")
    print(f"suggested --hsv {max(0, int(med[0]) - 12)},{max(0, int(med[1]) - 70)},{max(0, int(med[2]) - 70)},{min(179, int(med[0]) + 12)},255,255")


# ----------------------------------------------------------------------------------------------- sync
def parse_sync(s, starts, t0ms, day):
    """'12.40=18:02:00.221' (PC clock) or '12.40=r021@123.45' (Mega LCD) → (video_s, epoch)."""
    v, clk = s.split("=", 1); v = float(v); clk = clk.strip()
    if clk.startswith("r") and "@" in clk:
        rid, lt = clk[1:].split("@"); rid = f"{int(rid):03d}"
        if rid not in starts or rid not in t0ms: sys.exit(f"sync run {rid} not in ledger (needs play.py v7 t0_ms)")
        return v, starts[rid] + (float(lt) - t0ms[rid] / 1000.0)
    return v, clock_to_epoch(clk, day)

def clock_to_epoch(clk, day):
    hh, mm, ss = clk.split(":"); sec = float(ss)
    dt = datetime(day.year, day.month, day.day, int(hh), int(mm), int(sec), int(round((sec - int(sec)) * 1e6)))
    return dt.timestamp()

class Sync:
    """video seconds ↔ epoch seconds, linear (one point = offset only; two points = offset + drift)."""
    def __init__(self, points):
        (v1, e1) = points[0]
        if len(points) > 1:
            (v2, e2) = points[1]; self.k = (e2 - e1) / (v2 - v1)
        else:
            self.k = 1.0
        self.v1, self.e1 = v1, e1
    def video_of(self, epoch): return self.v1 + (epoch - self.e1) / self.k
    def epoch_of(self, video): return self.e1 + (video - self.v1) * self.k


# ----------------------------------------------------------------------------------------------- autosync
def schedule_signal(ledger, csvdir, hz=10.0):
    """Motor-on (x > 0) over epoch time, from the ledger's run starts and the per-run CSVs. Returns (t_epoch_grid, on)."""
    recs = [json.loads(l) for l in open(ledger, encoding="utf-8") if l.strip()]
    starts = {r["id"]: r["t0_epoch"] for r in recs if r["kind"] == "observe" and r.get("t0_epoch")}
    if not starts: sys.exit("ledger has no t0_epoch")
    spans = []
    for rid, t0 in starts.items():
        p = os.path.join(csvdir, f"{rid}.csv")
        if not os.path.exists(p): continue
        with open(p, encoding="utf-8") as f:
            rd = csv.reader(f); next(rd)
            rows = [(float(r[0]), int(r[1])) for r in rd]
        on = False; t_on = None
        for t, x in rows:
            if x > 0 and not on: on, t_on = True, t
            elif x == 0 and on: spans.append((t0 + t_on, t0 + t)); on = False
        if on: spans.append((t0 + t_on, t0 + rows[-1][0]))
    if not spans: sys.exit("no motor-on spans found in the CSVs")
    lo = min(s[0] for s in spans) - 120; hi = max(s[1] for s in spans) + 120
    grid = np.arange(lo, hi, 1.0 / hz); sig = np.zeros_like(grid)
    for a, b in spans: sig[(grid >= a) & (grid <= b)] = 1.0
    return grid, sig, spans

def video_signal(path, led=None, roi=None, hz=10.0):
    """LED brightness at a pixel (7x7 patch, V channel) or motion energy in a region, sampled at ~hz. Returns (t_video, sig)."""
    cap, fps, n = open_video(path); step = max(1, int(round(fps / hz)))
    ts, vals, prev = [], [], None
    for fi in range(0, n, step):
        cap.set(cv2.CAP_PROP_POS_FRAMES, fi); ok, img = cap.read()
        if not ok: break
        if led:
            x, y = led; patch = img[max(0, y - 3):y + 4, max(0, x - 3):x + 4]
            vals.append(float(cv2.cvtColor(patch, cv2.COLOR_BGR2HSV)[:, :, 2].mean()))
        else:
            g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            if roi: x0, y0, x1, y1 = roi; g = g[y0:y1, x0:x1]
            g = cv2.resize(g, (160, int(160 * g.shape[0] / g.shape[1]) or 1)).astype(np.float32)
            vals.append(float(np.abs(g - prev).mean()) if prev is not None else 0.0); prev = g
        ts.append(fi / fps)
    return np.array(ts), np.array(vals), fps

def do_autosync(a):
    grid, sched, spans = schedule_signal(a.ledger, a.csvdir)
    led = [int(v) for v in a.led.split(",")] if a.led else None
    roi = [int(v) for v in a.roi.split(",")] if a.roi else None
    tv, sv, fps = video_signal(a.video, led, roi)
    print(f"schedule: {len(spans)} motor-on spans over {grid[-1] - grid[0]:.0f} s | video: {tv[-1]:.0f} s sampled at 10 Hz")
    # z-score both, FFT cross-correlation on a common 10 Hz grid
    A = (sched - sched.mean()) / (sched.std() + 1e-9); B = (sv - sv.mean()) / (sv.std() + 1e-9)
    n = 1 << int(np.ceil(np.log2(len(A) + len(B)))); fa = np.fft.rfft(A, n); fb = np.fft.rfft(B, n)
    xc = np.fft.irfft(fa * np.conj(fb), n)              # xc[k] ~ sum A[i+k] B[i]  → schedule lags video by k samples
    lags = np.arange(n); lags[lags > n // 2] -= n
    k = int(np.argmax(xc)); peak = xc[k]
    order = np.argsort(xc)[::-1]; second = next((xc[j] for j in order if abs(lags[j] - lags[k]) > 50), 0.0)
    offset = grid[0] + lags[k] * 0.1 - tv[0]           # epoch = video_s + offset
    # refine around the peak at frame resolution
    best = (offset, -1.0)
    for d in np.arange(-0.3, 0.3001, 1.0 / fps):
        e = tv + offset + d; m = (e >= grid[0]) & (e <= grid[-1])
        if m.sum() < 50: continue
        c = float(np.corrcoef(np.interp(e[m], grid, sched), sv[m])[0, 1])
        if c > best[1]: best = (offset + d, c)
    offset, c = best
    ratio = peak / second if second > 0 else float("inf")
    clk = datetime.fromtimestamp(offset).strftime("%H:%M:%S.%f")[:-3]
    print(f"offset: video 0.00 s = epoch {offset:.3f} ({clk}) | corr at best {c:.2f} | peak/second-peak {ratio:.1f}")
    print("confidence: " + ("good" if c > 0.5 and ratio > 1.5 else "weak — check the LED pixel / region, or give --sync by hand"))
    print(f'use:  --sync "0.00={clk}"')


# ----------------------------------------------------------------------------------------------- tracking
def marker_centroid(img, hsv_lo, hsv_hi, roi=None):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, np.array(hsv_lo), np.array(hsv_hi))
    if roi:
        x0, y0, x1, y1 = roi; m2 = np.zeros_like(mask); m2[y0:y1, x0:x1] = mask[y0:y1, x0:x1]; mask = m2
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, labels, stats, cents = cv2.connectedComponentsWithStats(mask)
    if n <= 1: return None
    k = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    if stats[k, cv2.CC_STAT_AREA] < 6: return None
    return float(cents[k][0]), float(cents[k][1])

def do_track(a):
    cap, fps, n = open_video(a.video)
    recs = [json.loads(l) for l in open(a.ledger, encoding="utf-8") if l.strip()]
    starts = {r["id"]: r["t0_epoch"] for r in recs if r["kind"] == "observe" and r.get("t0_epoch")}
    t0ms = {r["id"]: r["t0_ms"] for r in recs if r["kind"] == "observe" and r.get("t0_ms") is not None}
    fors = {r["id"]: r["for_s"] for r in recs if r["kind"] == "predict"}
    if not starts: sys.exit("ledger has no t0_epoch (play.py v6+ writes it)")
    day = datetime.fromtimestamp(next(iter(starts.values())))
    pts = [parse_sync(a.sync, starts, t0ms, day)] + ([parse_sync(a.sync2, starts, t0ms, day)] if a.sync2 else [])
    sync = Sync(pts)
    px, py = [float(v) for v in a.pivot.split(",")]
    hsv = [int(v) for v in a.hsv.split(",")]; lo, hi = hsv[:3], hsv[3:]
    roi = [int(v) for v in a.roi.split(",")] if a.roi else None
    os.makedirs(a.out, exist_ok=True)
    runs = a.runs.split(",") if a.runs else sorted(starts)
    for rid in runs:
        rid = f"{int(rid):03d}"
        if rid not in starts: print(f"{rid}: no start time in ledger"); continue
        t0, dur = starts[rid], fors.get(rid, 10.0)
        v0 = sync.video_of(t0); f0, f1 = int(v0 * fps), int((v0 + dur) * fps) + 1
        cap.set(cv2.CAP_PROP_POS_FRAMES, max(0, f0))
        out = []
        for fi in range(max(0, f0), f1):
            ok, img = cap.read()
            if not ok: break
            c = marker_centroid(img, lo, hi, roi)
            t_run = sync.epoch_of(fi / fps) - t0
            if c is None: out.append((round(t_run, 3), None, None, None)); continue
            ang = math.degrees(math.atan2(c[0] - px, c[1] - py))   # 0 = straight down (image y grows downward)
            out.append((round(t_run, 3), round(ang, 2), round(c[0], 1), round(c[1], 1)))
        cam_csv = os.path.join(a.out, f"run_{rid}_cam.csv")
        with open(cam_csv, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f); w.writerow(["t", "angle_deg", "px", "py"]); w.writerows(out)
        found = [o for o in out if o[1] is not None]
        print(f"run {rid}: frames {f0}-{f1} (video {v0:.1f} s), marker found in {len(found)}/{len(out)} frames -> {cam_csv}")
        pot_csv = os.path.join(a.csvdir, f"{rid}.csv") if a.csvdir else None
        if pot_csv and os.path.exists(pot_csv) and len(found) > 10:
            compare(rid, found, pot_csv, os.path.join(a.out, f"run_{rid}_compare.png"), refine=not a.no_refine)

def refine_shift(ct, ca, pt, py_, window=0.4, step=0.005):
    """Shift the camera times by s to best align with the pot. The SIGN of the relation (pot counts may grow or shrink
    with angle) is taken from the coarse sync at shift 0; then the signed correlation is maximised over +/-window, which
    must stay below half a period so a periodic signal cannot lock onto the neighbouring cycle. Returns (shift, corr)."""
    if py_.std() < 5 or ca.std() < 0.5: return 0.0, 0.0
    def corr_at(sft):
        tt = ct + sft; m = (tt >= pt.min()) & (tt <= pt.max())
        if m.sum() < 20: return None
        return float(np.corrcoef(np.interp(tt[m], pt, py_), ca[m])[0, 1])
    c0 = corr_at(0.0)
    if c0 is None or abs(c0) < 0.2: return 0.0, (c0 or 0.0)
    sign = 1.0 if c0 > 0 else -1.0
    best = (0.0, c0)
    for sft in np.arange(-window, window + 1e-9, step):
        c = corr_at(float(sft))
        if c is not None and sign * c > sign * best[1]: best = (float(sft), c)
    return best

def compare(rid, cam, pot_csv, png, refine=True):
    with open(pot_csv, encoding="utf-8") as f:
        rd = csv.reader(f); next(rd); pot = [(float(r[0]), int(r[3])) for r in rd]
    pt = np.array([p[0] for p in pot]); py_ = np.array([p[1] for p in pot])
    ct = np.array([c[0] for c in cam]); ca = np.array([c[1] for c in cam])
    if refine:
        sft, corr = refine_shift(ct, ca, pt, py_)
        if abs(corr) >= 0.5:
            ct = ct + sft; print(f"  {rid}: sync refined by {sft:+.3f} s (|corr| {abs(corr):.2f})")
        else:
            print(f"  {rid}: no refinement (|corr| {abs(corr):.2f} — pot and camera do not agree enough to align; coarse sync kept)")
    m = (ct >= pt.min()) & (ct <= pt.max())
    if m.sum() < 10: print(f"  {rid}: no overlap between camera and pot times"); return
    pot_at_cam = np.interp(ct[m], pt, py_)
    A = np.vstack([np.ones(m.sum()), ca[m]]).T
    (a0, b), *_ = np.linalg.lstsq(A, pot_at_cam, rcond=None)
    resid = pot_at_cam - (a0 + b * ca[m])
    print(f"  {rid}: pot ≈ {a0:.1f} + {b:.2f}·angle   (counts per degree {b:.2f})   residual RMS {resid.std():.1f} counts, "
          f"max |resid| {np.abs(resid).max():.0f}   camera angle range {ca[m].min():.1f}..{ca[m].max():.1f} deg")
    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
        fig, ax = plt.subplots(2, 1, figsize=(10, 6), sharex=True)
        ax[0].plot(pt, py_, lw=0.8, label="pot (counts)"); ax[0].plot(ct[m], a0 + b * ca[m], lw=0.8, label="camera, mapped to counts")
        ax[0].legend(); ax[0].set_ylabel("y"); ax[0].set_title(f"run {rid}: pot vs camera")
        ax[1].plot(ct[m], resid, lw=0.8); ax[1].set_ylabel("pot − camera (counts)"); ax[1].set_xlabel("t (s)")
        fig.tight_layout(); fig.savefig(png, dpi=110); plt.close(fig); print(f"  wrote {png}")
    except Exception as e:
        print(f"  (no plot: {e})")


# ----------------------------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("autosync"); p.add_argument("video"); p.add_argument("--ledger", required=True); p.add_argument("--csvdir", required=True)
    p.add_argument("--led", default=""); p.add_argument("--roi", default=""); p.set_defaults(fn=do_autosync)
    p = sub.add_parser("frame"); p.add_argument("video"); p.add_argument("--t", type=float, required=True); p.add_argument("--out", default="frame.png"); p.set_defaults(fn=do_frame)
    p = sub.add_parser("sheet"); p.add_argument("video"); p.add_argument("--every", type=float, default=20.0); p.add_argument("--max", type=int, default=48); p.add_argument("--out", default="sheet.png"); p.set_defaults(fn=do_sheet)
    p = sub.add_parser("probe"); p.add_argument("video"); p.add_argument("--t", type=float, required=True); p.add_argument("--xy", required=True); p.set_defaults(fn=do_probe)
    p = sub.add_parser("track"); p.add_argument("video"); p.add_argument("--ledger", required=True); p.add_argument("--runs", default="")
    p.add_argument("--sync", required=True); p.add_argument("--sync2"); p.add_argument("--pivot", required=True)
    p.add_argument("--hsv", default="35,80,80,85,255,255"); p.add_argument("--roi", default=""); p.add_argument("--csvdir", default=""); p.add_argument("--out", default="out")
    p.add_argument("--no-refine", action="store_true")
    p.set_defaults(fn=do_track)
    a = ap.parse_args(); a.fn(a)

if __name__ == "__main__":
    main()
