# wind-rig — starter kit (3 Sep 2026)

Source of truth for the wind pendulum's code, kept in the vault the way the site lives in `Career/`. Build and run it from
Claude Code on the PC (it needs the USB port), in its own project folder — copy this folder to `<your folder>`
and open that as the Code project. The experiment itself: [[Experiment — The Wind Pendulum (self-play physics on the Elegoo kit, 3 Sep 2026)]].

| file | what |
|---|---|
| `wind_rig.ino` | Mega firmware **v4**: **angle from the kit's MPU-6050 on the arm** (I2C on 20/21; gyro + accelerometer fused; y = 512 + 3.41·deg, the pot's old scale) after the pot's wiper failed in both sessions and its friction stopped the arm swinging — `ANGLE_SOURCE 0` restores the pot on A0; L293D on 7/8/9; 50 Hz `t_ms,pwm,dir,adc`; `u`/`d`/`s`/`k`/`?`/`n`; motor-off after 10 s of serial silence (v2); built-in LED on whenever the motor is commanded on — the camera's sync flag (v3.1); LCD clock behind `LCD_PRESENT 0` (scrapped). Keep the arm still for 2 s after reset (gyro bias). Re-upload after pulling this version |
| `log.py` | drives a protocol (`decay`, `steps`, `random`, `manual`) and logs to CSV + a `.meta.json`; sends `k` every 3 s; needs `pip install pyserial` |
| `fit.py` | numpy-only analysis: calibration, free-decay ω₀ and damping, steady-state thrust exponent, and model selection for θ'' by held-out prediction; `--simulate` is kill-test 0 |

## Order of operations

1. **Kill-test 0, before any hardware:** `py -3 fit.py --simulate`. It fakes 10 minutes of a 20 cm pendulum under random fan commands with 0.3° of sensor noise and asks the pipeline to recover the law. Expected: the square-law model wins on prediction, L within ~5 %, damping within ~15 %. If this fails, fix the pipeline, not the rig. (It passes as shipped.)
2. **Flash** `wind_rig.ino` with the Arduino IDE or `arduino-cli` (board: Arduino Mega or Mega 2560). Open Serial Monitor at 115200; you should see a header line and then four numbers a line, 50 a second. Type `?` to check.
3. **Calibrate.** Let the arm hang: note the adc. Hold it horizontal (90°): note the adc. `py -3 fit.py --calibrate <hanging> <ninety>` writes `calib.json`. Repeat if you rebuild the arm.
4. **Free decay:** `py -3 log.py --port COM3 --protocol decay --out runs/decay1.csv` then `py -3 fit.py --decay runs/decay1.csv`. Kill-test 1: the effective length from g/ω₀² matches the tape measure to the arm's centre of mass within 10 %.
5. **Steps:** `--protocol steps` then `fit.py --steps …`. Prints sinθ per level and the log-log exponent (2.0 = pure square law; a brushed motor under load will not be exactly 2 — report what it is).
6. **Random excitation (30 min):** `--protocol random --minutes 30` then `fit.py --random …`. Kill-test 2: the square-law candidates beat the linear one on held-out prediction. Kill-test 3: 5-second-window RMS of a few degrees.
7. Write the numbers into the experiment note. Then stage 2 (the rig chooses its own next command) is a change to `log.py` only.

## Track B — blind play (6 Sep 2026)

Albert's divergence: instead of the fixed protocol, let an LLM *play* with the rig — choose its own runs, predict each outcome with a number and a confidence before the run, score itself, and carry a chain of reasoning from run to run while it maps the edges. It plays **blind, on raw variables** (Albert's third call the same evening: "get rid of all the interface stuff, literally I want it to be looking at raw variables and effectively making mathematical models"): it knows only **x** (integer 0–255, it sets), **z** (0/1, it sets), **y** (integer 0–1023, it observes at 50 Hz) and **t**. No "actuator", "sensor", "direction", "box", "port" — not even the word "system" is explained. The deliverable is a model: y as a function of the history of x, z and y, with parameters, uncertainties and the domain where it holds; to fit one it may write numpy analysis scripts in `runs/play/analysis/` against the CSVs. The agent lives in its own sealed project folder, and nothing physics-shaped goes there.

| file | what |
|---|---|
| `play-kit/play.py` | the only way to touch the rig: `init`, `run` (prediction is written to disk *before* the rig is touched), `judge`, `update`, `stop`, `ledger` (hit rate vs stated confidence, Brier for claims, per-metric hit rate *and* mean interval width), `show`. Command language: `x v @t`, `z b @t`, `pulse`, `ramp`; CSVs are `t,x,z,y`. No metric names the sensor's ends (`clip` was tried and dropped — it hinted). **The program draws no edges** (Albert, 6 Sep: "I want it to find its own boundaries"): no abort band, no enforced rest, 300 s runs; the only floor is load — it *refuses to start* a run that would exceed 9 x-weighted minutes in the last 15, and says so. The hard guard was removed entirely — its band values were a hint in the help text. The COM port lives in `runs/play/config.json` (written by the bat, unreadable to the agent), so the agent never sees "COM3" or the word "port" |
| `play-kit/CLAUDE.md` | the rules of play: x, z, y, t and nothing else; the program is not the system; what a model is (equations, parameters with uncertainties, tested domain, residuals; prefer the model that predicts an undone run, then do it); the loop (why → predict → run → score → update); **when the system changes** (no faulty readings, only a changed system: declare a regime, keep model A, rebuild B from the opening probes, test whether A can be brought back; drift as coefficients that depend on t); the files it owns (`model.md`, `boundaries.md`, `session-N.md`); analysis scripts; calibration discipline; stop only by choice, at the ceiling, or when nothing responds to anything |
| `play-kit/claude-settings.json` | permissions for the play project: `py -3 play.py` and `py -3 runs/play/analysis/*` allowed; web, other python, `py -m`, reading `play.py`/`config.json`/`session.json`, and edits to the ledger/program denied |
| `play-kit/setup-play.bat` | builds `%USERPROFILE%\Projects\blackbox\` from the kit (copies play.py, clock.py, CLAUDE.md, `.claude\settings.json`; asks for the COM port and writes `config.json`; installs pyserial + numpy) |
| `sim_box.py` | a fake box for testing the harness without hardware — **never copied to the play project**; it contains the physics |

To start a session: run `play-kit\setup-play.bat`, open `<your folder>\blackbox` in Claude Code (Manual mode; "always allow" only `py -3 play.py`), and paste:

> Read CLAUDE.md and `py -3 play.py --help`. Start with `py -3 play.py init` (or continue the open session if it says so), then play: every run through the loop, files kept as the rules say, and stop by choice when you have learned what you can. Write `runs/play/session-N.md` when you stop.

For session 2 add one sentence: *"The system was serviced after run 020 and a regime was declared for you; runs 001–020 are the record of what it was."* Nothing about what was wrong.

One trade-off to know: the analysis-script allowance means a script under `runs/play/analysis/` runs without a permission prompt, and Python can in principle open the COM port or list devices. The rules forbid it and the transcript would show it; if that is not enough, move the two `runs/play/analysis` lines from `allow` to `ask` in `.claude\settings.json` and approve each script by hand.

**Pre-session checklist (from the 6 Sep adversarial review):**

1. **Firmware v3.1 on the board.** Open `wind_rig\wind_rig.ino` from this folder in the Arduino IDE and upload; the header line in the Serial Monitor should say v3.1, and the "L" LED should light with `u 255` and go out with `s`. Then close the Serial Monitor — the port must be free.
2. **Pot centred.** With the arm hanging, the reading should be roughly 450–580. If it isn't (it read 94 on 5 Sep), rotate the pot body in its mount until it is, then re-fix. Off-centre, one side of the swing hits the pot's electrical end within ~25° and the agent's first "boundary" is your mounting.
3. **Noise under power — in the Serial Monitor, not through play.py** (the ledger is the agent's; Albert's checks must not appear in it). Idle: the adc column should jitter by a few counts at most. Then `d 0` + `u 255`, and `d 1` + `u 255`: the motor must spin both ways, the reading should move and settle, and the jitter under power should stay under ~10–15 counts. If it doesn't, motor PWM is bleeding into the sensor: a 100 nF (marked 104) capacitor from the pot's wiper column to the blue rail, and a separate short ground jumper from Mega GND to the pot's bottom leg. Then `s` and close the monitor.
4. **After any repair, declare it to the ledger yourself** from the play folder: `py -3 play.py regime --why "Albert: serviced between sessions"`. The agent's files and the ledger stay — regime 2 starts from run 021, and the agent is told only that. Do not delete `runs\play\` between sessions any more; the first session's files are the record.
5. Clear the swing area, tape over the arm's blu-tack joint, pull the 9 V plug if you leave the room (it is the kill switch: motor dies, serial survives). Camera on a stand that nothing touches; the pivot must stay at the same pixel all session.

What can go wrong, in order of likelihood: the joint slips (the rest reading moves — the agent should notice), the arm slams the pot's end-stop (S pins; pots survive this), the L293D goes into thermal shutdown (it comes back), the motor cooks (the duty floor is there for this; $1 if it fails). A run killed by the shell tool's timeout leaves the motor on for at most 10 s (firmware v2) and is listed in the ledger as "predicted but never observed".

Program self-test (here, not in the play folder): `py -3 play-kit\play.py init --sim` then a few `run`s — the stand-in answers as the pendulum would: dead zone below x≈40, weaker z=1, a 0.9 s period, and pulsing at that period reaches the end-stops in seconds.

## The camera as a second angle sensor (Albert's idea, 6 Sep 2026)

*"Set up a camera that you can view and assess once the experiment is complete… display a clock for the camera, that way you can sync the time from the experiment to the time on the display clock in the video."* Then: *"can we do it so the Arduino is displaying the time on the LCD screen, just cause I can't get the computer time on the screen logistically."* Session 1 is the reason: the pot said ±80°, the arm never moved. A camera cannot share the rig's ground rail.

The LCD showed only a row of blocks and was scrapped the same evening. What replaced it is better and needs no wiring: **the Mega's built-in LED is on whenever the motor is commanded on**, so the camera carries the motor schedule in every frame, and `track.py autosync` finds the video↔ledger offset by cross-correlating the LED's brightness with the x schedule rebuilt from the ledger and the CSVs — then the per-run refinement against the pot brings it to the frame. Verified on a synthetic three-run session: offset recovered to 0.1 s, then 3.37–3.40 counts/deg against a true 3.41. (The LCD path and the PC-clock path remain in the code as manual alternatives.)

| piece | what |
|---|---|
| `wind_rig.ino` v3.1 | built-in LED = motor-on flag (the sync source); optional LCD behind `LCD_PRESENT`; `n <id>` command |
| `play.py` v9 | sends `n <id>` on every run and `n init` on init; records `t0_epoch` (PC clock, ms) and `t0_ms` (Mega clock) per run; `regime` command (the ledger scores each regime on its own and counts declarations); `--trace` whole-run predictions scored by RMS skill against "y stays where it started"; a lock so two runs cannot overlap |
| `play-kit/clock.py` | the PC-screen alternative (HH:MM:SS.mmm + live run/x/z/y from `runs/play/live.json`) for when a monitor *can* be in frame |
| `video/track.py` (vault only) | `autosync` (LED brightness or region motion vs the ledger's motor schedule → the `--sync` string and a confidence), `frame`, `sheet`, `probe` (marker colour), `track`: marker angle vs time per run, coarse sync (auto, LCD, or PC clock), then per-run sign-aware refinement by correlating camera angle with the pot signal, overlay, counts-per-degree fit, residuals, plot |

Camera setup: fixed and square-on to the swing plane, **the Mega's "L" LED and the arm both in frame** (the LED is next to the USB socket; it needs to be a visible bright dot, not hidden under wires), plain background behind the arm, green tape on the arm tip, 720p at 30 fps, one recording per session. Start recording before the first run and leave it running to the end. Save it as `Desk\wind-rig\sessions\session-N\video.mp4` — git ignores it — and copy `runs\play` beside it as before. Then tell Claude the session is done: Claude dumps a frame, reads the LCD, and runs `track.py` for every run — camera angle against pot y, fit and residuals. Agreement to a few counts means the pot is honest; a pot that moves while the camera does not is session 1 again, caught in one plot.

## Physics being tested

θ'' = −(g/L)·sin θ − c·θ' + k·u^p. The fan is on the arm, so its torque is angle-independent (no cos θ term — an earlier draft had one; that is the model for a fixed fan blowing across a hanging arm, which is a different rig). Steady state: sin θ = k·u^p·L/g, so the steps give p directly (sin, not tan — tan is the fixed-fan model; the two agree only at small angles). L cancels in the deflection itself — thrust torque T·L against gravity torque m·g·L·sin θ — so a longer arm swings no further; more motor voltage or a lighter tip does.

## Safety

The fan bites. Keep fingers clear; the `s` command and the 10-second serial watchdog both stop it, and pulling the 9 V plug from the Mega's jack stops it instantly. Motor power comes from the Mega's Vin (9 V adaptor in the jack) or the breadboard module, never the Mega's 5 V pin.

#pulse/warm %%2026-09-06%%
