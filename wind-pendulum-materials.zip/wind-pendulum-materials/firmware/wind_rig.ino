// wind_rig.ino — the wind pendulum's firmware (Elegoo Mega 2560). v4, 6 Sep 2026 (MPU-6050 angle sensor; pot retired).
//
// ANGLE SOURCE (v4): after two sessions in which the potentiometer's wiper broke contact under the running motor and its
// bearing friction stopped the arm swinging at all, the angle comes from the kit's MPU-6050 (GY-521) taped to the arm:
//     VCC → 5V   GND → GND   SDA → Mega 20   SCL → Mega 21     (four thin leads along the arm, slack at the pivot)
// Mount it with its X axis pointing ALONG the arm toward the tip and its Y axis in the plane of swing; Z then points
// along the pivot axle. Hanging straight down reads 0°; the accelerometer gives the angle from gravity, the gyro's Z rate
// gives the fast part, a complementary filter fuses them (tau ≈ 1 s), and y = 512 + 3.41·angle_deg — the same 0–1023
// scale the pot had (1023 counts per 300°), so nothing downstream changes. Gyro bias is measured for 2 s at boot: keep
// the arm still until the header line appears. Set ANGLE_SOURCE 0 to go back to the pot on A0.
//
// (Old note) Pot on A0. L293D: IN1=7, IN2=8, EN1=9 (PWM). Motor supply on the L293D's VS pin from the
// breadboard power module or the Mega's Vin pin (9 V adaptor in the Mega's jack — the setup that worked, 6 Sep),
// logic VSS from the Mega's 5 V, all grounds common. Never power the motor from the Mega's 5 V pin for real runs.
// Serial 115200. One line every 20 ms:  t_ms,pwm,dir,adc
// Commands (newline-terminated):  u <0-255> set duty · d <0|1> direction · s stop · k keepalive · ? status · n <id> run id for the LCD
// Safety: if no serial byte arrives for 10 s while the motor is on, the motor stops. log.py sends 'k' every 3 s,
// play.py every 2 s, so a logger killed mid-run (shell timeout, crash) leaves the motor on for at most 10 s.
//
// CAMERA SYNC (v3.1): the board's built-in LED (pin 13, marked "L" next to the USB socket) is ON whenever pwm > 0.
// A camera that can see the board and the arm then carries the motor schedule in every frame, and video/track.py
// 'autosync' matches the LED's on/off pattern against the ledger's x schedule to find the video↔ledger offset by itself.
// No wiring needed. The LCD below is optional (Albert scrapped it, 6 Sep: one row of blocks = not initialised; V0 or RS/E).
//
// LCD (v3, optional): a 16x2 LCD in the camera's frame shows the Mega's own clock — the same t_ms the CSV rows carry — plus the
// run id, pwm, dir and adc, refreshed every 100 ms:
//     r021 t= 123.45      (run id, seconds since the board reset = CSV t to within the first sample)
//     x255 z1  y 676      (pwm, dir, adc)
// Wiring, plain LCD1602 (HD44780, 16 pins, Elegoo lesson "LCD Display"), pins chosen to stay clear of 7/8/9:
//     1 VSS→GND   2 VDD→5V   3 V0→contrast (second pot's wiper, or straight to GND: dark but readable)   4 RS→22
//     5 RW→GND    6 E→24     7–10 D0–D3 unconnected   11 D4→26   12 D5→28   13 D6→30   14 D7→32
//     15 A→5V through 220 Ω   16 K→GND
// I2C backpack version (4 wires: GND, VCC→5V, SDA→20, SCL→21): set LCD_I2C to 1 and install "LiquidCrystal I2C" from the
// Library Manager. Set LCD_PRESENT to 0 to build without any LCD.

#define ANGLE_SOURCE 1      // 1 = MPU-6050 on I2C (v4), 0 = potentiometer on A0
#define LCD_PRESENT 0
#define LCD_I2C 0

#if ANGLE_SOURCE
  #include <Wire.h>
  const uint8_t MPU = 0x68;
  const float COUNTS_PER_DEG = 1023.0 / 300.0;   // the pot's scale, kept
  const float ACC_LSB = 16384.0;                  // ±2 g
  const float GYR_LSB = 131.0;                    // ±250 °/s
  const float FUSE = 0.98;                        // complementary filter: gyro weight per 20 ms step (tau ≈ 1 s)
  float angleDeg = 0.0, gyroBias = 0.0;
  bool mpuOk = false;
  bool mpuRead(int16_t& ax, int16_t& ay, int16_t& az, int16_t& gz) {
    Wire.beginTransmission(MPU); Wire.write(0x3B);
    if (Wire.endTransmission(false) != 0) return false;
    if (Wire.requestFrom(MPU, (uint8_t)14) != 14) return false;
    ax = (Wire.read() << 8) | Wire.read(); ay = (Wire.read() << 8) | Wire.read(); az = (Wire.read() << 8) | Wire.read();
    Wire.read(); Wire.read();                                   // temperature
    Wire.read(); Wire.read(); Wire.read(); Wire.read();         // gx, gy
    gz = (Wire.read() << 8) | Wire.read();
    return true;
  }
  void mpuSetup() {
    Wire.begin(); Wire.setClock(400000);
    Wire.beginTransmission(MPU); Wire.write(0x6B); Wire.write(0x00); mpuOk = (Wire.endTransmission() == 0);   // wake
    Wire.beginTransmission(MPU); Wire.write(0x1A); Wire.write(0x03); Wire.endTransmission();                   // DLPF 44 Hz
    Wire.beginTransmission(MPU); Wire.write(0x1B); Wire.write(0x00); Wire.endTransmission();                   // gyro ±250 °/s
    Wire.beginTransmission(MPU); Wire.write(0x1C); Wire.write(0x00); Wire.endTransmission();                   // accel ±2 g
    if (!mpuOk) return;
    long sum = 0; int n = 0; int16_t ax, ay, az, gz;
    for (int i = 0; i < 100; i++) { if (mpuRead(ax, ay, az, gz)) { sum += gz; n++; } delay(20); }   // 2 s; a swinging arm averages to ~0 rate, so the mean is still a fair bias
    gyroBias = n ? (float)sum / n : 0.0;
    if (mpuRead(ax, ay, az, gz)) angleDeg = atan2((float)ay, (float)ax) * 57.2958;                    // start from gravity
  }
  int readAngleCounts() {
    int16_t ax, ay, az, gz;
    if (!mpuOk || !mpuRead(ax, ay, az, gz)) return -1;
    float rate = ((float)gz - gyroBias) / GYR_LSB;                       // °/s about the axle
    float accAngle = atan2((float)ay, (float)ax) * 57.2958;              // 0 = hanging straight down (X along the arm)
    angleDeg = FUSE * (angleDeg + rate * 0.02f) + (1.0 - FUSE) * accAngle;   // 0.02 s = SAMPLE_MS
    long c = lround(512.0 + COUNTS_PER_DEG * angleDeg);
    return (int)constrain(c, 0, 1023);
  }
#endif

#if LCD_PRESENT
  #if LCD_I2C
    #include <Wire.h>
    #include <LiquidCrystal_I2C.h>
    LiquidCrystal_I2C lcd(0x27, 16, 2);   // 0x3F on some backpacks
  #else
    #include <LiquidCrystal.h>
    LiquidCrystal lcd(22, 24, 26, 28, 30, 32);   // RS, E, D4, D5, D6, D7
  #endif
#endif

const int PIN_POT = A0;
const int PIN_IN1 = 7;
const int PIN_IN2 = 8;
const int PIN_EN  = 9;
const unsigned long SAMPLE_MS = 20;      // 50 Hz
const unsigned long SILENCE_MS = 10000;  // 10 s without a byte -> motor off (v2: a killed logger must not leave it running)
const unsigned long LCD_MS = 100;        // LCD refresh

int pwm = 0;
int dir = 0;
int lastAdc = 0;
unsigned long lastSample = 0;
unsigned long lastByte = 0;
unsigned long lastLcd = 0;
String line;
char runId[6] = "---";

void applyMotor() {
  digitalWrite(PIN_IN1, dir == 0 ? HIGH : LOW);
  digitalWrite(PIN_IN2, dir == 0 ? LOW : HIGH);
  analogWrite(PIN_EN, pwm);
  digitalWrite(LED_BUILTIN, pwm > 0 ? HIGH : LOW);   // the camera's motor-on flag
}

void lcdShow(unsigned long now) {
#if LCD_PRESENT
  char buf[17];
  unsigned long cs = now / 10;                       // centiseconds
  snprintf(buf, sizeof(buf), "r%-4s t=%4lu.%02lu", runId, cs / 100, cs % 100);
  lcd.setCursor(0, 0); lcd.print(buf);
  for (int i = strlen(buf); i < 16; i++) lcd.print(' ');
  snprintf(buf, sizeof(buf), "x%-3d z%d  y%4d", pwm, dir, lastAdc);
  lcd.setCursor(0, 1); lcd.print(buf);
  for (int i = strlen(buf); i < 16; i++) lcd.print(' ');
#endif
}

void setup() {
  pinMode(PIN_IN1, OUTPUT);
  pinMode(PIN_IN2, OUTPUT);
  pinMode(PIN_EN, OUTPUT);
  pinMode(LED_BUILTIN, OUTPUT);
  applyMotor();
#if ANGLE_SOURCE
  mpuSetup();
#endif
#if LCD_PRESENT
  #if LCD_I2C
    lcd.init(); lcd.backlight();
  #else
    lcd.begin(16, 2);
  #endif
  lcd.print("v3");
#endif
  Serial.begin(115200);
  Serial.print("# wind_rig v4 | t_ms,pwm,dir,adc | cmds: u <0-255>, d <0|1>, s, k, ?, n <id> | angle source: ");
#if ANGLE_SOURCE
  Serial.println(mpuOk ? "MPU-6050 ok" : "MPU-6050 NOT FOUND (check SDA 20 / SCL 21 / 5V) -- y will read 0");
#else
  Serial.println("pot on A0");
#endif
  lastByte = millis();
}

void handle(const String& cmd) {
  if (cmd.length() == 0) return;
  char c = cmd.charAt(0);
  if (c == 'u') { int v = cmd.substring(1).toInt(); pwm = constrain(v, 0, 255); applyMotor(); }
  else if (c == 'd') { dir = cmd.substring(1).toInt() ? 1 : 0; applyMotor(); }
  else if (c == 's') { pwm = 0; applyMotor(); }
  else if (c == 'k') { /* keepalive only */ }
  else if (c == 'n') { String id = cmd.substring(1); id.trim(); id.toCharArray(runId, sizeof(runId)); }
  else if (c == '?') { Serial.print("# pwm="); Serial.print(pwm); Serial.print(" dir="); Serial.print(dir); Serial.print(" y="); Serial.println(lastAdc); }
}

void loop() {
  while (Serial.available()) {
    char ch = Serial.read();
    lastByte = millis();
    if (ch == '\n' || ch == '\r') { handle(line); line = ""; }
    else if (line.length() < 32) line += ch;
  }
  unsigned long now = millis();
  if (pwm > 0 && now - lastByte > SILENCE_MS) { pwm = 0; applyMotor(); Serial.println("# safety: serial silent, motor off"); }
  if (now - lastSample >= SAMPLE_MS) {
    lastSample += SAMPLE_MS;
    if (now - lastSample > SAMPLE_MS) lastSample = now;  // resync if we fell behind
#if ANGLE_SOURCE
    int a = readAngleCounts(); if (a < 0) a = 0;
#else
    // average four reads to knock down ADC noise
    int a = (analogRead(PIN_POT) + analogRead(PIN_POT) + analogRead(PIN_POT) + analogRead(PIN_POT)) / 4;
#endif
    lastAdc = a;
    Serial.print(now); Serial.print(','); Serial.print(pwm); Serial.print(','); Serial.print(dir); Serial.print(','); Serial.println(a);
  }
  if (now - lastLcd >= LCD_MS) { lastLcd = now; lcdShow(now); }
}
