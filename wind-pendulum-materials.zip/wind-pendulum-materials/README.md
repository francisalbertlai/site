# The wind pendulum — materials

Everything behind francisalbertlai.github.io/site/wind-pendulum.html, as it was used. Rough by design.

- harness/        play.py (the only way the agent could touch the rig), RULES-OF-PLAY.md (the agent's instructions, verbatim),
                  claude-settings.json (the sandbox: what the agent could and couldn't read or run), setup-play.bat, clock.py,
                  fit.py and log.py (the fixed-protocol track that was never run), requirements.txt
- firmware/       wind_rig.ino for the Elegoo Mega 2560 (v4: MPU-6050 angle source; set ANGLE_SOURCE 0 for the potentiometer used in sessions 1–2)
- camera/         track.py (LED autosync + marker tracking), camera_vs_pot.png (the verdict figure), camera_frames_022_023.png
- sessions/       session-1: runs 001–020, ledger, the agent's notes, REVIEW.md
                  session-2: runs 021–052 (CSV t,x,z,y at 50 Hz), ledger.jsonl/.md, model.md, boundaries.md, session-2.md,
                  analysis/ (the agent's own scripts and trace predictions), cam_*.csv (camera tracks), REVIEW.md
- README-rig.md   the working README for the rig (build, checklist, safety)

The agent was Claude Code. The harness, firmware and tracker were built with Claude. Videos are not included (size).
