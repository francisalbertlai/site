#!/usr/bin/env python3
"""
clock.py -- a full-screen clock. v1, 6 Sep 2026.

Shows the PC's wall-clock time to the millisecond -- the clock play.py stamps its ledger with -- plus the current run id
and the live x, z, y that play.py writes to runs/play/live.json ten times a second while a run is in progress.

  py -3 clock.py            # full screen; Esc to quit
  py -3 clock.py --window   # a normal window instead

It only reads live.json.
"""
import argparse, json, os, sys, time, tkinter as tk
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
LIVE = os.path.join(HERE, "runs", "play", "live.json")


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--window", action="store_true"); a = ap.parse_args()
    root = tk.Tk(); root.title("clock"); root.configure(bg="black")
    if not a.window: root.attributes("-fullscreen", True)
    root.bind("<Escape>", lambda e: root.destroy())
    big = tk.Label(root, text="", fg="white", bg="black", font=("Consolas", 150, "bold")); big.pack(expand=True)
    mid = tk.Label(root, text="", fg="#ffd400", bg="black", font=("Consolas", 90, "bold")); mid.pack(expand=True)
    small = tk.Label(root, text="", fg="#888888", bg="black", font=("Consolas", 40)); small.pack(expand=True)
    state = {"mtime": 0, "live": None}

    def tick():
        now = datetime.now()
        big.config(text=now.strftime("%H:%M:%S.") + f"{now.microsecond // 1000:03d}")
        try:
            m = os.path.getmtime(LIVE)
            if m != state["mtime"]:
                state["mtime"] = m
                with open(LIVE, encoding="utf-8") as f: state["live"] = json.load(f)
            live = state["live"]
            if live and time.time() - m < 2.0 and live.get("state") == "run":
                mid.config(text=f"run {live['run']}   t {live['t']:6.2f}   x {live['x']:3d}   z {live['z']}   y {live['y']:4d}")
            elif live and live.get("state") == "run":
                mid.config(text=f"run {live['run']}   (stale)")
            else:
                mid.config(text="idle")
        except (OSError, ValueError, KeyError):
            mid.config(text="idle")
        small.config(text=now.strftime("%Y-%m-%d") + "    same clock as the ledger")
        root.after(10, tick)

    tick(); root.mainloop()


if __name__ == "__main__":
    main()
