@echo off
rem setup-play.bat -- builds the sealed play project from this kit. Run from anywhere. The folder name is deliberately neutral.
set DST=%USERPROFILE%\Projects\blackbox
mkdir "%DST%\.claude" 2>nul
mkdir "%DST%\runs\play\analysis" 2>nul
copy /Y "%~dp0play.py" "%DST%\play.py" >nul
copy /Y "%~dp0CLAUDE.md" "%DST%\CLAUDE.md" >nul
copy /Y "%~dp0clock.py" "%DST%\clock.py" >nul
copy /Y "%~dp0claude-settings.json" "%DST%\.claude\settings.json" >nul
set /p LINK=COM port of the Mega (e.g. COM3): 
echo {"link": "%LINK%"}> "%DST%\runs\play\config.json"
py -3 -m pip install --quiet pyserial numpy matplotlib
echo play project ready: %DST%   (link %LINK% written to runs\play\config.json; the agent never sees it)
echo   sim_box.py is deliberately NOT copied -- it holds the physics
echo next: open %DST% in Claude Code and paste the kickoff line from wind-rig\README.md
