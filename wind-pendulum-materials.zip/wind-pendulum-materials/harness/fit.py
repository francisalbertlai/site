#!/usr/bin/env python3
"""
fit.py — turn the wind rig's CSVs into physics. numpy only (pandas optional). v1, 3 Sep 2026.

  py -3 fit.py --simulate                                   # kill-test 0: does the pipeline recover a KNOWN law from fake data?
  py -3 fit.py --decay runs/decay1.csv --calib calib.json   # ω0, damping, g/L from free decay
  py -3 fit.py --steps runs/steps1.csv --calib calib.json   # steady-state sinθ vs u → thrust exponent
  py -3 fit.py --random runs/rand1.csv --calib calib.json   # sparse regression for θ'' = f(θ, θ', u)
  py -3 fit.py --calibrate <adc_hanging> <adc_at_90deg>     # writes calib.json

Model the data is tested against (the target, never assumed). The fan rides ON the arm, so its thrust is always
perpendicular to the arm and its torque does not depend on the angle:
    θ'' = -(g/L)·sin θ − c·θ' + k·u^p            (θ in rad, u in PWM counts 0–255, p the thrust exponent)
Model selection is by PREDICTION on a held-out tail, not by coefficient size: candidate laws (linear thrust u,
square-law u², with and without quadratic damping) are each fitted by least squares on the first 80 % and judged by
forward-simulated RMS error on the last 20 %. That avoids the collinearity trap (θ≈sinθ, u≈u²) that makes naive
sparse regression split huge opposite coefficients. numpy only; nothing to install.
"""
import argparse, csv, json, math, sys
import numpy as np

G = 9.81

# ----------------------------------------------------------------- io / calibration
def read_csv(path):
    rows = []
    with open(path, newline="") as f:
        r = csv.DictReader(f)
        for d in r:
            try: rows.append((float(d["t_ms"]) / 1000.0, float(d["pwm"]), float(d["adc"]), d.get("phase", "")))
            except (KeyError, ValueError): continue
    t = np.array([x[0] for x in rows]); u = np.array([x[1] for x in rows]); adc = np.array([x[2] for x in rows])
    phase = np.array([x[3] for x in rows])
    return t - t[0], u, adc, phase

def load_calib(path):
    c = json.load(open(path)); return float(c["adc_zero"]), float(c["adc_90"])

def adc_to_theta(adc, adc_zero, adc_90):
    return (adc - adc_zero) / (adc_90 - adc_zero) * (math.pi / 2)   # radians, sign = direction of the 90° reference

# ----------------------------------------------------------------- numerics (no scipy)
def smooth(x, win=11):
    win = max(3, win | 1); k = np.ones(win) / win
    pad = np.pad(x, (win // 2, win // 2), mode="edge")
    return np.convolve(pad, k, mode="valid")

def savgol_deriv(t, x, win=15, order=3, deriv=1):
    """Savitzky–Golay derivative by local polynomial fit (uniform dt assumed)."""
    win = max(order + 2, win | 1); h = win // 2; dt = np.median(np.diff(t))
    out = np.full_like(x, np.nan)
    for i in range(h, len(x) - h):
        tt = (np.arange(-h, h + 1)) * dt; p = np.polyfit(tt, x[i - h:i + h + 1], order)
        dp = np.polyder(p, deriv); out[i] = np.polyval(dp, 0.0)
    return out

def library(th, thd, u, terms):
    cols = {"sinθ": np.sin(th), "θ'": thd, "θ'|θ'|": thd * np.abs(thd), "u": u, "u²": u ** 2, "1": np.ones_like(th)}
    return np.column_stack([cols[n] for n in terms])

CANDIDATES = {
    "A: sinθ, θ', u":            ["sinθ", "θ'", "u", "1"],
    "B: sinθ, θ', u²":           ["sinθ", "θ'", "u²", "1"],
    "C: sinθ, θ', θ'|θ'|, u²":   ["sinθ", "θ'", "θ'|θ'|", "u²", "1"],
    "D: sinθ, θ', u, u²":        ["sinθ", "θ'", "u", "u²", "1"],
}

def stlsq(X, y, threshold, iters=20):  # kept for experiments; model selection above uses prediction instead
    """Sequential thresholded least squares — SINDy's core. Columns are standardised for the threshold."""
    sd = np.std(X, axis=0); scale = np.where(sd > 1e-9, sd, 1.0); Xs = X / scale   # constant column keeps scale 1
    w = np.linalg.lstsq(Xs, y, rcond=None)[0]; active = np.ones(X.shape[1], bool)
    for _ in range(iters):
        small = np.abs(w) < threshold; active &= ~small; w = np.zeros(X.shape[1])
        if not active.any(): break
        w[active] = np.linalg.lstsq(Xs[:, active], y, rcond=None)[0]
    return w / scale

def rk4(f, y0, t):
    y = np.zeros((len(t), len(y0))); y[0] = y0
    for i in range(1, len(t)):
        h = t[i] - t[i - 1]; k1 = f(t[i - 1], y[i - 1]); k2 = f(t[i - 1] + h / 2, y[i - 1] + h / 2 * k1)
        k3 = f(t[i - 1] + h / 2, y[i - 1] + h / 2 * k2); k4 = f(t[i], y[i - 1] + h * k3)
        y[i] = y[i - 1] + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
    return y

# ----------------------------------------------------------------- analyses
def analyse_decay(t, th):
    th = smooth(th - np.mean(th[-100:]))       # remove the rest offset
    # zero crossings → period; peak envelope → damping
    idx = np.where(np.diff(np.sign(th)) != 0)[0]
    if len(idx) < 4: print("not enough oscillations"); return
    half_periods = np.diff(t[idx]); T = 2 * np.median(half_periods); w0 = 2 * math.pi / T
    peaks = [abs(th[i]) for i in range(1, len(th) - 1) if abs(th[i]) > abs(th[i - 1]) and abs(th[i]) >= abs(th[i + 1]) and abs(th[i]) > 0.02]
    if len(peaks) >= 3:
        n = np.arange(len(peaks)); slope = np.polyfit(n, np.log(peaks), 1)[0]   # per half-period
        zeta = -slope / math.pi
    else: zeta = float("nan")
    L_eff = G / w0 ** 2
    print(f"free decay: period {T:.3f} s → ω0 {w0:.3f} rad/s → effective length g/ω0² = {L_eff*100:.1f} cm; damping ratio ζ ≈ {zeta:.3f} (c ≈ {2*zeta*w0:.3f} 1/s)")
    return w0, zeta

def analyse_steps(t, th, u, phase):
    # Fan on the arm ⇒ thrust torque T·L is angle-independent; gravity torque is m·g·L·sinθ.
    # Steady state is therefore sinθ = T/(m g) = k·u^p·L/g — sin, not tan (tan is the fixed-fan model).
    # Note L cancels: a longer arm does not deflect more; only thrust or a lighter tip does.
    print("steady state: u → sinθ (last 5 s of each hold)")
    us, sins = [], []
    for ph in sorted(set(p for p in phase if p.startswith("step_")), key=lambda s: int(s.split("_")[1])):
        m = phase == ph; tt = t[m]; sel = m & (t > tt.max() - 5.0)
        theta_ss = np.median(th[sel]); uu = np.median(u[sel]); us.append(uu); sins.append(abs(math.sin(theta_ss)))
        print(f"  u={uu:5.0f}  θ={math.degrees(theta_ss):6.2f}°  sinθ={abs(math.sin(theta_ss)):.4f}")
    us, sins = np.array(us), np.array(sins); ok = sins > 1e-3
    if ok.sum() >= 3:
        p = np.polyfit(np.log(us[ok]), np.log(sins[ok]), 1)
        print(f"log-log fit: sinθ ∝ u^{p[0]:.2f}   (thrust exponent; 2.0 = pure u² law)")
        return p[0]

def analyse_random(t, th, u, holdout=0.2):
    # θ, θ', θ'' all from the SAME local polynomial (same window, same order) so the smoothing attenuates them
    # consistently — mixing a smoothed θ with a differently-smoothed θ'' biases g/L upward.
    W, O = 11, 3
    th_s = savgol_deriv(t, th, W, O, 0); thd = savgol_deriv(t, th, W, O, 1); thdd = savgol_deriv(t, th, W, O, 2)
    ok = ~np.isnan(th_s) & ~np.isnan(thd) & ~np.isnan(thdd); t, th_s, thd, thdd, u = t[ok], th_s[ok], thd[ok], thdd[ok], u[ok]
    n = len(t); cut = int(n * (1 - holdout)); results = {}
    for name, terms in CANDIDATES.items():
        X = library(th_s, thd, u, terms); w = np.linalg.lstsq(X[:cut], thdd[:cut], rcond=None)[0]
        def f(tt, y, w=w, terms=terms):
            i = min(int(np.searchsorted(t, tt)), n - 1)
            row = library(np.array([y[0]]), np.array([y[1]]), np.array([u[i]]), terms)
            return np.array([y[1], (row @ w)[0]])
        # held-out prediction in 5-second windows, each re-started from the measured state (a long free-running
        # simulation of an oscillator accumulates phase error and says nothing about the law)
        errs = []; i0 = cut
        while i0 < n - 2:
            i1 = min(n, int(np.searchsorted(t, t[i0] + 5.0)))
            y = rk4(f, np.array([th_s[i0], thd[i0]]), t[i0:i1]); errs.append((y[:, 0] - th_s[i0:i1]) ** 2); i0 = i1
        rms = math.degrees(np.sqrt(np.mean(np.concatenate(errs))))
        results[name] = (rms, dict(zip(terms, w)))
        print(f"  {name:28s} 5-s-window RMS {rms:5.2f}°   " + "  ".join(f"{k}={v:+.3g}" for k, v in zip(terms, w)))
    best = min(results, key=lambda k: results[k][0]); rms, coef = results[best]
    gL = -coef["sinθ"]; L_eff = G / gL if gL > 0 else float("nan")
    print(f"→ best by prediction: {best}  (RMS {rms:.2f}°)")
    print(f"→ g/L = {gL:.3f} ⇒ L_eff = {L_eff*100:.1f} cm ; c = {-coef[chr(952)+chr(39)]:.3f} 1/s" + (f" ; k(u²) = {coef['u²']:.3e}" if "u²" in coef else "") + (f" ; k(u) = {coef['u']:.3e}" if "u" in coef else ""))
    return best, coef, rms

def _try_import(name):
    try: __import__(name); return True
    except Exception: return False

# ----------------------------------------------------------------- kill-test 0: simulate a known law and recover it
def simulate(seed=0):
    rng = np.random.default_rng(seed); L, c, k = 0.20, 0.35, 2.5e-4   # 20 cm arm, light damping; k gives ~20° at full power
    dt = 0.02; t = np.arange(0, 600, dt); levels = np.array([0, 60, 90, 120, 150, 180, 210, 240])
    u = np.repeat(rng.choice(levels, size=len(t) // 25 + 1), 25)[:len(t)].astype(float)
    def f(tt, y):
        i = min(int(tt / dt), len(t) - 1)
        return np.array([y[1], -(G / L) * math.sin(y[0]) - c * y[1] + k * u[i] ** 2])
    y = rk4(f, np.array([0.0, 0.0]), t); th = y[:, 0] + rng.normal(0, math.radians(0.3), len(t))   # 0.3° sensor noise
    print(f"SIMULATION: true g/L = {G/L:.3f} (L = {L*100:.0f} cm), c = {c}, k = {k:.1e}; noise 0.3° rms")
    best, coef, rms = analyse_random(t, th, u)
    gL = -coef["sinθ"]; L_hat = G / gL if gL > 0 else float("nan")
    verdict = "PASS" if (best.startswith("B") or best.startswith("C")) and abs(L_hat - L) / L < 0.1 and abs(-coef["θ'"] - c) / c < 0.3 else "FAIL"
    print(f"KILL-TEST 0 [{verdict}]: winner {best.split(':')[0]} (square law expected) ; L = {L_hat*100:.1f} cm vs {L*100:.0f} ; c = {-coef[chr(952)+chr(39)]:.3f} vs {c} ; k = {coef.get('u²', float('nan')):.2e} vs {k:.1e}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--simulate", action="store_true"); ap.add_argument("--decay"); ap.add_argument("--steps"); ap.add_argument("--random")
    ap.add_argument("--calib", default="calib.json"); ap.add_argument("--calibrate", nargs=2, type=float, metavar=("ADC_ZERO", "ADC_90"))
    a = ap.parse_args()
    if a.calibrate:
        json.dump({"adc_zero": a.calibrate[0], "adc_90": a.calibrate[1]}, open(a.calib, "w"), indent=1); print(f"wrote {a.calib}"); return
    if a.simulate: simulate(); return
    z, n = load_calib(a.calib)
    if a.decay: t, u, adc, ph = read_csv(a.decay); analyse_decay(t, adc_to_theta(adc, z, n))
    if a.steps: t, u, adc, ph = read_csv(a.steps); analyse_steps(t, adc_to_theta(adc, z, n), u, ph)
    if a.random: t, u, adc, ph = read_csv(a.random); analyse_random(t, adc_to_theta(adc, z, n), u)

if __name__ == "__main__":
    main()
