#!/usr/bin/env python3
"""
log.py — drive the wind rig through a protocol and log t_ms,pwm,dir,adc to CSV. v1, 3 Sep 2026.

  py -3 log.py --port COM3 --protocol decay  --out runs/decay1.csv        # motor off; displace and release when told
  py -3 log.py --port COM3 --protocol steps  --out runs/steps1.csv        # 5 s off, 15 s at each level, 10 s off
  py -3 log.py --port COM3 --protocol random --out runs/rand1.csv --minutes 30
  py -3 log.py --port COM3 --protocol manual --out runs/manual.csv        # type u 120 / s / q yourself

Find the port in Windows Device Manager (Ports → "Arduino Mega 2560 (COMx)"). Needs: pip install pyserial
Every run also writes <out>.meta.json with the protocol and timestamps. Calibration is a separate step (see README).
"""
import argparse, csv, json, os, random, sys, threading, time
try:
    import serial
except ImportError:
    sys.exit("pip install pyserial")

def open_port(port, baud):
    s = serial.Serial(port, baud, timeout=0.1)
    time.sleep(2.0)                       # Mega resets on open
    s.reset_input_buffer()
    return s

def send(s, cmd):
    s.write((cmd.strip() + "\n").encode())

class Logger:
    def __init__(self, s, out, protocol):
        os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
        self.f = open(out, "w", newline=""); self.w = csv.writer(self.f)
        self.w.writerow(["t_ms", "pwm", "dir", "adc", "protocol", "phase"])
        self.s, self.protocol, self.phase, self.n, self.stop = s, protocol, "", 0, False
        self.t = threading.Thread(target=self.run, daemon=True); self.t.start()
        self.k = threading.Thread(target=self.keepalive, daemon=True); self.k.start()
    def run(self):
        while not self.stop:
            raw = self.s.readline()
            if not raw: continue
            line = raw.decode(errors="replace").strip()
            if not line or line.startswith("#"):
                if line: print(line)
                continue
            parts = line.split(",")
            if len(parts) != 4: continue
            self.w.writerow(parts + [self.protocol, self.phase]); self.n += 1
    def keepalive(self):
        while not self.stop:
            time.sleep(3); send(self.s, "k")     # firmware v2 watchdog is 10 s
    def close(self):
        self.stop = True; time.sleep(0.3); self.f.close()

def protocol_decay(s, L):
    send(s, "s"); L.phase = "settle"; print("Motor off. Let the arm hang still... 5 s"); time.sleep(5)
    L.phase = "decay"; input("Displace the arm ~30° and hold it. Press Enter, then release within 1 s: ")
    print("Logging 25 s of free decay..."); time.sleep(25)

def protocol_steps(s, L, levels=(80, 110, 140, 170, 200, 230, 255)):
    for u in levels:
        send(s, "s"); L.phase = f"off_before_{u}"; print(f"off 5 s"); time.sleep(5)
        send(s, f"u {u}"); L.phase = f"step_{u}"; print(f"u={u} hold 15 s"); time.sleep(15)
        send(s, "s"); L.phase = f"off_after_{u}"; print("off 10 s"); time.sleep(10)

def protocol_random(s, L, minutes, seed=1):
    rnd = random.Random(seed); levels = [0, 60, 90, 120, 150, 180, 210, 240]
    end = time.time() + 60 * minutes; L.phase = "random"
    print(f"random excitation for {minutes} min (levels {levels}, new draw every 0.5 s)")
    while time.time() < end:
        send(s, f"u {rnd.choice(levels)}"); time.sleep(0.5)
    send(s, "s")

def protocol_manual(s, L):
    L.phase = "manual"; print("type: u <0-255> | d <0|1> | s | q")
    while True:
        cmd = input("> ").strip()
        if cmd == "q": break
        send(s, cmd)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", required=True); ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--protocol", choices=["decay", "steps", "random", "manual"], required=True)
    ap.add_argument("--out", required=True); ap.add_argument("--minutes", type=float, default=30)
    a = ap.parse_args()
    s = open_port(a.port, a.baud); L = Logger(s, a.out, a.protocol); t0 = time.time()
    try:
        {"decay": lambda: protocol_decay(s, L), "steps": lambda: protocol_steps(s, L),
         "random": lambda: protocol_random(s, L, a.minutes), "manual": lambda: protocol_manual(s, L)}[a.protocol]()
    finally:
        send(s, "s"); L.close(); s.close()
        json.dump({"protocol": a.protocol, "started": t0, "ended": time.time(), "rows": L.n, "port": a.port},
                  open(a.out + ".meta.json", "w"), indent=1)
        print(f"wrote {L.n} rows → {a.out}")

if __name__ == "__main__":
    main()
