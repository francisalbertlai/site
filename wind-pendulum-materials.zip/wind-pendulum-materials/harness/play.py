#!/usr/bin/env python3
"""
play.py -- the only way to interact with the system. v9.1, 6 Sep 2026.

The system has two inputs you set, x (integer 0-255) and z (0 or 1), one output you observe, y (integer 0-1023),
and a clock t (seconds). y is sampled fifty times a second. Every run starts with x=0, z=0 and ends with x=0.
Nothing else about the system is documented here, on purpose.

  py -3 play.py init [--ceiling 100]
  py -3 play.py run --why "..." --predict "..." --conf 0.8 --metric steady --lo 300 --hi 400 --cmds "x 200 @0" --for 12
  py -3 play.py run --why "..." --predict "..." --conf 0.6 --claim --cmds "pulse x=200 on=0.4 off=0.4 n=10 @1" --for 15
  py -3 play.py run ... --trace runs/play/analysis/pred_021.csv      # also: a predicted whole trace (t,y) from your model, scored by RMS
  py -3 play.py judge 007 --outcome yes --update "what this changed in the model"
  py -3 play.py update 007 --update "..."          # add the reasoning update to a metric run (may be called again; all are kept)
  py -3 play.py regime --why "..."                  # declare that the system has changed: later runs are scored as a new regime
  py -3 play.py stop --why "..."                    # end the session by choice (recorded)
  py -3 play.py ledger                              # scorecard + renders runs/play/ledger.md
  py -3 play.py show 007 [--trace-hz 5]             # reprint a run; the full 50 Hz record is runs/play/007.csv (t,x,z,y)

Command language (times are seconds from run start; events happen in time order):
  x <0-255> @t                          set x
  z <0|1> @t                            set z (takes effect immediately)
  pulse x=<v> on=<s> off=<s> n=<k> @t   k pulses: x=v for on seconds, then x=0 for off seconds
  ramp x=<v0>..<v1> over=<s> @t         linear ramp of x from v0 to v1 over s seconds, 10 updates a second
A run with no commands is allowed: it just records y. One run at a time; never two in parallel.

Metrics you can predict (in y units, or seconds):
  start     median y over the first 0.5 s
  final     median y over the last 1 s
  steady    median y over the last 3 s
  min, max  extremes of y over the whole run
  range     max - min over the whole run
  spread    max - min over the last 3 s
  period    seconds per repeat of y after the last command, from crossings of its own mean (None if < 4 crossings)
  t_settle  seconds after the last command until y stays within +/-6 of final for 1.5 s (None if never)
A metric that comes out None misses every interval. To predict a None ("period will be None"), use a claim.
A trace prediction (--trace, a CSV with columns t,y — your model's y(t) for the run) is optional on top of the metric or
claim. It is scored by RMS against the observed y, next to the RMS of the laziest prediction (y stays at its start value);
skill = 1 - RMS/RMS_lazy. Skill near 1 is a model; near 0 is no better than "nothing happens"; below 0 is worse.

Rules of this program (about the program, not the system):
  x is at most 255 and z is 0 or 1 -- that is the domain.  A run is at most 300 s.
  Load limit: the program refuses to START a run if the x-weighted time (integral of x/255 dt) over the last 15 minutes,
  plus the run you asked for, would exceed 9 minutes. It says so, records nothing, and tells you how long to wait.
  Nothing is ever stopped mid-run.
  A session has a run ceiling; you are expected to stop before it, by choice, with 'play.py stop'. 'init' will not open a
  new session while one is open.
  Regimes: 'play.py regime' marks a point after which the system is treated as having changed. The ledger scores each regime
  separately, so a model of the old system is not punished for the new one. Nothing else changes; the ids keep counting.
"""
import argparse, csv, json, math, os, re, sys, time
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
PLAY_DIR = os.path.join(HERE, "runs", "play")
CONFIG = os.path.join(PLAY_DIR, "config.json")
SESSION = os.path.join(PLAY_DIR, "session.json")
LEDGER = os.path.join(PLAY_DIR, "ledger.jsonl")
LEDGER_MD = os.path.join(PLAY_DIR, "ledger.md")
LIVE = os.path.join(PLAY_DIR, "live.json")      # live run values for the display; rewritten 10x/s during a run
LOCK = os.path.join(PLAY_DIR, ".running")
METRICS = ["start", "final", "steady", "min", "max", "range", "spread", "period", "t_settle"]
LIMITS = {"max_run_s": 300.0, "max_x": 255, "load_window_s": 900.0, "load_max_s": 540.0}
BAUD = 115200
KEEPALIVE_S = 2.0          # the system zeroes x after ~10 s of silence; a killed program must not leave x set
TRACE_LINES = 150


# ----------------------------------------------------------------------------------------------- clock
class Clock:
    """Real time, or a virtual clock for the stand-in system so program tests do not wait."""
    def __init__(self, virtual=False):
        self.virtual = virtual; self.t = 0.0; self.t0 = time.monotonic()
    def now(self):
        return self.t if self.virtual else time.monotonic() - self.t0
    def sleep(self, s):
        if s <= 0: return
        if self.virtual: self.t += s
        else: time.sleep(s)


# ----------------------------------------------------------------------------------------------- the system
class LiveSystem:
    """Lines of 't_ms,x,z,y' at 50 Hz over the link. Opening the link resets the system (x=0, z=0)."""
    def __init__(self, link):
        try:
            import serial
        except ImportError:
            sys.exit("pip install pyserial")
        try:
            self.s = serial.Serial(link, BAUD, timeout=0)
        except Exception as e:
            sys.exit(f"cannot open the link: {e}")
        time.sleep(2.2); self.s.reset_input_buffer(); self.buf = b""
    def send(self, cmd):
        self.s.write((cmd + "\n").encode())
    def rows(self, clock):
        data = self.s.read(4096)
        if data: self.buf += data
        out = []
        while b"\n" in self.buf:
            line, self.buf = self.buf.split(b"\n", 1)
            line = line.decode(errors="replace").strip()
            if not line or line.startswith("#"): continue
            p = line.split(",")
            if len(p) != 4: continue
            try: out.append((int(p[0]), int(p[1]), int(p[2]), int(p[3])))
            except ValueError: pass
        return out
    def close(self):
        try: self.send("s")
        finally: self.s.close()


def stand_in(clock):
    """A stand-in system used only to test this program; it is not shipped with the play project."""
    for d in (HERE, os.path.dirname(HERE)):
        if os.path.exists(os.path.join(d, "sim_box.py")):
            sys.path.insert(0, d)
            import sim_box
            return sim_box.SimBox(clock)
    sys.exit("no stand-in system in this folder")


def open_system(ses, clock):
    return stand_in(clock) if ses.get("sim") else LiveSystem(ses["link"])


# ----------------------------------------------------------------------------------------------- files
def load_json(path, default=None):
    if not os.path.exists(path): return default
    with open(path, encoding="utf-8") as f: return json.load(f)

def save_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f: json.dump(obj, f, indent=1)

def write_live(obj):
    try:
        tmp = LIVE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f: json.dump(obj, f)
        os.replace(tmp, LIVE)
    except OSError:
        pass

def append_ledger(rec):
    os.makedirs(PLAY_DIR, exist_ok=True)
    rec["at"] = datetime.now().isoformat(timespec="seconds")
    with open(LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=True) + "\n"); f.flush(); os.fsync(f.fileno())

def read_ledger():
    if not os.path.exists(LEDGER): return []
    with open(LEDGER, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]

def fold_ledger():
    """Append-only records folded by run id. The first judgement stands; updates accumulate."""
    runs, notes = {}, []
    for r in read_ledger():
        k = r["kind"]
        if k in ("session", "stop", "regime"): notes.append(r); continue
        e = runs.setdefault(r["id"], {"id": r["id"], "updates": []})
        if k == "predict":
            e.update({kk: r[kk] for kk in ("why", "cmds", "for_s", "predict", "kind_p", "metric", "lo", "hi", "conf", "session_n")})
            e["regime"] = r.get("regime", 1)
        elif k == "observe":
            e["observed"] = r["observed"]; e["score"] = r["score"]; e["csv"] = r["csv"]
        elif k == "judge":
            if "outcome" not in e: e["outcome"] = r["outcome"]
            if r.get("update"): e["updates"].append(r["update"])
        elif k == "update":
            e["updates"].append(r["update"])
    return [runs[k] for k in sorted(runs)], notes


# ----------------------------------------------------------------------------------------------- commands
def x_val(s, max_x):
    v = int(s)
    if v > max_x: sys.exit(f"x {v} is outside 0-{max_x}; nothing was run")
    return v

def parse_cmds(text, max_x):
    ev = []
    for tok in [t.strip() for t in (text or "").split(";") if t.strip()]:
        m = re.fullmatch(r"x\s+(\d+)\s*@\s*([\d.]+)", tok)
        if m: ev.append((float(m[2]), "u", x_val(m[1], max_x))); continue
        m = re.fullmatch(r"z\s+([01])\s*@\s*([\d.]+)", tok)
        if m: ev.append((float(m[2]), "d", int(m[1]))); continue
        m = re.fullmatch(r"pulse\s+x=(\d+)\s+on=([\d.]+)\s+off=([\d.]+)\s+n=(\d+)\s*@\s*([\d.]+)", tok)
        if m:
            v, on, off, n, t0 = x_val(m[1], max_x), float(m[2]), float(m[3]), int(m[4]), float(m[5])
            for i in range(n):
                ev.append((t0 + i * (on + off), "u", v)); ev.append((t0 + i * (on + off) + on, "u", 0))
            continue
        m = re.fullmatch(r"ramp\s+x=(\d+)\.\.(\d+)\s+over=([\d.]+)\s*@\s*([\d.]+)", tok)
        if m:
            v0, v1, over, t0 = x_val(m[1], max_x), x_val(m[2], max_x), float(m[3]), float(m[4])
            steps = max(1, int(over * 10))
            for i in range(steps + 1):
                ev.append((t0 + over * i / steps, "u", int(round(v0 + (v1 - v0) * i / steps))))
            continue
        sys.exit(f"cannot parse command: '{tok}'; nothing was run")
    ev.sort(key=lambda e: e[0])
    return ev

def planned_load(ev, for_s):
    """x-weighted seconds (integral of x/255 dt) the schedule would run, if nothing interrupts it."""
    total, cur, last_t = 0.0, 0, 0.0
    for t, kind, val in ev:
        if kind != "u": continue
        total += (t - last_t) * cur / 255.0; cur, last_t = val, t
    return total + (for_s - last_t) * cur / 255.0


def load_trace(path, for_s):
    """Read a predicted trace CSV (t,y). Kept small so it can be stored inside the ledger record itself."""
    pts = []
    try:
        with open(path, encoding="utf-8") as f:
            rd = csv.reader(f); hdr = next(rd)
            for r in rd:
                if len(r) < 2: continue
                t, y = float(r[0]), float(r[1])
                if 0 <= t <= for_s: pts.append((round(t, 3), round(y, 2)))
    except (OSError, ValueError) as e:
        sys.exit(f"--trace: cannot read {path}: {e}; nothing was run")
    if len(pts) < 5: sys.exit("--trace needs at least 5 points inside the run; nothing was run")
    pts.sort()
    if len(pts) > 3000: pts = pts[::len(pts) // 3000 + 1]
    return pts

def score_trace(pred, rows):
    """RMS of predicted vs observed y at the observed sample times, and the RMS of 'y stays at its start value'."""
    if not rows or not pred: return None
    t = [r[0] for r in rows]; y = [r[3] for r in rows]
    pt = [p[0] for p in pred]; py_ = [p[1] for p in pred]
    lo, hi = pt[0], pt[-1]
    def interp(x):
        if x <= lo: return py_[0]
        if x >= hi: return py_[-1]
        import bisect
        k = bisect.bisect_right(pt, x); a, b = pt[k - 1], pt[k]
        return py_[k - 1] + (py_[k] - py_[k - 1]) * (x - a) / (b - a) if b > a else py_[k]
    sel = [(tt, yy) for tt, yy in zip(t, y) if lo <= tt <= hi]
    if len(sel) < 10: return None
    start = median([yy for tt, yy in sel if tt <= sel[0][0] + 0.5])
    e2 = sum((yy - interp(tt)) ** 2 for tt, yy in sel) / len(sel)
    b2 = sum((yy - start) ** 2 for tt, yy in sel) / len(sel)
    rms, lazy = math.sqrt(e2), math.sqrt(b2)
    return {"rms": round(rms, 2), "rms_lazy": round(lazy, 2), "skill": round(1 - rms / lazy, 3) if lazy > 0 else None,
            "n": len(sel), "span": [lo, hi]}


# ----------------------------------------------------------------------------------------------- metrics
def median(xs):
    xs = sorted(xs); n = len(xs)
    if n == 0: return None
    return xs[n // 2] if n % 2 else (xs[n // 2 - 1] + xs[n // 2]) / 2

def metrics(rows, last_cmd_t):
    """rows: list of (t, x, z, y) with t in seconds from run start."""
    if not rows: return {m: None for m in METRICS} | {"samples": 0, "duration": 0.0}
    t = [r[0] for r in rows]; Y = [r[3] for r in rows]; T = t[-1]
    win = lambda a, b: [s for tt, s in zip(t, Y) if a <= tt <= b]
    out = {"samples": len(rows), "duration": round(T, 2),
           "start": median(win(0, 0.5)), "final": median(win(T - 1.0, T)), "steady": median(win(T - 3.0, T)),
           "min": min(Y), "max": max(Y)}
    out["range"] = out["max"] - out["min"]
    last3 = win(T - 3.0, T); out["spread"] = (max(last3) - min(last3)) if last3 else None
    seg = [(tt, s) for tt, s in zip(t, Y) if tt >= last_cmd_t]
    out["period"] = None; out["t_settle"] = None
    if len(seg) >= 25:
        ts = [a for a, _ in seg]; ss = [b for _, b in seg]
        sm = [sum(ss[max(0, i - 2):i + 3]) / len(ss[max(0, i - 2):i + 3]) for i in range(len(ss))]
        mean = sum(sm) / len(sm); dev = [v - mean for v in sm]
        if max(ss) - min(ss) >= 8:
            # crossings of the mean with hysteresis: a crossing counts only if the signal had moved >= 4 units
            # away from the mean since the previous one, so noise around a settled value is not a repeat
            cross, sign, extreme = [], (1 if dev[0] >= 0 else -1), 0.0
            for i in range(len(dev)):
                extreme = max(extreme, abs(dev[i]))
                s_now = 1 if dev[i] >= 0 else -1
                if s_now != sign:
                    if extreme >= 4.0: cross.append(ts[i])
                    sign, extreme = s_now, 0.0
            if len(cross) >= 4:
                out["period"] = round(2 * (cross[-1] - cross[0]) / (len(cross) - 1), 3)
        fin = out["final"]
        if fin is not None:
            for i in range(len(seg)):
                j = i
                while j < len(seg) and ts[j] - ts[i] < 1.5: j += 1
                if j >= len(seg): break
                if all(abs(ss[k] - fin) <= 6 for k in range(i, j)):
                    out["t_settle"] = round(ts[i] - last_cmd_t, 2); break
    return out

def score(kind_p, metric, lo, hi, obs):
    if kind_p != "metric": return {"hit": None}
    v = obs.get(metric)
    if v is None: return {"hit": False, "note": f"{metric} was None", "err_out": None, "abs_err_mid": None}
    hit = lo <= v <= hi
    return {"hit": hit, "err_out": round(max(lo - v, v - hi, 0), 3), "abs_err_mid": round(abs(v - (lo + hi) / 2), 3)}


# ----------------------------------------------------------------------------------------------- run
def load_wait(ses, lim, planned):
    """Seconds to wait before the planned run fits under the load limit (0 = go). Prunes old history in place."""
    if not lim.get("load_window_s"): return 0.0
    now = time.time(); hist = [h for h in ses.get("load", []) if now - h[0] < lim["load_window_s"]]
    ses["load"] = hist
    used = sum(h[1] for h in hist)
    if used + planned <= lim["load_max_s"]: return 0.0
    for end, on in sorted(hist):
        used -= on
        if used + planned <= lim["load_max_s"]:
            return max(0.0, end + lim["load_window_s"] - now)
    return lim["load_window_s"]


def do_run(a):
    ses = load_json(SESSION)
    if not ses: sys.exit("no session: run 'play.py init' first")
    if ses.get("stopped"): sys.exit("this session was stopped by choice; a new 'init' starts another")
    lim = ses["limits"]
    if ses["runs_used"] >= ses["ceiling"]:
        sys.exit(f"ceiling reached ({ses['ceiling']} runs). Stop and write the session up.")
    ev = parse_cmds(a.cmds, lim["max_x"])
    last_t = max([e[0] for e in ev], default=0.0)
    for_s = a.for_s if a.for_s is not None else min(last_t + 5.0, lim["max_run_s"])
    if for_s > lim["max_run_s"]: sys.exit(f"--for {for_s} exceeds the {lim['max_run_s']} s limit; nothing was run")
    if for_s < last_t: sys.exit(f"--for {for_s} ends before the last command at {last_t} s; nothing was run")
    if not (0 < a.conf < 1): sys.exit("--conf must be strictly between 0 and 1; nothing was run")
    kind_p = "claim" if a.claim else "metric"
    if kind_p == "metric":
        if a.metric not in METRICS: sys.exit(f"--metric must be one of {METRICS} (or use --claim); nothing was run")
        if a.lo is None or a.hi is None or a.lo > a.hi: sys.exit("metric predictions need --lo <= --hi; nothing was run")
    if not a.why.strip() or not a.predict.strip(): sys.exit("--why and --predict are required; nothing was run")
    trace = load_trace(a.trace, for_s) if a.trace else None
    if os.path.exists(LOCK) and time.time() - os.path.getmtime(LOCK) < 360:
        sys.exit("another run appears to be in progress (runs/play/.running is fresh). One run at a time; nothing was run")

    planned = planned_load(ev, for_s)
    wait = load_wait(ses, lim, planned)
    if wait > 0:
        save_json(SESSION, ses)
        print(f"load limit: this run would put more than {lim['load_max_s']/60:.0f} min of x-weighted time into the last "
              f"{lim['load_window_s']/60:.0f} min. Not started; nothing recorded. Either wait {wait:.0f} s and ask again, "
              f"or ask for a shorter or lower run. (A rule of this program, not of the system.)")
        sys.exit(4)

    # Allocate the id and reserve the planned load BEFORE the run, so a program killed mid-run still leaves a trace and
    # still counts against the limit. Then the prediction goes to disk BEFORE the system is touched. That is the whole point.
    rid = f"{ses['next_id']:03d}"; ses["next_id"] += 1
    ses.setdefault("load", []).append([time.time(), round(planned, 1)]); load_idx = len(ses["load"]) - 1
    save_json(SESSION, ses)
    append_ledger({"kind": "predict", "id": rid, "session_n": ses.get("session_n"), "regime": ses.get("regime", 1), "why": a.why, "cmds": a.cmds or "",
                   "for_s": for_s, "predict": a.predict, "kind_p": kind_p,
                   "metric": a.metric if kind_p == "metric" else None, "lo": a.lo, "hi": a.hi, "conf": a.conf,
                   "trace": trace})
    with open(LOCK, "w") as f: f.write(rid)

    clock = Clock(virtual=bool(ses.get("sim")))
    sysm = open_system(ses, clock)
    sysm.send(f"n {rid}")                      # the run id, for the display in the camera's frame
    rows, on_time = [], 0.0
    t0_ms = None; i = 0; cur_x, last_change = 0, clock.now(); last_send = clock.now(); t0_wall = time.time()
    try:
        while t0_ms is None and clock.now() < 8.0:      # firmware v4 calibrates its gyro for 2 s after the reset
            batch = sysm.rows(clock)
            if batch:
                t0_ms = batch[0][0]
                rows += [(round((r[0] - t0_ms) / 1000.0, 3), r[1], r[2], r[3]) for r in batch]
            else:
                clock.sleep(0.005)
        if t0_ms is None:
            append_ledger({"kind": "observe", "id": rid, "observed": metrics([], 0), "score": {"hit": False, "note": "no data"},
                           "csv": None})
            sys.exit("no data from the system. Recorded as a run with no observation. Tell Albert.")
        start = clock.now(); t0_wall = time.time(); last_live = -1.0
        cur_z, last_y = 0, rows[-1][3] if rows else None
        while True:
            now = clock.now() - start
            if now - last_live >= 0.1:
                write_live({"state": "run", "run": rid, "t": round(now, 2), "x": cur_x, "z": cur_z, "y": last_y}); last_live = now
            while i < len(ev) and ev[i][0] <= now:
                _, kind, val = ev[i]; i += 1
                sysm.send(f"{'u' if kind == 'u' else 'd'} {val}"); last_send = clock.now()
                if kind == "u":
                    on_time += (clock.now() - last_change) * (cur_x / 255.0); last_change = clock.now(); cur_x = val
                else:
                    cur_z = val
            if clock.now() - last_send > KEEPALIVE_S:
                sysm.send("k"); last_send = clock.now()
            for r in sysm.rows(clock):
                tt = (r[0] - t0_ms) / 1000.0
                rows.append((round(tt, 3), r[1], r[2], r[3])); last_y = r[3]
            if now >= for_s: break
            clock.sleep(0.005)
        on_time += (clock.now() - last_change) * (cur_x / 255.0)
    finally:
        sysm.close()
        write_live({"state": "idle", "run": rid})
        try: os.remove(LOCK)
        except OSError: pass

    os.makedirs(PLAY_DIR, exist_ok=True)
    csv_path = os.path.join(PLAY_DIR, f"{rid}.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["t", "x", "z", "y"]); w.writerows(rows)
    obs = metrics(rows, last_t); sc = score(kind_p, a.metric, a.lo, a.hi, obs)
    if trace: sc["trace"] = score_trace(trace, rows)
    append_ledger({"kind": "observe", "id": rid, "observed": obs, "score": sc, "csv": os.path.relpath(csv_path, HERE),
                   "t0_wall": datetime.fromtimestamp(t0_wall).isoformat(timespec="milliseconds"), "t0_epoch": round(t0_wall, 3),
                   "t0_ms": t0_ms})
    ses = load_json(SESSION)
    ses["runs_used"] += 1
    if load_idx < len(ses.get("load", [])): ses["load"][load_idx] = [time.time(), round(on_time, 1)]
    save_json(SESSION, ses)
    print_run({"id": rid, "why": a.why, "cmds": a.cmds or "", "for_s": for_s, "predict": a.predict, "kind_p": kind_p,
               "metric": a.metric, "lo": a.lo, "hi": a.hi, "conf": a.conf, "observed": obs, "score": sc}, rows, a.trace_hz, a.trace_lines)
    print(f"runs used this session: {ses['runs_used']} of a ceiling of {ses['ceiling']}")


def print_run(e, rows, trace_hz=5.0, trace_lines=TRACE_LINES):
    o = e.get("observed") or {}
    print(f"run {e['id']}  cmds: {e['cmds'] or '(none)'} | for {e['for_s']} s | {o.get('samples', 0)} samples")
    print("y: " + "  ".join(f"{m} {o.get(m)}" for m in METRICS))
    if e["kind_p"] == "metric":
        v = o.get(e["metric"]); sc = e.get("score") or {}
        verdict = "HIT" if sc.get("hit") else "MISS" + (f" (out by {sc['err_out']})" if sc.get("err_out") else "")
        print(f"prediction: {e['metric']} in [{e['lo']}, {e['hi']}] @{e['conf']:.2f}  ->  observed {v}  {verdict}")
    else:
        print(f"claim @{e['conf']:.2f}: {e['predict']}  ->  judge it: play.py judge {e['id']} --outcome yes|no|void --update \"...\"")
    tr = (e.get("score") or {}).get("trace")
    if tr: print(f"trace prediction: RMS {tr['rms']} vs lazy {tr['rms_lazy']}  ->  skill {tr['skill']}   ({tr['n']} samples over t={tr['span'][0]}..{tr['span'][1]})")
    if rows and trace_hz > 0:
        dur = max(rows[-1][0], 0.2)
        hz = min(trace_hz, trace_lines / dur) if trace_lines else trace_hz
        print(f"trace ({hz:.2g} Hz) t,x,z,y:" + ("" if hz >= trace_hz else f"   [thinned to ~{trace_lines} lines; full 50 Hz record in the CSV]"))
        step = 1.0 / hz; nxt = 0.0
        for r in rows:
            if r[0] >= nxt:
                print(f"{r[0]:.1f},{r[1]},{r[2]},{r[3]}"); nxt += step


# ----------------------------------------------------------------------------------------------- other commands
def do_init(a):
    os.makedirs(PLAY_DIR, exist_ok=True)
    old = load_json(SESSION)
    if old and old.get("runs_used", 0) > 0 and not old.get("stopped") and not a.force:
        sys.exit(f"session {old.get('session_n')} is already open with {old['runs_used']} runs -- just continue with 'play.py run'. "
                 "(To end it: 'play.py stop --why ...'.)")
    cfg = load_json(CONFIG, {})
    link = a.link or cfg.get("link")
    if not a.sim and not link: sys.exit("not configured. Tell Albert.")
    ses = {"link": link, "sim": bool(a.sim), "ceiling": a.ceiling, "runs_used": 0,
           "limits": dict(LIMITS) if not a.no_load_limit else {**LIMITS, "load_window_s": None, "load_max_s": None},
           "started": datetime.now().isoformat(timespec="seconds"),
           "load": (old or {}).get("load", []), "session_n": ((old or {}).get("session_n", 0) + 1),
           "next_id": (old or {}).get("next_id", 1), "regime": (old or {}).get("regime", 1)}
    clock = Clock(virtual=bool(a.sim)); sysm = open_system(ses, clock); sysm.send("n init")
    vals = []
    try:
        t_end = clock.now() + 3.0
        while clock.now() < t_end:
            vals += [r[3] for r in sysm.rows(clock)]; clock.sleep(0.005)
    finally:
        sysm.close()
    save_json(SESSION, ses)
    append_ledger({"kind": "session", "id": "---", "note": f"session {ses['session_n']} begins; ceiling {a.ceiling}"})
    if vals: print(f"the system answers. y with x=0 for 3 s: median {median(vals)}  min {min(vals)}  max {max(vals)}  ({len(vals)} samples)")
    else: print("the system did not answer. Tell Albert.")
    lim = ses["limits"]
    print(f"session {ses['session_n']}: ceiling {a.ceiling} runs; runs up to {lim['max_run_s']:.0f} s; "
          + (f"load limit {lim['load_max_s']/60:.0f} min x-weighted per {lim['load_window_s']/60:.0f} min" if lim.get("load_window_s") else "no load limit"))


def do_regime(a):
    ses = load_json(SESSION)
    if not ses: sys.exit("no session")
    if not a.why.strip(): sys.exit("--why is required: what changed, and which runs showed it")
    ses["regime"] = ses.get("regime", 1) + 1; save_json(SESSION, ses)
    append_ledger({"kind": "regime", "id": "---", "regime": ses["regime"], "note": f"regime {ses['regime']} declared after run {ses['next_id'] - 1:03d}: {a.why}"})
    print(f"regime {ses['regime']} begins with run {ses['next_id']:03d}. Model the system as it is now; keep the old model as the record of what it was.")

def do_stop(a):
    ses = load_json(SESSION)
    if not ses: sys.exit("no session")
    if ses.get("stopped"): sys.exit("already stopped")
    ses["stopped"] = {"at": datetime.now().isoformat(timespec="seconds"), "after_runs": ses["runs_used"], "why": a.why}
    save_json(SESSION, ses)
    append_ledger({"kind": "stop", "id": "---", "note": f"session {ses.get('session_n')} stopped by choice after {ses['runs_used']} runs: {a.why}"})
    print(f"session stopped after {ses['runs_used']} runs. Write runs/play/session-{ses.get('session_n', 1)}.md.")

def find_run(rid):
    runs, _ = fold_ledger()
    e = next((e for e in runs if e["id"] == rid), None)
    if not e: sys.exit(f"no run {rid}")
    return e

def do_judge(a):
    if a.outcome not in ("yes", "no", "void"): sys.exit("--outcome yes|no|void")
    e = find_run(a.id)
    if e.get("kind_p") != "claim": sys.exit(f"run {a.id} is a metric prediction; it scored itself. Use 'update' for its reasoning.")
    if e.get("outcome"): sys.exit(f"run {a.id} was already judged '{e['outcome']}'; judgements are final. Use 'update' to add reasoning.")
    if not e.get("observed"): sys.exit(f"run {a.id} has no observation to judge")
    append_ledger({"kind": "judge", "id": a.id, "outcome": a.outcome, "update": a.update}); print(f"judged {a.id}: {a.outcome}")

def do_update(a):
    find_run(a.id)
    if not a.update.strip(): sys.exit("an empty update is not an update")
    append_ledger({"kind": "update", "id": a.id, "update": a.update}); print(f"update recorded for {a.id}")

def do_show(a):
    e = find_run(a.id)
    rows = []
    p = os.path.join(HERE, e.get("csv") or "")
    if e.get("csv") and os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            rd = csv.reader(f); next(rd)
            rows = [(float(r[0]), int(r[1]), int(r[2]), int(r[3])) for r in rd]
    print(f"why: {e.get('why')}"); print_run(e, rows, a.trace_hz, a.trace_lines)
    for u in e.get("updates", []): print(f"update: {u}")


def do_ledger(a):
    runs, notes = fold_ledger(); ses = load_json(SESSION) or {}
    observed = [e for e in runs if e.get("observed")]
    metric = [e for e in observed if e.get("kind_p") == "metric" and e.get("score")]
    claims = [e for e in observed if e.get("kind_p") == "claim" and e.get("outcome") in ("yes", "no")]
    lines = [f"runs: {len(runs)} | this session: {ses.get('runs_used', 0)} of ceiling {ses.get('ceiling', 0)}"
             + (f" | regime {ses.get('regime', 1)}" if ses.get("regime", 1) > 1 else "")
             + (f" | STOPPED by choice after {ses['stopped']['after_runs']}" if ses.get("stopped") else "")]
    traced = [e for e in observed if (e.get("score") or {}).get("trace")]
    if traced:
        sk = [e["score"]["trace"]["skill"] for e in traced if e["score"]["trace"].get("skill") is not None]
        if sk: lines.append(f"trace predictions: {len(traced)} | mean skill {sum(sk) / len(sk):.2f} | best {max(sk):.2f} | worst {min(sk):.2f}  (1 = perfect, 0 = 'nothing happens')")
    n_reg = len([n for n in notes if n["kind"] == "regime"])
    if n_reg: lines.append(f"regimes declared: {n_reg} (each is a claim that the system changed; the record above is the overall one)")
    regimes = sorted(set(e.get("regime", 1) for e in metric))
    if len(regimes) > 1:
        for rg in regimes:
            mm = [e for e in metric if e.get("regime", 1) == rg]
            h = sum(1 for e in mm if e["score"].get("hit")); c = sum(e["conf"] for e in mm) / len(mm)
            lines.append(f"  regime {rg}: {len(mm)} metric predictions, hits {h} ({h / len(mm):.0%}), mean stated confidence {c:.2f} ({h / len(mm) - c:+.2f})")
    if metric:
        hits = sum(1 for e in metric if e["score"].get("hit")); conf = sum(e["conf"] for e in metric) / len(metric)
        real = hits / len(metric); gap = real - conf
        verdict = "overconfident" if gap < -0.1 else "underconfident" if gap > 0.1 else "calibrated so far"
        lines.append(f"metric predictions: {len(metric)} | hits {hits} ({real:.0%}) | mean stated confidence {conf:.2f} | {verdict} ({gap:+.2f})")
        bins = [(0, 0.5, "<=0.50"), (0.5, 0.7, "0.50-0.70"), (0.7, 0.9, "0.70-0.90"), (0.9, 1.01, ">0.90")]
        parts = []
        for lo, hi, name in bins:
            b = [e for e in metric if lo < e["conf"] <= hi] if lo else [e for e in metric if e["conf"] <= hi]
            if b: parts.append(f"{name}: {sum(1 for e in b if e['score'].get('hit'))}/{len(b)} hit")
        lines.append("  by stated confidence: " + " | ".join(parts))
        by_m = {}
        for e in metric: by_m.setdefault(e["metric"], []).append(e)
        lines.append("  by metric (hits/n, mean interval width -- narrow and right is the goal): " + " | ".join(
            f"{m} {sum(1 for e in v if e['score'].get('hit'))}/{len(v)}, w={sum(e['hi'] - e['lo'] for e in v) / len(v):.1f}"
            for m, v in sorted(by_m.items())))
        errs = [e["score"]["abs_err_mid"] for e in metric if e["score"].get("abs_err_mid") is not None]
        if errs: lines.append(f"  mean |observed - interval midpoint|: {sum(errs) / len(errs):.1f}")
    if claims:
        brier = sum((e["conf"] - (1 if e["outcome"] == "yes" else 0)) ** 2 for e in claims) / len(claims)
        yes = sum(1 for e in claims if e["outcome"] == "yes") / len(claims); conf = sum(e["conf"] for e in claims) / len(claims)
        lines.append(f"claims judged: {len(claims)} | Brier {brier:.3f} (0 = perfect, 0.25 = coin-flip) | mean confidence {conf:.2f} | realised yes-rate {yes:.2f}")
    unobserved = [e["id"] for e in runs if not e.get("observed")]
    if unobserved: lines.append(f"predicted but never observed (program died mid-run?): {', '.join(unobserved)}")
    missing = [e["id"] for e in observed if not e.get("updates") and not e.get("outcome")]
    if missing: lines.append(f"runs without a reasoning update: {', '.join(missing)}")
    unjudged = [e["id"] for e in observed if e.get("kind_p") == "claim" and not e.get("outcome")]
    if unjudged: lines.append(f"claims not yet judged: {', '.join(unjudged)}")
    print("\n".join(lines))
    md = ["# Play ledger", "", f"*Rendered {datetime.now().isoformat(timespec='minutes')}. Append-only source: `ledger.jsonl`.*", "",
          "## Scorecard", "", "```", *lines, "```", ""]
    if notes: md += ["## Sessions", ""] + [f"- {n['at']} - {n['note']}" for n in notes] + [""]
    md += ["## Runs", ""]
    for e in runs:
        o = e.get("observed") or {}; sc = e.get("score") or {}
        if e.get("kind_p") == "metric":
            v = o.get(e.get("metric")); res = "HIT" if sc.get("hit") else "MISS"
            head = f"### {e['id']} - {e.get('metric')} in [{e.get('lo')}, {e.get('hi')}] @{e.get('conf')} -> {v} {res}"
        else:
            head = f"### {e['id']} - claim @{e.get('conf')}: {e.get('predict')} -> {e.get('outcome', 'unjudged')}"
        if not e.get("observed"): head += " (NO OBSERVATION)"
        if e.get("regime", 1) > 1: head += f" [regime {e['regime']}]"
        md += [head, "", f"**why:** {e.get('why')}", "", f"**cmds:** `{e.get('cmds') or '(none)'}` for {e.get('for_s')} s", "",
               f"**prediction:** {e.get('predict')}", "",
               "**observed:** " + ", ".join(f"{m} {o.get(m)}" for m in METRICS), ""]
        for u in e.get("updates", []): md += [f"**update:** {u}", ""]
    with open(LEDGER_MD, "w", encoding="utf-8") as f: f.write("\n".join(md))
    print(f"rendered {os.path.relpath(LEDGER_MD, HERE)}")


# ----------------------------------------------------------------------------------------------- main
def main():
    try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception: pass
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init"); p.add_argument("--ceiling", type=int, default=100)
    p.add_argument("--link", help=argparse.SUPPRESS); p.add_argument("--force", action="store_true", help=argparse.SUPPRESS)
    p.add_argument("--no-load-limit", action="store_true", help=argparse.SUPPRESS)
    p.add_argument("--sim", action="store_true", help=argparse.SUPPRESS); p.set_defaults(fn=do_init)
    p = sub.add_parser("run")
    p.add_argument("--why", required=True); p.add_argument("--predict", required=True); p.add_argument("--conf", type=float, required=True)
    p.add_argument("--metric"); p.add_argument("--lo", type=float); p.add_argument("--hi", type=float); p.add_argument("--claim", action="store_true")
    p.add_argument("--cmds", default=""); p.add_argument("--for", dest="for_s", type=float); p.add_argument("--trace", default="")
    p.add_argument("--trace-hz", type=float, default=5.0); p.add_argument("--trace-lines", type=int, default=TRACE_LINES)
    p.set_defaults(fn=do_run)
    p = sub.add_parser("regime"); p.add_argument("--why", required=True); p.set_defaults(fn=do_regime)
    p = sub.add_parser("stop"); p.add_argument("--why", required=True); p.set_defaults(fn=do_stop)
    p = sub.add_parser("judge"); p.add_argument("id"); p.add_argument("--outcome", required=True); p.add_argument("--update", default=""); p.set_defaults(fn=do_judge)
    p = sub.add_parser("update"); p.add_argument("id"); p.add_argument("--update", required=True); p.set_defaults(fn=do_update)
    p = sub.add_parser("show"); p.add_argument("id"); p.add_argument("--trace-hz", type=float, default=5.0)
    p.add_argument("--trace-lines", type=int, default=TRACE_LINES); p.set_defaults(fn=do_show)
    p = sub.add_parser("ledger"); p.set_defaults(fn=do_ledger)
    a = ap.parse_args(); a.fn(a)

if __name__ == "__main__":
    main()
