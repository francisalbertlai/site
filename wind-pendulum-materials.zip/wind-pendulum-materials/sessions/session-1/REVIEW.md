# Session 1 — review (Claude, 6 Sep 2026)

*Copied from `the play folder` after the agent stopped by rule at run 020. The agent's own files are beside this one: `model.md`, `boundaries.md`, `session-1.md`, `ledger.md`, the CSVs, and its three analysis scripts.*

## Verdict

The agent behaved as the rules asked — prediction before every run, a fitted-on/tested-on table, honest calibration (it reported itself overconfident by 0.13 and said why), a hypothesis abandoned when run 020 failed it, and a stop when behaviour changed persistently. The system it modelled, however, was mostly the wiring. Three of its four "edges" are instrument faults, which is exactly what Track A's kill-test 1 exists to catch first and which a blind agent has no way to know.

## Evidence, from the CSVs

- **"Oscillating regime" at z=1, x=192–251 is not motion.** Run 011 shows consecutive 20 ms samples jumping 598 → 666, 642 → 514, 599 → 667 → 793; max single-step change 290–365 counts across runs 011–018. A pendulum cannot move ~90° in 20 ms. The breakup appears where the motor is PWM-chopped (x < 254) and vanishes at x = 254–255 (x=255 is pure DC, no switching edges). Signature of ground bounce under chopped motor current and/or wiper chatter under vibration.
- **"Onset undershoot" (010, 014, 015; 707 → 390 in one sample) is the motor's inrush current pulling the ground/reference**, not the arm.
- **z=0 "inert" (+1.5 counts at x=255)** is most simply a motor that did not spin with z=0 — a loose IN1 wire (chip pin 2 → Mega D7). Reverse thrust from a propeller is poor but not 4 % of forward.
- **Post-018 "self-oscillation" at rest (358–505, period 7.6 s, regular, x=0)** is a floating analog input: a disconnected A0 picks up mains hum, and 50 Hz sampled at 50 Hz aliases to |50 − f_mains|; 7.6 s ⇔ 49.87 Hz, a normal grid deviation. Run 020 under drive (370–667, irregular) is the same floating input under motor EMI. The wiper jumper or pot leg came off after run 017.
- **Rest level 715, "holds exactly with zero noise":** the pot was well connected then; but 715 is far off centre (the checklist asked for 450–580), and the arm may be resting against something rather than hanging free — which would also explain why one thrust direction moved it and the other could not.

## What it got right, worth keeping

The reasoning chain is readable run by run; the model file separates measured from guessed; the scorecard is used as written ("interval widths for range and spread are wide because the onset undershoot varies by 250 units between repeats; spread in the last 3 s was the better discriminator once I switched to it"); the stop was by rule, with the three next runs written down. Twenty runs, three analysis scripts, no rule broken.

## Fix before session 2

1. Rest reading with nothing touching: 715 steady = pot connected; wandering 360–500 = A0 jumper off. Press all three pot jumpers home.
2. Move the arm by hand: numbers must follow smoothly. Check it hangs free (nothing touching) and re-centre toward ~512.
3. `d 0` then `u 255` in the Serial Monitor: if no spin, re-seat the D7 wire (chip pin 2 column).
4. Separate short ground jumper from Mega GND to the pot's bottom leg; 100 nF (104) from the wiper column to the blue rail.
5. Noise check at z=1, x=200 for 8 s: `spread` should be single digits. Then Track A's free decay would settle whether the pivot is honest at all.

## For session 2

Tell the agent only this, in `runs/play/session-1.md` or the kickoff: *"Albert: the system was serviced between sessions 1 and 2. Treat runs 001–020 as observations of a different instance; keep the files, start the model again."* Nothing about what was wrong. Whether it re-finds a z-asymmetry that is now real (propeller reverse thrust is weaker, not zero), a steady deflection that grows with x, and a ~1 s period after release — and whether it notices that the old regimes never return — is the second session's question.
