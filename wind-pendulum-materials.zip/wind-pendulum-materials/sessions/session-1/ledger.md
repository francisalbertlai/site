# Play ledger

*Rendered 2026-09-06T17:40. Append-only source: `ledger.jsonl`.*

## Scorecard

```
runs: 20 | this session: 20 of ceiling 100
metric predictions: 14 | hits 6 (43%) | mean stated confidence 0.56 | overconfident (-0.13)
  by stated confidence: <=0.50: 0/6 hit | 0.50-0.70: 5/7 hit | 0.70-0.90: 1/1 hit
  by metric (hits/n, mean interval width -- narrow and right is the goal): max 1/1, w=7.0 | range 1/4, w=235.0 | spread 1/4, w=140.0 | start 1/2, w=10.5 | steady 2/3, w=20.7
  mean |observed - interval midpoint|: 162.4
claims judged: 6 | Brier 0.380 (0 = perfect, 0.25 = coin-flip) | mean confidence 0.54 | realised yes-rate 0.33
runs without a reasoning update: 008
```

## Sessions

- 2026-09-06T17:21:06 - session 1 begins; ceiling 100

## Runs

### 001 - steady in [708.0, 722.0] @0.85 -> 715 HIT

**why:** Run 1: baseline with no commands, to measure y's noise and drift at x=0,z=0. init showed y=715 constant over 3 s.

**cmds:** `(none)` for 10.0 s

**prediction:** y stays near 715; noise is small

**observed:** start 715.0, final 715, steady 715, min 715, max 715, range 0, spread 0, period None, t_settle 0.0

**update:** Baseline established: y=715 exactly at x=0,z=0 with zero noise over 10 s (500 samples identical). Model so far: y_rest = 715 +/- 0 (measured). Noise floor at rest is 0 y-units; any deviation under drive is signal, not noise (unless noise is input-dependent).

### 002 - claim @0.8: y moves away from 715 by more than 20 units in steady state; direction unknown -> no

**why:** Run 2: first drive. Step x=128 at t=1 and hold, to learn whether y responds, in which direction, how fast, and whether noise appears under drive. Follows 001 (rest = 715, no noise).

**cmds:** `x 128 @1` for 15.0 s

**prediction:** y moves away from 715 by more than 20 units in steady state; direction unknown

**observed:** start 715.0, final 715, steady 715, min 714, max 717, range 3, spread 2, period None, t_settle 0.0

**update:** MISS. x=128 held 14 s: steady stays 715, no shift in mean at all. But noise appeared: y jitters 714-717 under drive versus exactly 715 at rest. So x does reach the system, but at 128 its effect on the mean is below ~1 unit. Hypotheses: (a) threshold in x above 128, (b) very slow response (>14 s), (c) x only matters when z=1, (d) x mainly modulates noise. Next: x=255 for 30 s.

### 003 - steady in [705.0, 725.0] @0.55 -> 716 HIT

**why:** Run 3: maximum x=255 held 30 s, to test whether x=128 in 002 was below a threshold or the response is slow. If mean still stays at 715, x likely needs z=1 or only modulates noise. Expect jitter larger than 002's +/-2 if noise scales with x.

**cmds:** `x 255 @1` for 30.0 s

**prediction:** mean barely moves as in 002; steady stays near 715 (from 002 null result), modest chance of a real shift

**observed:** start 715.0, final 716, steady 716, min 715, max 718, range 3, spread 1, period None, t_settle 0.0

**update:** x=255 held 29 s: steady 716, i.e. +1 over rest, jitter 715-718 (smaller than at 128, oddly: spread 1 vs 2). No slow drift over 29 s. With z=0, x's effect on the mean is at most ~1 unit across the full range: gain_z0 <= 1/255 per unit x. Threshold and slow-response hypotheses are now unlikely for z=0. Leading hypothesis: z=1 enables x. Next: z=1 alone (004), then z=1 with x.

### 004 - claim @0.5: z=1 alone shifts steady y away from 715 by more than 20 units -> no

**why:** Run 4: z=1 alone with x=0, 15 s. 002 and 003 showed x barely moves y when z=0, so z is the next variable. Does z by itself change y?

**cmds:** `z 1 @1` for 15.0 s

**prediction:** z=1 alone shifts steady y away from 715 by more than 20 units

**observed:** start 715.0, final 715, steady 715, min 715, max 715, range 0, spread 0, period None, t_settle 0.0

**update:** MISS. z=1 with x=0 leaves y at exactly 715, zero jitter. z alone is invisible. Remaining hypothesis for a large effect: z gates x (interaction term). Next: z=1 with x=128.

### 005 - claim @0.6: with z=1, x=128 shifts steady y away from 715 by more than 20 units -> no

**why:** Run 5: z=1 then x=128, 20 s. 002/003 (x alone, z=0) moved the mean by <=1; 004 (z alone) did nothing. Tests the interaction: does z=1 enable x?

**cmds:** `z 1 @1; x 128 @2` for 20.0 s

**prediction:** with z=1, x=128 shifts steady y away from 715 by more than 20 units

**observed:** start 715.0, final 715, steady 715, min 714, max 717, range 3, spread 3, period None, t_settle 0.0

**update:** MISS. z=1 + x=128: steady 715, jitter 714-717, indistinguishable from 002 (z=0, x=128). z has no visible effect on the static response. Static gain of x on the mean is ~0 to +1 unit over the full range, for both z. The jitter is the only clear signature of x. Hypotheses left: (a) y responds to changes in x (derivative / AC coupling / pulses), (b) very slow integrating response (thermal-like) needing minutes, (c) x sets noise amplitude only. Next: inspect 50 Hz CSVs around the steps for fast transients, then a pulse train run.

### 006 - max in [717.0, 724.0] @0.6 -> 719 HIT

**why:** Run 6: pulse train x=255, 0.5 s on / 0.5 s off, 10 pulses. Static x barely moves the mean (002-005) but 003's edge analysis showed a fast +3 spike at the step. Tests whether y responds to changes in x rather than its level, and whether repeated edges accumulate.

**cmds:** `pulse x=255 on=0.5 off=0.5 n=10 @1` for 15.0 s

**prediction:** each edge gives a spike like 003's (+3); max stays a few units above 715 unless edges accumulate

**observed:** start 715.0, final 716, steady 716, min 715, max 719, range 4, spread 0, period None, t_settle 0.0

**update:** HIT (max 719). Pulses of x=255: y ~717-719 while on, 716 while off, and 716 persists for 4+ s after the last pulse (rest was 715). Peaks grow 717->719 over the train: a slow component accumulates. Ripple analysis (002,005): at x=128 spectral lines at 3.8/9.8/13.6 Hz, sd 0.5-0.7; at x=255 none (sd 0.28). Looks like aliased ripple, largest at mid x. Model sketch: y = 715 + fast(x) + slow, fast(255) ~ +2 (spike +3 at edge), slow builds to ~+1 in seconds and decays slowly. Next: 10 s at 255 then 50 s of decay (007).

### 007 - claim @0.55: the offset decays: median of last 1 s is back at 715 by t=60 -> no

**why:** Run 7: x=255 for 10 s then x=0 for 50 s, to measure the decay of the persistent +1 offset seen after the pulse train in 006 (y stayed 716 after x returned to 0). Time constant of the slow component.

**cmds:** `x 255 @1; x 0 @11` for 60.0 s

**prediction:** the offset decays: median of last 1 s is back at 715 by t=60

**observed:** start 716.0, final 717, steady 717, min 716, max 719, range 3, spread 0, period None, t_settle 0.0

**update:** MISS, and a surprise. Run started at y=716 (rest was 715 in 001-006). During x=255 y=718 (+2 above this run's rest); after x->0 y=717 and stays there for all 50 s: no decay at all. The rest level is ratcheting upward across runs: 715 (001-006 starts), 716 (007 start), 717 (007 end). Either the system integrates x with an extremely long memory (thermal-like, tau >> 1 min), or the baseline drifts with wall-clock time. Need to separate these: 008 no-command run now, and later runs' start values versus time and versus accumulated x.

### 008 - start in [716.5, 717.5] @0.6 -> 717.0 HIT

**why:** Run 8: no commands, 20 s, to read the current rest level after 007 ended at 717. Distinguishes a rest level that stays where drive left it (memory) from one that relaxes back toward 715 given time (decay slower than 50 s) or keeps drifting up (ambient).

**cmds:** `(none)` for 20.0 s

**prediction:** rest stays where 007 left it: start ~717 (memory hypothesis)

**observed:** start 717.0, final 717, steady 717, min 717, max 717, range 0, spread 0, period None, t_settle 0.0

### 009 - claim @0.35: rest holds at 717 for the whole 180 s (memory, not clock drift); a step within 3 min is unlikely -> yes

**why:** Run 9: no commands for 180 s. Rest ratcheted 715->716->717 around runs 006-008 but stayed 715 after 003's 29 s of drive, so it is not simply cumulative x. Tests whether rest drifts with wall-clock time when undriven (a step would appear within 3 min) or holds where drive left it.

**cmds:** `(none)` for 180.0 s

**prediction:** rest holds at 717 for the whole 180 s (memory, not clock drift); a step within 3 min is unlikely

**observed:** start 717.0, final 717, steady 717, min 717, max 717, range 0, spread 0, period None, t_settle 0.0

**update:** YES as worded, but I attached 0.35 to a claim I actually believed at ~0.65 (I had meant to bet on a step). Scored as written; a calibration error on my side, not the system's. Finding: rest holds at exactly 717 for 180 s undriven (8980 identical samples), and CSV timestamps show no clock-driven drift over 17:21-17:31. The rest level is state left behind by drive: 715 through 006, 716 after 006's pulses, 717 after 007's 10 s at 255. Yet 003's 29 s at 255 left rest at 715 (004 start). So it is not a simple integral of x. Hypothesis: persistent state moves only under some condition (stiction-like), and z may set the direction. Test: z=1, x=255 (010).

### 010 - claim @0.45: z reverses the persistent shift: final (last 1 s, undriven) is below 717 -> yes

**why:** Run 10: z=1 then x=255 for 10 s, then x=0 for 20 s. Same drive as 007 but with z=1. 007 left the rest level 1 higher (716->717); if z sets a direction, this should leave it lower. z had no effect at x=128 (005) or alone (004).

**cmds:** `z 1 @1; x 255 @2; x 0 @12` for 32.0 s

**prediction:** z reverses the persistent shift: final (last 1 s, undriven) is below 717

**observed:** start 717.0, final 715, steady 715, min 628, max 720, range 92, spread 0, period None, t_settle 0.44

**update:** YES. Big result: with z=1, x=255 drives y from 717 down to 672 (-45), via a +3 spike then an undershoot to 628, settling in ~0.5 s. On release y returns to 715, 2 below the run's start: z=1 drive moved the rest level DOWN. So z sets polarity, the response is very asymmetric (z=0: +1..2 at 255; z=1: -45 at 255), and z=1/x=128 gave nothing (005), so the z=1 response is thresholded or strongly nonlinear in x between 128 and 255. Fast dynamics: settles in ~0.5 s with overshoot at onset and t_settle 0.44 s at release.

### 011 - steady in [690.0, 718.0] @0.65 -> 551 MISS

**why:** Run 11: z=1, x=192 held to the end of the run. 010 gave -45 at x=255 with z=1; 005 gave ~0 at x=128 with z=1. Locates the nonlinearity between 128 and 255. Holding x to the end so 'steady' measures the driven level.

**cmds:** `z 1 @1; x 192 @2` for 12.0 s

**prediction:** between the two: a linear-from-128 model gives ~694, a steep power law ~710, a threshold above 192 gives ~717

**observed:** start 715.0, final 630, steady 551, min 271, max 834, range 563, spread 303, period 0.872, t_settle None

**update:** MISS by 139. x=192 with z=1 does not sit between the x=128 (nothing) and x=255 (-45, stable) responses: y oscillates wildly, 271..834, period ~0.87 s, with a slow envelope (down to ~370 around t=8, back to ~600 by t=11). Above AND below rest. So the z=1 branch is not monotone in x: there is an oscillatory regime somewhere around 192 that 255 does not show. Ledger at 10 runs: metric hits 4/4 (underconfident, small n), claims Brier 0.38 (coin-flip): my claims are poorly worded/priced. Action: repeat 011 exactly before trusting it (012).

### 012 - range in [350.0, 700.0] @0.6 -> 416 HIT

**why:** Run 12: exact repeat of 011 (z=1, x=192 held, 12 s). 011 showed large oscillation (range 563, period ~0.87 s) where 010 (x=255) was smooth and 005 (x=128) was flat. Repeat before trusting: does the oscillation recur with the same amplitude and period?

**cmds:** `z 1 @1; x 192 @2` for 12.0 s

**prediction:** the oscillation recurs; range comparable to 011's 563 (model: unstable regime near x=192, z=1)

**observed:** start 714.0, final 401, steady 435, min 300, max 716, range 416, spread 351, period 1.64, t_settle None

**update:** HIT (range 416). The oscillatory regime at x=192, z=1 is reproducible in kind but not in detail: 011 range 563 / period 0.87 s, 012 range 416 / period 1.64 s, both with a slow envelope of several seconds and mean ~500-540 (011: 538, 012: ~500). Waveform is irregular (lag-1 autocorr 0.93, spectrum power spread below 1.5 Hz): more like a noisy or chaotic regime than a clean oscillator. Rest level fell again: 715 (011 start) -> 714 (012 start). Regime map for z=1 so far: 128 flat, 192 oscillating, 255 smooth -45. Next: 224 (013), then 160.

### 013 - range in [30.0, 150.0] @0.5 -> 506 MISS

**why:** Run 13: z=1, x=224 held 12 s. Maps the z=1 regime between 192 (oscillating, 011/012) and 255 (smooth -45, 010). Is the boundary sharp, and on which side is 224?

**cmds:** `z 1 @1; x 224 @2` for 12.0 s

**prediction:** 224 behaves like 255: smooth drop with an onset undershoot; range ~50-150 (010 gave 92). If it oscillates instead, range >350 and this misses.

**observed:** start 714.0, final 418, steady 463, min 300, max 806, range 506, spread 426, period 0.821, t_settle None

**update:** MISS by 356. x=224, z=1 oscillates like 192 (range 506, period ~0.8 s, mean ~550, slow envelope). So the oscillatory regime spans at least 192-224 and the smooth -45 at 255 (010) is the outlier. Two candidates: (a) 255 is special because it is the only x with no ripple (002/003 showed ripple at 128, none at 255): the oscillation may need the switching; prediction: 254 oscillates, 255 does not; (b) 010 was a one-off. Rest level: 714 before and (from 013 start) unchanged by 012. Next: repeat 255 with z=1 (014), then 254 (015).

### 014 - range in [30.0, 150.0] @0.55 -> 331 MISS

**why:** Run 14: repeat of 010's drive (z=1, x=255) held 12 s. 011-013 oscillate at 192 and 224, so 010's smooth -45 must be repeated before I trust that 255 is a distinct regime.

**cmds:** `z 1 @1; x 255 @2` for 12.0 s

**prediction:** 010 reproduces: smooth drop to ~R-45 with onset undershoot, range 50-150 (010: 92). If it oscillates, range >350.

**observed:** start 710.0, final 676, steady 676, min 382, max 713, range 331, spread 2, period None, t_settle 0.72

**update:** MISS on range (331) but the regime reproduced: x=255,z=1 settles smooth and flat (steady 676, spread 2), unlike 192/224. The miss came from the onset undershoot, which is much deeper this time (min 382 vs 628 in 010): the transient is variable, the settled level is not. Driven level is ABSOLUTE: 672 (010, R=717) and 676 (014, R=710), so y under 255/z=1 goes to ~674+/-3 regardless of rest level. New: rest fell 714->710 after 013 and now jitters 709/710, the first noise ever seen at rest (as if sitting on a quantisation edge, or something has changed). Next: x=254 (015) tests whether 255 is special because it has no switching ripple.

### 015 - range in [350.0, 700.0] @0.5 -> 333 MISS

**why:** Run 15: z=1, x=254 held 12 s. 255 is smooth (010, 014) while 192 and 224 oscillate (011-013). 255 is also the only x with no ripple (003 vs 002). If the oscillation needs the switching, 254 should oscillate; if the boundary is a threshold in x between 224 and 255, 254 should be smooth.

**cmds:** `z 1 @1; x 254 @2` for 12.0 s

**prediction:** the no-switching hypothesis: 254 oscillates like 224, range >350

**observed:** start 715.0, final 680, steady 680, min 384, max 717, range 333, spread 18, period None, t_settle 0.8

**update:** MISS by 17 (range 333, but the real answer is 'smooth'): x=254,z=1 settles flat at 680 (spread 18 from one glitch), like 255. The no-switching hypothesis is rejected; the boundary between oscillating (<=224) and smooth (>=254) is a threshold in x. Driven levels: 672 (255), 676 (255), 680 (254): absolute, ~676+/-4. Rest jumped 710 -> 715 between 014 and 015 without an undriven interval I observed: 255/z=1 drives leave rest at 715 (010, 014), oscillating drives leave it lower (714, 714, 710), z=0 drives left it higher (716, 717). Range is a poor discriminator because the onset undershoot varies (min 382-628); use spread (last 3 s) instead. Next: x=240 (016).

### 016 - spread in [0.0, 25.0] @0.5 -> 372 MISS

**why:** Run 16: z=1, x=240 held 12 s. Bisects the oscillating/smooth threshold, known to lie between 224 (013, oscillates) and 254 (015, smooth). Predicting spread (last 3 s) because range is dominated by the variable onset undershoot.

**cmds:** `z 1 @1; x 240 @2` for 12.0 s

**prediction:** 50/50; smooth regime gives spread <= 25 (015: 18, 014: 2), oscillating gives >300

**observed:** start 714.0, final 691, steady 633, min 333, max 812, range 479, spread 372, period 0.414, t_settle None

**update:** MISS (spread 372): x=240, z=1 oscillates. Threshold now in (240, 254). Character differs from 192/224: at 240 y spends time near 680 (the smooth level) and breaks away in bursts down to ~380, i.e. intermittent, with a faster component (period 0.41 s by crossings). Suggests the oscillation is a loss of stability of the smooth level that becomes intermittent close to the boundary. Next: 248 (017).

### 017 - spread in [0.0, 25.0] @0.5 -> 350 MISS

**why:** Run 17: z=1, x=248 held 12 s. Threshold between oscillating (240, run 016) and smooth (254, run 015). 016 showed intermittent bursts near the smooth level, so close to the threshold the last 3 s may be quiet by chance; still predicting spread.

**cmds:** `z 1 @1; x 248 @2` for 12.0 s

**prediction:** 50/50 on which side; smooth gives spread <= 25, bursts give >100

**observed:** start 710.0, final 683, steady 595, min 319, max 755, range 436, spread 350, period 0.352, t_settle None

**update:** MISS (spread 350): x=248, z=1 oscillates fully (range 436, mean ~520), not intermittent like 240. Threshold now in (248, 254): the smooth regime is a narrow band at the very top of x. My three 0.5 bisection bets all missed on the 'smooth' side; from here I lean oscillating until proven otherwise. Rest before this run: 710 (after 016's oscillation), consistent with oscillating drives leaving rest low. Next: 251 (018).

### 018 - spread in [100.0, 600.0] @0.6 -> 226 HIT

**why:** Run 18: z=1, x=251 held 12 s. Threshold between 248 (017, oscillates) and 254 (015, smooth). 240 and 248 both oscillate fully, so the smooth band looks narrow and I now lean oscillating.

**cmds:** `z 1 @1; x 251 @2` for 12.0 s

**prediction:** oscillates: spread in the last 3 s >100 (011-013, 016, 017 gave 303-426)

**observed:** start 436.0, final 681, steady 681, min 383, max 780, range 397, spread 226, period 0.359, t_settle None

**update:** HIT (spread 226), but the run opened on a surprise: at x=0 y was 458 falling to ~411 over 2 s, nowhere near any rest level seen before (709-717). Run 017 (x=248, oscillating) ended at ~640-690 and the program set x=0; the rest 1.5 min later was ~436 and still drifting. So release from the oscillating regime does NOT return to 715; it can leave y hundreds lower, and drifting. Under x=251 y sat at ~681 (the smooth level) with intermittent dips (mean 664, sd 46): 251 is the near-threshold intermittent case; the boundary is in (251, 254). Priority now: observe the undriven state (019) before any more drive.

### 019 - start in [700.0, 720.0] @0.35 -> 431.5 MISS

**why:** Run 19: no commands, 40 s. 018 opened at y~436 and drifting at x=0, after 017 ended in oscillation; 018 ended at ~681 under 251/z=1. Where is the rest level now, and is it drifting? Look before driving again.

**cmds:** `(none)` for 40.0 s

**prediction:** rest is no longer at 715; it sits well below (018's start was 436, and 018 ended at 681 under drive) and may still be moving

**observed:** start 431.5, final 466, steady 394, min 358, max 505, range 147, spread 128, period 7.658, t_settle None

**update:** MISS by 268: undriven, y is NOT at rest. With x=0, z=0 for 40 s it oscillates 360..505 with a very regular period of 7.66 s (sawtooth-like: slow rise ~4 s, faster fall). This is self-sustained: no input at all. Earlier rest (001-017 starts) was a flat fixed point. Explanation on offer: two coexisting states at x=0, a fixed point near 715 and a slow limit cycle around ~430; the oscillating drive of 017 (x=248) and release left the system on the cycle. Test: 255/z=1 drive returned rest to 715 flat in 010 and 014; try it once (020). If the flat rest does not come back I stop, as the rules require for an unexplained persistent change.

### 020 - spread in [0.0, 10.0] @0.5 -> 66 MISS

**why:** Run 20: recovery attempt. z=1, x=255 for 8 s, then x=0 and watch 30 s. 019 showed a self-sustained 7.7 s oscillation at rest after 017's oscillating drive. In 010 and 014 a 255/z=1 drive left rest flat at 715. If the flat rest returns, the two-state (fixed point vs limit cycle) explanation holds and I continue; if not, I stop.

**cmds:** `z 1 @1; x 255 @2; x 0 @10` for 40.0 s

**prediction:** flat rest restored after release: spread over the last 3 s <= 10 (two-state hypothesis; 010/014 both returned to 715)

**observed:** start 488.5, final 482, steady 502, min 337, max 715, range 378, spread 66, period 7.58, t_settle None

**update:** MISS (spread 66). Recovery failed on both counts: under 255/z=1 y did not settle at the smooth level ~676 (010, 014, 015) but wandered irregularly 370-667; after release the slow cycle continued (period 7.58 s, 365..513), same as 019. So the change is not just a second attractor at x=0 reachable by the right drive: the driven response has changed as well. The system's behaviour has changed in a way that persists across runs (018-020) and my explanation failed its test. Stopping now, as the rules require.
