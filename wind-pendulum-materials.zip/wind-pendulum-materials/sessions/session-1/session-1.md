# session-1.md — 20 runs, stopped by rule

Stopped after run 020 because the system's behaviour changed in a way that persisted across runs
018–020 and that I could not explain. Details in the last section.

## The model as it stands (fitted on 001–017; see model.md)

y depends on z as a switch between two branches, and on a rest level R that persists between runs.

**z=0 (runs 002, 003, 006, 007): nearly inert.** y = R + F0(x) + ripple(x), with F0(255) = +1.5 ± 0.5,
F0(128) = +0.3 ± 0.2, a +3 onset spike lasting ~0.3 s at a 0→255 step, and a small aliased ripple
(sd 0.6 at x=128, 0.25 at 255, 0 at rest).

**z=1 (runs 005, 010–018): three regimes in x.**
| x | regime | y while driven | runs |
|---|---|---|---|
| 128 | flat | R | 005 |
| 192–248 | oscillating | irregular, mean ~530 ± 40, sd ~100, excursions 270–835, crossing period 0.35–1.6 s with a 5–9 s envelope | 011, 012, 013, 016, 017 |
| 251 | intermittent | mostly ~681 with dips | 018 |
| 254–255 | smooth | absolute level 676 ± 4 within ~0.6 s, after an onset undershoot of variable depth (382–628) | 010, 014, 015 |

Thresholds for z=1: (128, 192) and (251, 254). The smooth band at the top of x is narrow.
Release from the smooth regime returns y to 715 in ~0.5 s (010, 014); release from the oscillating
regime does not (017→018).

**Rest level R.** Holds exactly for minutes when undriven (009: 180 s at 717) and is left at
different values by different drives: z=0 drives raised it 715→716→717; 255/z=1 drives left it at 715;
oscillating drives left it at 710–714. No rule found for the amount.

**Numbers measured vs guessed.** All parameters above are measured. Guesses: that z=0 never oscillates
(never tested at 192–254); the flat→oscillating threshold near 160; that the smooth level is
independent of x above 254 (only 254 and 255 seen: 680 vs 672–676).

## What surprised me, in order

1. **Static x does almost nothing with z=0** (002, 003): +1 to +2 units at x=255 out of a 1023 range.
   I spent five runs before finding the interaction.
2. **The rest level is state** (007–009): it moves by 1–2 units after drive and then holds for minutes
   with zero noise. Not ambient drift (CSV timestamps rule out a clock trend).
3. **z=1 with x=255 pulls y down 45 units, smoothly** (010) — and **z=1 with x=192 makes y swing by 560**
   (011). The z=1 branch is not monotone in x: an oscillating regime sits between a flat one and a
   smooth one.
4. **The smooth band is only x ≥ 254** (013–018). Four bisection runs at 0.5 confidence all landed on
   the oscillating side, which is why the range/spread metric scorecard reads 0/6 below 0.5.
5. **After run 017 the system did not come back** (018–020): at x=0 it oscillates 360–510 with a clean
   7.6 s period, and under 255/z=1 the smooth 676 level no longer appears.

## Scorecard (py -3 play.py ledger, after run 020)

```
runs: 20 | this session: 20 of ceiling 100
metric predictions: 14 | hits 6 (43%) | mean stated confidence 0.56 | overconfident (-0.13)
  by stated confidence: <=0.50: 0/6 hit | 0.50-0.70: 5/7 hit | 0.70-0.90: 1/1 hit
  by metric (hits/n, mean interval width -- narrow and right is the goal): max 1/1, w=7.0 | range 1/4, w=235.0 | spread 1/4, w=140.0 | start 1/2, w=10.5 | steady 2/3, w=20.7
  mean |observed - interval midpoint|: 162.4
claims judged: 6 | Brier 0.380 (0 = perfect, 0.25 = coin-flip) | mean confidence 0.54 | realised yes-rate 0.33
```

Reading it honestly: overconfident by 0.13 overall. The 0.5-confidence bets (six of them) were regime
coin-flips that all fell the same way, and two late metric predictions (019, 020) were bets that the
old model still applied when it did not. Claims scored at coin-flip level; three of six early claims
were "y moves by more than 20" bets made before I had found the z=1 branch, and one (009) was worded
opposite to what I meant and scored as written. Interval widths for range and spread (235, 140) are
wide because the onset undershoot varies by 250 units between repeats; spread in the last 3 s was the
better discriminator once I switched to it.

## Why I stopped

Rule: stop at once if behaviour changes in a way that persists across runs and cannot be explained.
- 018 opened at y ≈ 436 and falling, at x=0, where every earlier run opened at 709–717.
- 019 (no commands, 40 s): self-sustained oscillation 360–505, period 7.66 s, regular.
- 020 (255/z=1 then release): the smooth 676 level did not appear (y wandered 370–667); after
  release the 7.58 s cycle continued.
My candidate explanation — a second undriven attractor (limit cycle) reachable from the oscillating
regime, with 255/z=1 as the way back — failed its one test in 020, because the driven response changed
as well. I did not run more. The change followed run 017 (x=248, z=1, 10 s in the oscillating regime,
released to x=0 at the end of the run); whether it was caused by that run or by the accumulated
oscillating drive of 011–017 (about 60 s in total) I cannot say.

## The three runs I would do next (if Albert says the system is safe to drive)

1. **No commands, 120 s.** Is the 7.6 s cycle still there after a long rest, and is its period and
   amplitude drifting? Predict: period 7.6 ± 0.3 s, range 130–170 (0.6).
2. **z=0, x=255 for 10 s, then 30 s undriven.** The z=0 branch was inert before; if the cycle is a
   mechanical/thermal state, a z=0 push may damp it or shift it. Predict: cycle persists, spread over
   last 3 s > 50 (0.6).
3. **z=1, x=128 for 10 s, then 30 s undriven.** The one z=1 value that was flat before. Predict:
   cycle persists (0.6). If any of these restores a flat rest, that is the way back and the two-state
   model returns; if none does, the change is a different kind of thing and the file should say so.

Analysis scripts used: `runs/play/analysis/edges.py` (fine transients), `ripple.py` (spectra),
`summary.py` (per-run table).
