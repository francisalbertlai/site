"""Print y around command edges and slow stats for given run ids.
Usage: py -3 runs/play/analysis/inspect.py 002 003 [--win 1.0]
Reads runs/play/<id>.csv (t,x,z,y). Writes nothing."""
import sys, os, csv
import numpy as np
base = os.path.join(os.path.dirname(__file__), '..')
args = sys.argv[1:]
ids = [a for i, a in enumerate(args) if not a.startswith("--") and (i == 0 or args[i-1] != "--win")]
win = 1.0
if '--win' in sys.argv: win = float(sys.argv[sys.argv.index('--win')+1])
for rid in ids:
    p = os.path.join(base, f'{rid}.csv')
    d = np.genfromtxt(p, delimiter=',', names=True)
    t, x, z, y = d['t'], d['x'], d['z'], d['y']
    print(f'=== run {rid}: {len(t)} samples, t {t[0]:.2f}..{t[-1]:.2f}')
    # edges where x or z change
    dx = np.flatnonzero(np.diff(x) != 0) + 1
    dz = np.flatnonzero(np.diff(z) != 0) + 1
    edges = sorted(set(dx.tolist()) | set(dz.tolist()))
    for e in edges:
        te = t[e]
        print(f'-- edge at t={te:.2f}: x {x[e-1]:.0f}->{x[e]:.0f} z {z[e-1]:.0f}->{z[e]:.0f}')
        m = (t >= te - win/2) & (t <= te + win)
        print('   t:', ' '.join(f'{v:.2f}' for v in t[m]))
        print('   y:', ' '.join(f'{v:.0f}' for v in y[m]))
    # 2 s-bin means to see slow drift
    print('-- 2 s bin means (t_mid, mean y, sd y):')
    for t0 in np.arange(t[0], t[-1], 2.0):
        m = (t >= t0) & (t < t0 + 2)
        if m.sum(): print(f'   {t0+1:6.1f}  {y[m].mean():8.3f}  {y[m].std():6.3f}  x={x[m].mean():.0f} z={z[m].mean():.0f}')
