"""One line per run: start (rest), x/z used, driven-segment mean/sd, last value.
Usage: py -3 runs/play/analysis/summary.py. Reads runs/play/*.csv and ledger.jsonl. Writes nothing."""
import os, glob, json
import numpy as np
base = os.path.join(os.path.dirname(__file__), '..')
cmds = {}
for line in open(os.path.join(base, 'ledger.jsonl'), encoding='utf-8'):
    d = json.loads(line)
    if d.get('kind') == 'predict': cmds[d['id']] = d['cmds']
print(f"{'id':>4} {'start':>6} {'end':>5} {'xmax':>4} {'z':>1} {'drv_mean':>8} {'drv_sd':>7} {'drv_n':>5}  cmds")
for p in sorted(glob.glob(os.path.join(base, '[0-9][0-9][0-9].csv'))):
    rid = os.path.basename(p)[:3]
    d = np.genfromtxt(p, delimiter=',', names=True)
    t, x, z, y = d['t'], d['x'], d['z'], d['y']
    start = np.median(y[t <= 0.5]); end = y[-1]
    m = x == x.max()
    if x.max() > 0:
        # driven segment excluding first 1 s after each onset
        onset = np.flatnonzero(np.diff((x == x.max()).astype(int)) == 1) + 1
        keep = m.copy()
        for o in onset: keep &= ~((t >= t[o]) & (t < t[o] + 1.0))
        dm, ds, dn = (y[keep].mean(), y[keep].std(), keep.sum()) if keep.sum() else (np.nan, np.nan, 0)
    else:
        dm, ds, dn = np.nan, np.nan, 0
    print(f"{rid:>4} {start:6.1f} {end:5.0f} {x.max():4.0f} {z.max():1.0f} {dm:8.1f} {ds:7.1f} {dn:5d}  {cmds.get(rid,'')}")
