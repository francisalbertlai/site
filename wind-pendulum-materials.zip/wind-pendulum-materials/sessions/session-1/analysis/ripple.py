"""Spectrum of y over a steady segment. Usage: py -3 runs/play/analysis/ripple.py <id> <t0> <t1>
Reads runs/play/<id>.csv, prints top spectral peaks of (y - mean) in [t0,t1]. Writes nothing."""
import sys, os
import numpy as np
base = os.path.join(os.path.dirname(__file__), '..')
rid, t0, t1 = sys.argv[1], float(sys.argv[2]), float(sys.argv[3])
d = np.genfromtxt(os.path.join(base, f'{rid}.csv'), delimiter=',', names=True)
m = (d['t'] >= t0) & (d['t'] <= t1)
t, y = d['t'][m], d['y'][m]
fs = 1.0 / np.median(np.diff(t))
yy = y - y.mean()
print(f'run {rid} [{t0},{t1}] n={len(y)} fs={fs:.2f} Hz mean={y.mean():.3f} sd={yy.std():.3f}')
# value histogram
vals, cnts = np.unique(y, return_counts=True)
print('histogram:', ', '.join(f'{int(v)}:{c}' for v, c in zip(vals, cnts)))
# autocorrelation at small lags
ac = [np.corrcoef(yy[:-k], yy[k:])[0,1] for k in range(1, 26)]
print('autocorr lags 1..25 samples:', ' '.join(f'{a:+.2f}' for a in ac))
F = np.abs(np.fft.rfft(yy * np.hanning(len(yy))))
f = np.fft.rfftfreq(len(yy), 1/fs)
top = np.argsort(F)[::-1][:8]
print('top peaks (Hz, amp):', ' '.join(f'{f[i]:.2f}:{F[i]:.1f}' for i in sorted(top)))
