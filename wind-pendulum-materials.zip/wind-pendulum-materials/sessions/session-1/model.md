# model.md — current model of the system

## State after run 020 (session stopped here)

The model below was fitted on runs 001–017 and held there. From run 018 on, the system's
behaviour changed persistently (see boundaries.md, last entries) and the model no longer applies.

### Structure
y depends on z as a switch between two very different branches, plus a persistent rest level R.
Time constants: fast (≤0.6 s) for drive response; R holds for minutes.

### Branch z=0 (runs 002, 003, 006, 007) — nearly inert
y = R + F0(x) + ripple(x)
- F0(255) = +1.5 ± 0.5 (003: +1, 007: +2); F0(128) = +0.3 ± 0.2 (002, 005 bin means)
- onset spike +3 for ~0.3 s at a 0→255 step (003, 006 HIT)
- ripple sd 0.6 at x=128 (lines 3.8/9.8/13.6 Hz), 0.25 at 255, 0 at rest

### Branch z=1 — three regimes in x (runs 005, 010–018)
| x | regime | y while driven | evidence |
|---|---|---|---|
| 128 | flat | R (+ripple as z=0) | 005 |
| 192–248 | oscillating | irregular, mean 500–550 (240: 605), sd 85–110, excursions 270–835, crossing periods 0.35–1.6 s plus a slow envelope of 5–9 s | 011, 012, 013, 016, 017 |
| 251 | intermittent | mostly at ~681 with dips; mean 664, sd 46 | 018 |
| 254–255 | smooth | absolute level 676 ± 4 (672, 676, 680) in ~0.6 s after a variable onset undershoot (min 382–628) | 010, 014, 015 |

Thresholds for z=1: flat→oscillating in (128, 192); oscillating→smooth in (251, 254).
Release from the smooth regime returns y to 715 in ~0.5 s (010, 014). Release from the
oscillating regime does not (017→018).

### Rest level R (runs 001–017)
Holds exactly for minutes when undriven (009: 180 s). Left at different values by different drives:
z=0 drives 715→716→717; 255/z=1 drives → 715; oscillating drives → 714, 714, 710, 714, 710.

## Parameters
| name | value | uncertainty | fitted on | tested on | residual |
|---|---|---|---|---|---|
| R home | 715 | 0 | init, 001 | 010, 014, 015 returns | 0 |
| F0(255) | +1.5 | ±0.5 | 003, 007 | 006 | ≤1 |
| F0(128) | +0.3 | ±0.2 | 002, 005 | — | — |
| smooth level (z=1, x≥254) | 676 | ±4 | 010, 014 | 015 | +4 |
| settle time (smooth) | 0.6 s | ±0.2 | 010, 014, 015 | — | — |
| oscillation mean (192–248) | 530 | ±40 | 011–013, 017 | 016 (605: +75, near threshold) | — |
| oscillation range (12 s) | 416–563 | — | 011, 013 | 012 HIT | — |
| self-oscillation at rest (post-018) | 360–510, period 7.6 s | ±0.1 s | 019 | 020 (7.58 s) | 0.08 s |

## What the model predicted for untried commands (as of run 017; untested)
- z=0 at any x: flat, R + ≤2. Never tested at 192–254.
- z=1 at 160: flat or oscillating, 50/50.
- Long hold at 255/z=1 (60 s+): stays at 676 (0.7).

## Open questions (ranked)
1. What changed at 017→018, and is it reversible? (Highest value; cannot be answered without further drive, which the stop rule forbids me from doing now.)
2. Is the 7.6 s self-oscillation a second attractor that always existed, or new?
3. Does z=0 ever oscillate?
4. Exact thresholds for z=1 (128–192 and 251–254).
5. Is the driven oscillation deterministic (chaotic) or noise-driven?
