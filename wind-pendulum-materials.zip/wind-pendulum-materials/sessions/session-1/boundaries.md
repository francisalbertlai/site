# boundaries.md — edges of the model

- **z is a switch between two branches, not a small effect (010; sure).** z=0: x barely moves y (≤2 units at 255). z=1: x above ~128 moves y by hundreds.
- **Oscillating regime in z=1 for x in [192, 248] (011–013, 016, 017; sure).** y swings 270–835, irregular, crossing period ~0.4–1.6 s with a slow envelope. Reproducible in kind, not in detail (range 416–563 at 192).
- **Smooth regime in z=1 for x in [254, 255] (010, 014, 015; sure).** Flat absolute level ~676. Boundary with the oscillating regime lies in (251, 254): a threshold in x, not a switching artefact (015 killed that). 251 is intermittent (018).
- **Onset transient at 254/255, z=1 is variable (010: min 628; 014: 382; 015: 384).** Not predictable; the settled level is.
- **Persistent rest level (007–017; sure).** Rest holds for minutes but is left at different values by different drives (710–717). First rest-level noise seen at 014 start (709/710).
- **Ripple depends on x non-monotonically** (002/005 vs 003): largest near 128, ~none at 255. Fairly sure.
- **Release from the oscillating regime does not return y to 715 (017→018; sure).** Unlike release from the smooth regime (010, 014 → 715).
- **Self-sustained oscillation at rest (018 opening, 019, 020; sure).** After run 017 was released to x=0, y never returned to a fixed rest level: at x=0 it oscillates 360–510 with period 7.6 s, regular, with no input, for the rest of the session (≥ 3 min across 018–020).
- **The driven response changed too (020; sure).** Under 255/z=1, which gave a flat 676 in 010/014/015, y wandered 370–667 irregularly. So this is not merely a second undriven attractor. **Unexplained persistent change across runs 018–020: session stopped here.**
