# Play ledger

*Rendered 2026-09-06T21:43. Append-only source: `ledger.jsonl`.*

## Scorecard

```
runs: 52 | this session: 32 of ceiling 100 | regime 4
trace predictions: 18 | mean skill 0.26 | best 0.81 | worst -0.55  (1 = perfect, 0 = 'nothing happens')
regimes declared: 3 (each is a claim that the system changed; the record above is the overall one)
  regime 1: 14 metric predictions, hits 6 (43%), mean stated confidence 0.56 (-0.13)
  regime 3: 19 metric predictions, hits 12 (63%), mean stated confidence 0.58 (+0.06)
  regime 4: 6 metric predictions, hits 3 (50%), mean stated confidence 0.57 (-0.07)
metric predictions: 39 | hits 21 (54%) | mean stated confidence 0.57 | calibrated so far (-0.03)
  by stated confidence: <=0.50: 3/14 hit | 0.50-0.70: 16/23 hit | 0.70-0.90: 2/2 hit
  by metric (hits/n, mean interval width -- narrow and right is the goal): final 7/9, w=13.3 | max 1/1, w=7.0 | min 0/1, w=16.0 | period 0/2, w=3.2 | range 2/6, w=158.8 | spread 5/10, w=210.1 | start 1/2, w=10.5 | steady 5/8, w=22.6
  mean |observed - interval midpoint|: 90.3
claims judged: 13 | Brier 0.333 (0 = perfect, 0.25 = coin-flip) | mean confidence 0.53 | realised yes-rate 0.38
```

## Sessions

- 2026-09-06T17:21:06 - session 1 begins; ceiling 100
- 2026-09-06T17:41:15 - session 1 stopped by choice after 20 runs: Stopping at 20 runs by rule: the system's behaviour changed persistently at 017->018 (self-sustained 7.6 s oscillation at x=0; smooth 255/z=1 regime gone in 020) and my two-state explanation failed its test in 020. Model for runs 001-017 is in model.md; the change and the evidence are in boundaries.md and session-1.md.
- 2026-09-06T20:50:00 - regime 2 declared after run 020: Albert: serviced between sessions 1 and 2
- 2026-09-06T20:58:55 - regime 3 declared after run 020: Albert: serviced between sessions 1 and 2
- 2026-09-06T21:01:21 - session 2 begins; ceiling 100
- 2026-09-06T21:33:51 - regime 4 declared after run 045: Regime 4 declared after run 045. Since 043 (a fast 255->0 ramp with z=1 through the oscillating region) the system rests on a slow limit cycle instead of a fixed point (044: 588-782, period 4.7 s; 045 tail: 420-570, irregular 6-8 s) and a 255/z=1 step no longer gives the smooth 669 level (045: intermittent 647-662 with sd 17-36), where 023, 026, 027, 033, 036, 040, 041, 043 all did. Same signature as regime 2 (018-020). The regime-3 model B stays in model.md as the record; the question now is whether any command restores it.

## Runs

### 001 - steady in [708.0, 722.0] @0.85 -> 715 HIT

**why:** Run 1: baseline with no commands, to measure y's noise and drift at x=0,z=0. init showed y=715 constant over 3 s.

**cmds:** `(none)` for 10.0 s

**prediction:** y stays near 715; noise is small

**observed:** start 715.0, final 715, steady 715, min 715, max 715, range 0, spread 0, period None, t_settle 0.0

**update:** Baseline established: y=715 exactly at x=0,z=0 with zero noise over 10 s (500 samples identical). Model so far: y_rest = 715 +/- 0 (measured). Noise floor at rest is 0 y-units; any deviation under drive is signal, not noise (unless noise is input-dependent).

### 002 - claim @0.8: y moves away from 715 by more than 20 units in steady state; direction unknown -> no

**why:** Run 2: first drive. Step x=128 at t=1 and hold, to learn whether y responds, in which direction, how fast, and whether noise appears under drive. Follows 001 (rest = 715, no noise).

**cmds:** `x 128 @1` for 15.0 s

**prediction:** y moves away from 715 by more than 20 units in steady state; direction unknown

**observed:** start 715.0, final 715, steady 715, min 714, max 717, range 3, spread 2, period None, t_settle 0.0

**update:** MISS. x=128 held 14 s: steady stays 715, no shift in mean at all. But noise appeared: y jitters 714-717 under drive versus exactly 715 at rest. So x does reach the system, but at 128 its effect on the mean is below ~1 unit. Hypotheses: (a) threshold in x above 128, (b) very slow response (>14 s), (c) x only matters when z=1, (d) x mainly modulates noise. Next: x=255 for 30 s.

### 003 - steady in [705.0, 725.0] @0.55 -> 716 HIT

**why:** Run 3: maximum x=255 held 30 s, to test whether x=128 in 002 was below a threshold or the response is slow. If mean still stays at 715, x likely needs z=1 or only modulates noise. Expect jitter larger than 002's +/-2 if noise scales with x.

**cmds:** `x 255 @1` for 30.0 s

**prediction:** mean barely moves as in 002; steady stays near 715 (from 002 null result), modest chance of a real shift

**observed:** start 715.0, final 716, steady 716, min 715, max 718, range 3, spread 1, period None, t_settle 0.0

**update:** x=255 held 29 s: steady 716, i.e. +1 over rest, jitter 715-718 (smaller than at 128, oddly: spread 1 vs 2). No slow drift over 29 s. With z=0, x's effect on the mean is at most ~1 unit across the full range: gain_z0 <= 1/255 per unit x. Threshold and slow-response hypotheses are now unlikely for z=0. Leading hypothesis: z=1 enables x. Next: z=1 alone (004), then z=1 with x.

### 004 - claim @0.5: z=1 alone shifts steady y away from 715 by more than 20 units -> no

**why:** Run 4: z=1 alone with x=0, 15 s. 002 and 003 showed x barely moves y when z=0, so z is the next variable. Does z by itself change y?

**cmds:** `z 1 @1` for 15.0 s

**prediction:** z=1 alone shifts steady y away from 715 by more than 20 units

**observed:** start 715.0, final 715, steady 715, min 715, max 715, range 0, spread 0, period None, t_settle 0.0

**update:** MISS. z=1 with x=0 leaves y at exactly 715, zero jitter. z alone is invisible. Remaining hypothesis for a large effect: z gates x (interaction term). Next: z=1 with x=128.

### 005 - claim @0.6: with z=1, x=128 shifts steady y away from 715 by more than 20 units -> no

**why:** Run 5: z=1 then x=128, 20 s. 002/003 (x alone, z=0) moved the mean by <=1; 004 (z alone) did nothing. Tests the interaction: does z=1 enable x?

**cmds:** `z 1 @1; x 128 @2` for 20.0 s

**prediction:** with z=1, x=128 shifts steady y away from 715 by more than 20 units

**observed:** start 715.0, final 715, steady 715, min 714, max 717, range 3, spread 3, period None, t_settle 0.0

**update:** MISS. z=1 + x=128: steady 715, jitter 714-717, indistinguishable from 002 (z=0, x=128). z has no visible effect on the static response. Static gain of x on the mean is ~0 to +1 unit over the full range, for both z. The jitter is the only clear signature of x. Hypotheses left: (a) y responds to changes in x (derivative / AC coupling / pulses), (b) very slow integrating response (thermal-like) needing minutes, (c) x sets noise amplitude only. Next: inspect 50 Hz CSVs around the steps for fast transients, then a pulse train run.

### 006 - max in [717.0, 724.0] @0.6 -> 719 HIT

**why:** Run 6: pulse train x=255, 0.5 s on / 0.5 s off, 10 pulses. Static x barely moves the mean (002-005) but 003's edge analysis showed a fast +3 spike at the step. Tests whether y responds to changes in x rather than its level, and whether repeated edges accumulate.

**cmds:** `pulse x=255 on=0.5 off=0.5 n=10 @1` for 15.0 s

**prediction:** each edge gives a spike like 003's (+3); max stays a few units above 715 unless edges accumulate

**observed:** start 715.0, final 716, steady 716, min 715, max 719, range 4, spread 0, period None, t_settle 0.0

**update:** HIT (max 719). Pulses of x=255: y ~717-719 while on, 716 while off, and 716 persists for 4+ s after the last pulse (rest was 715). Peaks grow 717->719 over the train: a slow component accumulates. Ripple analysis (002,005): at x=128 spectral lines at 3.8/9.8/13.6 Hz, sd 0.5-0.7; at x=255 none (sd 0.28). Looks like aliased ripple, largest at mid x. Model sketch: y = 715 + fast(x) + slow, fast(255) ~ +2 (spike +3 at edge), slow builds to ~+1 in seconds and decays slowly. Next: 10 s at 255 then 50 s of decay (007).

### 007 - claim @0.55: the offset decays: median of last 1 s is back at 715 by t=60 -> no

**why:** Run 7: x=255 for 10 s then x=0 for 50 s, to measure the decay of the persistent +1 offset seen after the pulse train in 006 (y stayed 716 after x returned to 0). Time constant of the slow component.

**cmds:** `x 255 @1; x 0 @11` for 60.0 s

**prediction:** the offset decays: median of last 1 s is back at 715 by t=60

**observed:** start 716.0, final 717, steady 717, min 716, max 719, range 3, spread 0, period None, t_settle 0.0

**update:** MISS, and a surprise. Run started at y=716 (rest was 715 in 001-006). During x=255 y=718 (+2 above this run's rest); after x->0 y=717 and stays there for all 50 s: no decay at all. The rest level is ratcheting upward across runs: 715 (001-006 starts), 716 (007 start), 717 (007 end). Either the system integrates x with an extremely long memory (thermal-like, tau >> 1 min), or the baseline drifts with wall-clock time. Need to separate these: 008 no-command run now, and later runs' start values versus time and versus accumulated x.

### 008 - start in [716.5, 717.5] @0.6 -> 717.0 HIT

**why:** Run 8: no commands, 20 s, to read the current rest level after 007 ended at 717. Distinguishes a rest level that stays where drive left it (memory) from one that relaxes back toward 715 given time (decay slower than 50 s) or keeps drifting up (ambient).

**cmds:** `(none)` for 20.0 s

**prediction:** rest stays where 007 left it: start ~717 (memory hypothesis)

**observed:** start 717.0, final 717, steady 717, min 717, max 717, range 0, spread 0, period None, t_settle 0.0

**update:** Rest read as 717 exactly, where 007 left it, with zero noise. Confirmed that the rest level persists between runs (1 min gap) rather than relaxing; set up 009's 180 s undriven check.

### 009 - claim @0.35: rest holds at 717 for the whole 180 s (memory, not clock drift); a step within 3 min is unlikely -> yes

**why:** Run 9: no commands for 180 s. Rest ratcheted 715->716->717 around runs 006-008 but stayed 715 after 003's 29 s of drive, so it is not simply cumulative x. Tests whether rest drifts with wall-clock time when undriven (a step would appear within 3 min) or holds where drive left it.

**cmds:** `(none)` for 180.0 s

**prediction:** rest holds at 717 for the whole 180 s (memory, not clock drift); a step within 3 min is unlikely

**observed:** start 717.0, final 717, steady 717, min 717, max 717, range 0, spread 0, period None, t_settle 0.0

**update:** YES as worded, but I attached 0.35 to a claim I actually believed at ~0.65 (I had meant to bet on a step). Scored as written; a calibration error on my side, not the system's. Finding: rest holds at exactly 717 for 180 s undriven (8980 identical samples), and CSV timestamps show no clock-driven drift over 17:21-17:31. The rest level is state left behind by drive: 715 through 006, 716 after 006's pulses, 717 after 007's 10 s at 255. Yet 003's 29 s at 255 left rest at 715 (004 start). So it is not a simple integral of x. Hypothesis: persistent state moves only under some condition (stiction-like), and z may set the direction. Test: z=1, x=255 (010).

### 010 - claim @0.45: z reverses the persistent shift: final (last 1 s, undriven) is below 717 -> yes

**why:** Run 10: z=1 then x=255 for 10 s, then x=0 for 20 s. Same drive as 007 but with z=1. 007 left the rest level 1 higher (716->717); if z sets a direction, this should leave it lower. z had no effect at x=128 (005) or alone (004).

**cmds:** `z 1 @1; x 255 @2; x 0 @12` for 32.0 s

**prediction:** z reverses the persistent shift: final (last 1 s, undriven) is below 717

**observed:** start 717.0, final 715, steady 715, min 628, max 720, range 92, spread 0, period None, t_settle 0.44

**update:** YES. Big result: with z=1, x=255 drives y from 717 down to 672 (-45), via a +3 spike then an undershoot to 628, settling in ~0.5 s. On release y returns to 715, 2 below the run's start: z=1 drive moved the rest level DOWN. So z sets polarity, the response is very asymmetric (z=0: +1..2 at 255; z=1: -45 at 255), and z=1/x=128 gave nothing (005), so the z=1 response is thresholded or strongly nonlinear in x between 128 and 255. Fast dynamics: settles in ~0.5 s with overshoot at onset and t_settle 0.44 s at release.

### 011 - steady in [690.0, 718.0] @0.65 -> 551 MISS

**why:** Run 11: z=1, x=192 held to the end of the run. 010 gave -45 at x=255 with z=1; 005 gave ~0 at x=128 with z=1. Locates the nonlinearity between 128 and 255. Holding x to the end so 'steady' measures the driven level.

**cmds:** `z 1 @1; x 192 @2` for 12.0 s

**prediction:** between the two: a linear-from-128 model gives ~694, a steep power law ~710, a threshold above 192 gives ~717

**observed:** start 715.0, final 630, steady 551, min 271, max 834, range 563, spread 303, period 0.872, t_settle None

**update:** MISS by 139. x=192 with z=1 does not sit between the x=128 (nothing) and x=255 (-45, stable) responses: y oscillates wildly, 271..834, period ~0.87 s, with a slow envelope (down to ~370 around t=8, back to ~600 by t=11). Above AND below rest. So the z=1 branch is not monotone in x: there is an oscillatory regime somewhere around 192 that 255 does not show. Ledger at 10 runs: metric hits 4/4 (underconfident, small n), claims Brier 0.38 (coin-flip): my claims are poorly worded/priced. Action: repeat 011 exactly before trusting it (012).

### 012 - range in [350.0, 700.0] @0.6 -> 416 HIT

**why:** Run 12: exact repeat of 011 (z=1, x=192 held, 12 s). 011 showed large oscillation (range 563, period ~0.87 s) where 010 (x=255) was smooth and 005 (x=128) was flat. Repeat before trusting: does the oscillation recur with the same amplitude and period?

**cmds:** `z 1 @1; x 192 @2` for 12.0 s

**prediction:** the oscillation recurs; range comparable to 011's 563 (model: unstable regime near x=192, z=1)

**observed:** start 714.0, final 401, steady 435, min 300, max 716, range 416, spread 351, period 1.64, t_settle None

**update:** HIT (range 416). The oscillatory regime at x=192, z=1 is reproducible in kind but not in detail: 011 range 563 / period 0.87 s, 012 range 416 / period 1.64 s, both with a slow envelope of several seconds and mean ~500-540 (011: 538, 012: ~500). Waveform is irregular (lag-1 autocorr 0.93, spectrum power spread below 1.5 Hz): more like a noisy or chaotic regime than a clean oscillator. Rest level fell again: 715 (011 start) -> 714 (012 start). Regime map for z=1 so far: 128 flat, 192 oscillating, 255 smooth -45. Next: 224 (013), then 160.

### 013 - range in [30.0, 150.0] @0.5 -> 506 MISS

**why:** Run 13: z=1, x=224 held 12 s. Maps the z=1 regime between 192 (oscillating, 011/012) and 255 (smooth -45, 010). Is the boundary sharp, and on which side is 224?

**cmds:** `z 1 @1; x 224 @2` for 12.0 s

**prediction:** 224 behaves like 255: smooth drop with an onset undershoot; range ~50-150 (010 gave 92). If it oscillates instead, range >350 and this misses.

**observed:** start 714.0, final 418, steady 463, min 300, max 806, range 506, spread 426, period 0.821, t_settle None

**update:** MISS by 356. x=224, z=1 oscillates like 192 (range 506, period ~0.8 s, mean ~550, slow envelope). So the oscillatory regime spans at least 192-224 and the smooth -45 at 255 (010) is the outlier. Two candidates: (a) 255 is special because it is the only x with no ripple (002/003 showed ripple at 128, none at 255): the oscillation may need the switching; prediction: 254 oscillates, 255 does not; (b) 010 was a one-off. Rest level: 714 before and (from 013 start) unchanged by 012. Next: repeat 255 with z=1 (014), then 254 (015).

### 014 - range in [30.0, 150.0] @0.55 -> 331 MISS

**why:** Run 14: repeat of 010's drive (z=1, x=255) held 12 s. 011-013 oscillate at 192 and 224, so 010's smooth -45 must be repeated before I trust that 255 is a distinct regime.

**cmds:** `z 1 @1; x 255 @2` for 12.0 s

**prediction:** 010 reproduces: smooth drop to ~R-45 with onset undershoot, range 50-150 (010: 92). If it oscillates, range >350.

**observed:** start 710.0, final 676, steady 676, min 382, max 713, range 331, spread 2, period None, t_settle 0.72

**update:** MISS on range (331) but the regime reproduced: x=255,z=1 settles smooth and flat (steady 676, spread 2), unlike 192/224. The miss came from the onset undershoot, which is much deeper this time (min 382 vs 628 in 010): the transient is variable, the settled level is not. Driven level is ABSOLUTE: 672 (010, R=717) and 676 (014, R=710), so y under 255/z=1 goes to ~674+/-3 regardless of rest level. New: rest fell 714->710 after 013 and now jitters 709/710, the first noise ever seen at rest (as if sitting on a quantisation edge, or something has changed). Next: x=254 (015) tests whether 255 is special because it has no switching ripple.

### 015 - range in [350.0, 700.0] @0.5 -> 333 MISS

**why:** Run 15: z=1, x=254 held 12 s. 255 is smooth (010, 014) while 192 and 224 oscillate (011-013). 255 is also the only x with no ripple (003 vs 002). If the oscillation needs the switching, 254 should oscillate; if the boundary is a threshold in x between 224 and 255, 254 should be smooth.

**cmds:** `z 1 @1; x 254 @2` for 12.0 s

**prediction:** the no-switching hypothesis: 254 oscillates like 224, range >350

**observed:** start 715.0, final 680, steady 680, min 384, max 717, range 333, spread 18, period None, t_settle 0.8

**update:** MISS by 17 (range 333, but the real answer is 'smooth'): x=254,z=1 settles flat at 680 (spread 18 from one glitch), like 255. The no-switching hypothesis is rejected; the boundary between oscillating (<=224) and smooth (>=254) is a threshold in x. Driven levels: 672 (255), 676 (255), 680 (254): absolute, ~676+/-4. Rest jumped 710 -> 715 between 014 and 015 without an undriven interval I observed: 255/z=1 drives leave rest at 715 (010, 014), oscillating drives leave it lower (714, 714, 710), z=0 drives left it higher (716, 717). Range is a poor discriminator because the onset undershoot varies (min 382-628); use spread (last 3 s) instead. Next: x=240 (016).

### 016 - spread in [0.0, 25.0] @0.5 -> 372 MISS

**why:** Run 16: z=1, x=240 held 12 s. Bisects the oscillating/smooth threshold, known to lie between 224 (013, oscillates) and 254 (015, smooth). Predicting spread (last 3 s) because range is dominated by the variable onset undershoot.

**cmds:** `z 1 @1; x 240 @2` for 12.0 s

**prediction:** 50/50; smooth regime gives spread <= 25 (015: 18, 014: 2), oscillating gives >300

**observed:** start 714.0, final 691, steady 633, min 333, max 812, range 479, spread 372, period 0.414, t_settle None

**update:** MISS (spread 372): x=240, z=1 oscillates. Threshold now in (240, 254). Character differs from 192/224: at 240 y spends time near 680 (the smooth level) and breaks away in bursts down to ~380, i.e. intermittent, with a faster component (period 0.41 s by crossings). Suggests the oscillation is a loss of stability of the smooth level that becomes intermittent close to the boundary. Next: 248 (017).

### 017 - spread in [0.0, 25.0] @0.5 -> 350 MISS

**why:** Run 17: z=1, x=248 held 12 s. Threshold between oscillating (240, run 016) and smooth (254, run 015). 016 showed intermittent bursts near the smooth level, so close to the threshold the last 3 s may be quiet by chance; still predicting spread.

**cmds:** `z 1 @1; x 248 @2` for 12.0 s

**prediction:** 50/50 on which side; smooth gives spread <= 25, bursts give >100

**observed:** start 710.0, final 683, steady 595, min 319, max 755, range 436, spread 350, period 0.352, t_settle None

**update:** MISS (spread 350): x=248, z=1 oscillates fully (range 436, mean ~520), not intermittent like 240. Threshold now in (248, 254): the smooth regime is a narrow band at the very top of x. My three 0.5 bisection bets all missed on the 'smooth' side; from here I lean oscillating until proven otherwise. Rest before this run: 710 (after 016's oscillation), consistent with oscillating drives leaving rest low. Next: 251 (018).

### 018 - spread in [100.0, 600.0] @0.6 -> 226 HIT

**why:** Run 18: z=1, x=251 held 12 s. Threshold between 248 (017, oscillates) and 254 (015, smooth). 240 and 248 both oscillate fully, so the smooth band looks narrow and I now lean oscillating.

**cmds:** `z 1 @1; x 251 @2` for 12.0 s

**prediction:** oscillates: spread in the last 3 s >100 (011-013, 016, 017 gave 303-426)

**observed:** start 436.0, final 681, steady 681, min 383, max 780, range 397, spread 226, period 0.359, t_settle None

**update:** HIT (spread 226), but the run opened on a surprise: at x=0 y was 458 falling to ~411 over 2 s, nowhere near any rest level seen before (709-717). Run 017 (x=248, oscillating) ended at ~640-690 and the program set x=0; the rest 1.5 min later was ~436 and still drifting. So release from the oscillating regime does NOT return to 715; it can leave y hundreds lower, and drifting. Under x=251 y sat at ~681 (the smooth level) with intermittent dips (mean 664, sd 46): 251 is the near-threshold intermittent case; the boundary is in (251, 254). Priority now: observe the undriven state (019) before any more drive.

### 019 - start in [700.0, 720.0] @0.35 -> 431.5 MISS

**why:** Run 19: no commands, 40 s. 018 opened at y~436 and drifting at x=0, after 017 ended in oscillation; 018 ended at ~681 under 251/z=1. Where is the rest level now, and is it drifting? Look before driving again.

**cmds:** `(none)` for 40.0 s

**prediction:** rest is no longer at 715; it sits well below (018's start was 436, and 018 ended at 681 under drive) and may still be moving

**observed:** start 431.5, final 466, steady 394, min 358, max 505, range 147, spread 128, period 7.658, t_settle None

**update:** MISS by 268: undriven, y is NOT at rest. With x=0, z=0 for 40 s it oscillates 360..505 with a very regular period of 7.66 s (sawtooth-like: slow rise ~4 s, faster fall). This is self-sustained: no input at all. Earlier rest (001-017 starts) was a flat fixed point. Explanation on offer: two coexisting states at x=0, a fixed point near 715 and a slow limit cycle around ~430; the oscillating drive of 017 (x=248) and release left the system on the cycle. Test: 255/z=1 drive returned rest to 715 flat in 010 and 014; try it once (020). If the flat rest does not come back I stop, as the rules require for an unexplained persistent change.

### 020 - spread in [0.0, 10.0] @0.5 -> 66 MISS

**why:** Run 20: recovery attempt. z=1, x=255 for 8 s, then x=0 and watch 30 s. 019 showed a self-sustained 7.7 s oscillation at rest after 017's oscillating drive. In 010 and 014 a 255/z=1 drive left rest flat at 715. If the flat rest returns, the two-state (fixed point vs limit cycle) explanation holds and I continue; if not, I stop.

**cmds:** `z 1 @1; x 255 @2; x 0 @10` for 40.0 s

**prediction:** flat rest restored after release: spread over the last 3 s <= 10 (two-state hypothesis; 010/014 both returned to 715)

**observed:** start 488.5, final 482, steady 502, min 337, max 715, range 378, spread 66, period 7.58, t_settle None

**update:** MISS (spread 66). Recovery failed on both counts: under 255/z=1 y did not settle at the smooth level ~676 (010, 014, 015) but wandered irregularly 370-667; after release the slow cycle continued (period 7.58 s, 365..513), same as 019. So the change is not just a second attractor at x=0 reachable by the right drive: the driven response has changed as well. The system's behaviour has changed in a way that persists across runs (018-020) and my explanation failed its test. Stopping now, as the rules require.

### 021 - steady in [731.0, 739.0] @0.75 -> 735 HIT [regime 3]

**why:** Run 21: first run of session 2 after servicing (regime 3 declared by Albert). init read y=734/735 at x=0, where regime 1 rested at 715 and regime 2 (019, 020) oscillated 360-510 with a 7.6 s period. No commands, 20 s: is the new rest a flat fixed point, and where, and how noisy? Look before driving.

**cmds:** `(none)` for 20.0 s

**prediction:** y stays flat near 735 (init read 734/735); a fixed point like regime 1, not the 7.6 s cycle of regime 2

**observed:** start 735.0, final 735, steady 735, min 734, max 735, range 1, spread 1, period None, t_settle 0.0

**update:** HIT. Regime 3 rest is a flat fixed point at 735 (999 samples, 734 on a few), not the 7.6 s cycle of regime 2. Same character as regime 1's rest, shifted +20 (715 -> 735). Model B starts as model A with R=735; every other parameter is now untested. Next: the z=0, x=255 probe (003/007 gave +1..+2).

### 022 - steady in [734.0, 740.0] @0.6 -> 735 HIT [regime 3]

**why:** Run 22: z=0, x=255 held to the end, 12 s. Re-runs the basic z=0 probe (003, 007) in regime 3. Model A said z=0 is nearly inert: y = R + 1.5 +/- 0.5 at x=255 with a +3 onset spike. Does that hold with R=735 (021)?

**cmds:** `x 255 @1` for 12.0 s

**prediction:** model A with R=735: steady = 735 + F0(255) = 736.5 +/- 1; the interval also allows a small unexpected shift

**observed:** start 735.0, final 735, steady 735, min 734, max 737, range 3, spread 1, period None, t_settle 0.0

**update:** HIT. z=0 branch holds in regime 3: x=255 gives +0.5..+1 over R (735/736 alternating, mean ~735.5), onset spike to 737 (+2), ripple tiny. Model A's F0(255) = +1.5 +/- 0.5 is consistent (slightly lower, ~+0.8). So the z=0 branch survived the service unchanged apart from R. Next: z=1, x=255, the probe that separated regime 1 (smooth 676) from regime 2 (wandering, 020).

### 023 - steady in [670.0, 700.0] @0.55 -> 668 MISS [regime 3]

**why:** Run 23: z=1, x=255 held 12 s, the regime-1 smooth probe (010, 014, 015 gave a flat 672-680) that failed in regime 2 (020 wandered 370-667). Decides whether regime 3 behaves like regime 1 with R shifted +20 (021, 022) and, if so, whether the smooth level is absolute (676) or relative to R (R-41 = 694).

**cmds:** `z 1 @1; x 255 @2` for 12.0 s

**prediction:** regime-1 behaviour returns: a smooth flat level in the last 3 s; interval covers both the absolute level 676+/-4 and the relative level R-41 = 694. Oscillating/wandering (regime 2) would miss low.

**observed:** start 735.0, final 668, steady 668, min 660, max 737, range 77, spread 8, period None, t_settle 0.48

**update:** MISS by 2 (steady 668), but the regime-1 character is back: 255/z=1 gives a smooth flat level, settle 0.48 s, spread 8. Level 668 is neither model A's absolute 676 (-8) nor relative R-41 = 694 (-26): the drop from R is now -67 vs -41. Onset undershoot was shallow this time (min 660) vs 382-628 in regime 1. Model B: smooth level L = 668 +/- 3 (one run). Next: z=1 x=192, the oscillating probe (011, 012).

### 024 - spread in [150.0, 500.0] @0.6 -> 4 MISS [regime 3]

**why:** Run 24: z=1, x=192 held 12 s, the regime-1 oscillating probe (011: spread 303, 012: 351). Regime 3 has so far matched regime 1 with shifted levels (021-023). Does the oscillating regime still exist at 192, and with the same amplitude? Also reads the rest left by 023's release at t=0.

**cmds:** `z 1 @1; x 192 @2` for 12.0 s

**prediction:** oscillates as in regime 1: spread over the last 3 s in [150, 500] (regime-1 values 303-426 at 192-248). Smooth or flat would give <30 and miss.

**observed:** start 722.0, final 715, steady 715, min 713, max 724, range 11, spread 4, period None, t_settle 0.34

**update:** MISS (spread 4): the oscillating regime is gone. z=1, x=192 gives a smooth drop of -7 (722 -> 715, settle 0.34 s), where regime 1 swung 270-835. Also: rest at start was 722, not 735: the 255/z=1 drive of 023 left R 13 lower (regime 1 returned to home 715 from both sides). So regime 3 differs from regime 1 in two ways: the z=1 branch is smooth everywhere seen so far (drop -7 at 192, -67 at 255, strongly nonlinear), and R is moved down by z=1 drive. Next: map the z=1 curve at 224, then repeat 255 and check what the drive does to R.

### 025 - steady in [670.0, 705.0] @0.55 -> 703 HIT [regime 3]

**why:** Run 25: z=1, x=224 held 12 s. 023 gave a drop of -67 at 255 and 024 a drop of -7 at 192 (both smooth). Maps the z=1 static curve between them: a linear-above-threshold fit (x0~185, slope ~0.95/unit) predicts -37 at 224, an exponential fit (e-fold 28 units) predicts -22. R at start is uncertain (715-723) after 024's drive.

**cmds:** `z 1 @1; x 224 @2` for 12.0 s

**prediction:** guess from two points: drop 20-40 below a rest of 714-723, so steady in [670, 705]; regime-1 style oscillation would miss

**observed:** start 715.0, final 703, steady 703, min 702, max 717, range 15, spread 2, period None, t_settle 0.54

**update:** HIT (steady 703): z=1 x=224 drops -12 from R=715, smooth, settle 0.54 s. Static z=1 curve in regime 3: drop 7 (192), 12 (224), 67 (255): very steep at the top, convex, no oscillation anywhere. Onset dynamics look like a first-order lag, tau ~0.15 s, after a ~0.1-0.3 s delay, with a +1..+2 spike at the edge (023-025, 50 Hz). R sequence at run starts: 735, 735, 735, 722, 715: each z=1 drive left R lower (255: -13, 192: -7) while z=0 drive (022) left it unchanged. Next: release inside a run (026) to see how y returns and where R ends up.

### 026 - final in [695.0, 725.0] @0.5 -> 719 HIT [regime 3]

**why:** Run 26: z=1, x=255 for 8 s, then x=0 and z=0 and watch for 30 s. 023's release was not observed within the run and left R at 722 (from 735); 024's left R at 715. In regime 1 release from 255/z=1 returned y to home 715 in 0.5 s (010, 014). Where does y go after release now, how fast, and does it keep moving over 30 s?

**cmds:** `z 1 @1; x 255 @2; x 0 @10; z 0 @10` for 40.0 s

**prediction:** release returns y to a rest near the pre-run R (715 at 025's start) or a little below it, like 023's -13 step: final in [695, 725]; staying near 668 or overshooting above 735 would miss

**observed:** start 710.0, final 719, steady 719, min 657, max 719, range 62, spread 0, period None, t_settle 0.44

**update:** HIT (final 719). Release from 255/z=1 returns y in 0.44 s to 719 and it holds exactly for 30 s. But 719 is 9 ABOVE the pre-run rest (710, left by 025's 224 drive), so the R change is not a fixed step down per z=1 drive. R sequence at run starts/ends: 735, 722 (after 255), 715 (after 192), 710 (after 224), 719 (after 255). Working hypothesis: a slow state S relaxes during drive toward a target T(x) with T(255) ~ 720, T(224) <= 710, T(192) <= 715, and y after release = S; while driven, y sits at an absolute level L(x) (L(255) = 668 and 671 from R = 735 and 710). Driven levels are flat, no drift over 8-10 s. Next: repeat 026 from R=719 to test T(255) ~ 720 (prediction: R stays ~719-720).

### 027 - final in [714.0, 726.0] @0.6 -> 722 HIT [regime 3]

**why:** Run 27: exact repeat of 026 (z=1, x=255 for 8 s, release, watch 30 s) from a rest of 719. Tests the hypothesis from 026 that a 255/z=1 drive parks the rest near 720 (735 -> 722 in 023, 710 -> 719 in 026) rather than stepping it by a fixed amount; also checks the driven level (668, 671) and the 0.44 s return.

**cmds:** `z 1 @1; x 255 @2; x 0 @10; z 0 @10` for 40.0 s

**prediction:** model: rest after release = T(255) = 720 +/- 4, so final in [714, 726]; a fixed -13 step (706) or a return to the old home 715 exactly would sit at the edge or miss

**observed:** start 719.0, final 722, steady 722, min 659, max 722, range 63, spread 1, period None, t_settle 0.46

**update:** HIT (final 722). Repeat of 026 reproduced: driven level 670 (668/671/670 over three runs: L(255) = 670 +/- 1.5, absolute, R-independent across R = 710-735), release rise 670 -> 719 in 0.3 s (S-shaped at 50 Hz), and the rest after release 722 (719, 722: T(255) = 721 +/- 2). So a 255/z=1 drive of 8-10 s parks R at ~721 whatever it was before (735, 710, 719). Model B v0 written as runs/play/analysis/model_b.py: y relaxes with tau 0.15 s after a 0.12 s delay to L(x) while driven (L = 715/703/670 at 192/224/255) and to T(x) after release (715/710/721). Next: 224 drive with release from R=722, with a trace.

### 028 - final in [704.0, 716.0] @0.55 -> 711 HIT [regime 3]

**why:** Run 28: z=1, x=224 for 10 s then release, watch 18 s, from R=722. 025 (224 from R=715) gave a driven level 703 and left R at 710. Tests whether L(224) is absolute (703) like L(255) (023, 026, 027) and whether the rest after release is T(224) ~ 710 independent of the starting R, as T(255) ~ 721 proved to be (026, 027). First trace prediction from model B.

**cmds:** `z 1 @1; x 224 @2; x 0 @12; z 0 @12` for 30.0 s

**prediction:** model B: driven level 703 (absolute), release to T(224) = 710 +/- 5, so final in [704, 716]; if T depends on the prior R (e.g. R-5 = 717) this misses high

**observed:** start 722.0, final 711, steady 711, min 693, max 723, range 30, spread 0, period None, t_settle 0.32

**update:** HIT on final (711 = T(224), matching 025's 710 from a different starting R) and first trace skill 0.72. But the driven level was 695, not 703 (025 from R=715 gave 703; from R=722 gave 695): L(224) is neither absolute nor R-relative. Restructure: at a z=1 drive the slow state jumps to T(x) and y_driven = T(x) + G(x); G(255) = -51 +/- 3 (four runs), G(224) = -7 and -16, G(192) = 0; G ~ -0.013 (x-192)^2 fits. T(x) is non-monotonic: 715 (192), 710.5 (224, two runs), 721 (255, three runs). Model B v1 in model_b.py. Next: x=240 to fill the T and G curves.

### 029 - final in [709.0, 723.0] @0.5 -> 714 HIT [regime 3]

**why:** Run 29: z=1, x=240 for 10 s, release, watch 18 s, from R=711. Fills the T(x) and G(x) curves between 224 (T 710.5, runs 025/028) and 255 (T 721, runs 026/027): model B v1 interpolates T(240) ~ 716 and G(240) = -0.013*48^2 = -30, so a driven level ~686. Trace attached.

**cmds:** `z 1 @1; x 240 @2; x 0 @12; z 0 @12` for 30.0 s

**prediction:** model B v1: rest after release T(240) in [709, 723] (linear interpolation 716; T is non-monotonic so the interval is wide); driven level ~686

**observed:** start 711.0, final 714, steady 714, min 687, max 714, range 27, spread 0, period None, t_settle 0.4

**update:** HIT (final 714), trace skill 0.81. T(240) = 714, G(240) = 688 - 714 = -26 (model -30, residual +4). T(x) now: 715 (192), 710.5 (224), 714 (240), 721 (255): a shallow dip around 224 then rising to 255. G: 0, -7/-16, -26, -51 at 192/224/240/255: the quadratic -0.013(x-192)^2 gives 0/-13/-30/-52, residuals within +/-6. Next: x=160, below the lowest tested z=1 value, to find where the z=1 branch starts (model guesses no effect below 150 and a flat 714 at 160).

### 030 - range in [0.0, 8.0] @0.5 -> 2 HIT [regime 3]

**why:** Run 30: z=1, x=160 for 10 s, release, from R=714. The z=1 branch has been mapped at 192-255 (024-029); regime 1 had 128 flat and 192 oscillating, so the branch starts somewhere in (128, 192). Model B guesses G(160) = 0 and T(160) ~ R, i.e. y stays flat at 714 apart from the +1..2 edge spike.

**cmds:** `z 1 @1; x 160 @2; x 0 @12; z 0 @12` for 30.0 s

**prediction:** model B: nothing happens at 160: range over the whole run in [0, 8]; a visible drop (G) or a rest shift (T) larger than that would miss

**observed:** start 714.0, final 714, steady 714, min 713, max 715, range 2, spread 0, period None, t_settle 0.0

**update:** HIT (range 2): x=160 with z=1 does nothing (y 714 +/- 1 throughout, rest unchanged), like 128 in regime 1. The z=1 branch starts in (160, 192). Trace skill -0.05 is the correct score for a flat run (RMS 0.34 vs lazy 0.32: nothing to predict). Model B v1 unchanged. Next: a 0.5 s drive at 255 to test whether R jumps to T(255) at once (model B) or needs seconds to relax there.

### 031 - final in [718.0, 724.0] @0.5 -> 726 MISS [regime 3]

**why:** Run 31: z=1, x=255 for only 0.5 s, then release and watch 17 s, from R=714. Model B (026-029) says the slow state jumps to T(255) = 721 as soon as the drive is applied, so even a brief drive should leave the rest at 721. If R instead relaxes toward T over seconds, a 0.5 s drive leaves it near 714-716. The two models differ by ~6 in final.

**cmds:** `z 1 @1; x 255 @2; x 0 @2.5; z 0 @2.5` for 20.0 s

**prediction:** model B: final = T(255) = 721 +/- 3, so [718, 724]; slow-relaxation alternative gives 714-717 and misses

**observed:** start 714.0, final 726, steady 726, min 520, max 732, range 212, spread 0, period None, t_settle 0.46

**update:** MISS by 2 (final 726 vs T(255) = 721 from 8-10 s drives) and a surprise at 50 Hz: during the 0.5 s at 255 y did not fall smoothly as in 023 but burst into large sample-to-sample scatter (634, 520, 563, 664, 609, ... 732), then sat at exactly 670 (= the long-drive level) for 0.12 s after release before the S-shaped rise to 726. So the onset transient is variable (as in regime 1: undershoot 382-628), and a brief drive may leave R higher (726) than a long one (721). Model B v1 keeps its structure; the onset burst is outside it. Ledger at 10 runs: regime 3 hits 8/10 at mean conf 0.57, underconfident by 0.23: I will raise stated confidence and narrow intervals. Next: five 0.5 s pulses at 255 to see how often the burst recurs and what rest each leaves.

### 032 - final in [720.0, 730.0] @0.65 -> 732 MISS [regime 3]

**why:** Run 32: z=1, five pulses of x=255, 0.5 s on / 2.5 s off, from R=726, then watch 8 s. 031 showed a 0.5 s drive produces a chaotic burst (520-732) rather than the smooth fall of 023/026/027 and leaves R at 726 rather than 721. Five repeats in one run: how often does the burst occur, and does the rest after each pulse stay at ~726 (model B: R := T(255) each time)?

**cmds:** `z 1 @1; pulse x=255 on=0.5 off=2.5 n=5 @2; z 0 @17` for 25.0 s

**prediction:** model B with T(255) from brief drives = 726 (031): final in [720, 730]; the trace assumes smooth falls to 670 and will lose skill if bursts recur

**observed:** start 726.0, final 732, steady 732, min 418, max 755, range 337, spread 1, period None, t_settle 0.0

**update:** MISS by 2 (final 732), trace skill 0.20. All five 0.5 s pulses at 255 burst (minima 418-632; no smooth fall), and the rest after each rose 726 -> 730 -> 731 -> 732 -> 732 -> 732: each pulse closes ~2/3 of the gap to an upper level U ~ 732 (from 714: 726 in 031 = 67%; 726 -> 730 = 67%). Long 8-10 s drives at 255 leave R at 721 instead (026, 027, 023), so a drive has a fast upward effect on R (saturating within ~1 s at U ~ 732 for x=255) and a slower downward one that dominates by 8 s. Model B v1's single T(x) is therefore a function of drive duration: T(255, 0.5 s) -> 732, T(255, 8-10 s) = 721. Confidence at 0.65 was still too low for the direction (miss was by 2 above). Next: 255 held 30 s to see whether the slow downward effect saturates at 721 or keeps going.

### 033 - final in [717.0, 726.0] @0.6 -> 722 HIT [regime 3]

**why:** Run 33: z=1, x=255 held 30 s, release, watch 13 s, from R=732. 8 s and 10 s drives at 255 both left R at 721 (023, 026, 027) while 0.5 s pulses left it at 726-732 (031, 032): a fast upward and a slower downward effect on the rest. Does the downward effect saturate by 8 s (R stays 721) or continue with time (R lower after 30 s)? Also checks the driven level 670 for drift over 30 s.

**cmds:** `z 1 @1; x 255 @2; x 0 @32; z 0 @32` for 45.0 s

**prediction:** model B: slow effect saturated, final = 721 +/- 4 -> [717, 726]; continuing decline would land below 717

**observed:** start 731.0, final 722, steady 722, min 478, max 734, range 256, spread 0, period None, t_settle 0.42

**update:** HIT (final 722), trace skill 0.68 despite an onset burst (min 478). 30 s at 255 gives the same rest (722) as 8-10 s (719, 722, 722): the slow downward effect on R saturates within ~8 s at T_long(255) = 721.5 +/- 1.5. Driven level 667 flat for 30 s, no drift (L(255) = 668.5 +/- 2 over five runs). Onset bursts have now occurred in 031, 032, 033 and not in 023, 026, 027, with no variable I can point to; the settled level is the same either way. Model B v2: R after a z=1 drive of duration d at x: T(x,d) = U(x) - (U(x) - T_long(x)) (1 - exp(-(d-0.3)/tau_s)), U(255) = 732 (031, 032), tau_s unknown (guess 2 s). Next: 2 s pulses to measure tau_s.

### 034 - final in [722.0, 731.0] @0.6 -> 725 HIT [regime 3]

**why:** Run 34: z=1, three pulses of x=255, 2 s on / 5 s off, from R=722, then watch 7 s. A 0.5 s drive leaves R near U=732 (031, 032) and a >=8 s drive leaves it at 721.5 (023, 026, 027, 033). 2 s drives measure the time constant tau_s of the slow downward effect: model B v2 with tau_s = 2 s predicts each release lands at ~726. Three onsets also add to the burst/smooth tally.

**cmds:** `z 1 @1; pulse x=255 on=2 off=5 n=3 @2; z 0 @23` for 30.0 s

**prediction:** model B v2 (tau_s guess 2 s): final in [722, 731] (tau_s 1 s -> 723.5, 4 s -> 728.5); the trace uses tau_s = 2 s

**observed:** start 722.0, final 725, steady 725, min 401, max 729, range 328, spread 1, period None, t_settle 0.0

**update:** HIT (final 725): 2 s drives at 255 leave R at 726, 725, 725, right on model B v2's 726 with tau_s = 2 s. R after a 255 drive of duration d: 732 - 10.5 (1 - exp(-(d-0.3)/2)) fits 0.5 s (732), 2 s (725.5), 8-30 s (721.5). All three onsets burst again (minima 401-460; tally now 12 bursts vs 3 smooth, the smooth ones being the session's first three 255 drives). Trace skill 0.25 because the model has no burst. Simplification for v3: driven level is absolute, L(x) = 715 - 0.0118 (x-192)^2 for x >= 192 (residuals <= 4 at 224/240/255), no coupling to R. Next: a slow ramp to map L(x) continuously and test the model as a whole trace.

### 035 - min in [660.0, 676.0] @0.5 -> 394 MISS [regime 3]

**why:** Run 35: z=1, ramp x from 0 to 255 over 25 s, hold 3 s, release, watch 10 s, from R=725. Maps the driven level L(x) continuously (so far 4 points: 192, 224, 240, 255, runs 024-029) and tests model B v3 as a whole trace; also asks whether a slow ramp avoids the onset burst that every step to 255 has produced since 031.

**cmds:** `z 1 @1; ramp x=0..255 over=25 @2; x 0 @30; z 0 @30` for 40.0 s

**prediction:** model B v3: y follows L(x) = 715 - 0.0118 (x-192)^2 down to 668.5 at 255 with no burst, so min in [660, 676]; a burst would take min below 600 and miss

**observed:** start 725.0, final 719, steady 719, min 394, max 848, range 454, spread 0, period None, t_settle 0.4

**update:** MISS by 266 (min 394, max 848), trace skill 0.12. A slow ramp does not follow L(x): at x ~ 140 (t ~ 15-16 s) y broke into the regime-1 style oscillation (2 s bin means 500-655, sd 30-90) and stayed oscillating through x=255 (mean ~505 at 252, where a step gives a flat 668). Release still gave R = 719. So the oscillating state was not removed by the service: it coexists with the smooth state at the same x and z, and the path selects it. A step from 0 lands on the smooth fixed point (024-029, 033), after a transient visit (the 'onset bursts' of 031-034) or not (023, 026, 027); a slow ramp lands on the oscillation. Also the z=1 threshold is ~140 via a ramp, while a step to 160 (030) did nothing. Model B v3 gains a state variable s in {smooth, osc}; in osc the mean is ~540 with sd ~60. Next: ramp into oscillation, then step 0 -> 255 inside the same run to test whether the step selects the smooth state.

### 036 - claim @0.6: claim: after the step at t=21, y settles to the smooth state: median over t 28-31 in [660, 676] and sd < 6 (judged from the CSV), while t 16-20 oscillates with sd > 30 -> yes [regime 3]

**why:** Run 36: z=1, ramp 0->255 over 15 s (035 showed this enters the oscillating state), hold to t=20, then x=0 for 1 s and a step back to 255 at t=21, hold 10 s, release. Tests the bistability reading of 035: the same x=255, z=1 should oscillate after the ramp and settle smooth at ~668 after the step (023, 026, 027, 033).

**cmds:** `z 1 @1; ramp x=0..255 over=15 @1; x 0 @20; x 255 @21; x 0 @31; z 0 @31` for 40.0 s

**prediction:** claim: after the step at t=21, y settles to the smooth state: median over t 28-31 in [660, 676] and sd < 6 (judged from the CSV), while t 16-20 oscillates with sd > 30

**observed:** start 719.0, final 722, steady 722, min 390, max 822, range 432, spread 1, period None, t_settle 0.4

**update:** YES. t 16-20 (ramp end, x 237-255): oscillating, sd 57-86, mean 509-538. After x=0 for 1 s and a step back to 255 at t=21: flat 673 with sd 0.3 for 8 s. Same x, same z, two states: the path selects them. Trace skill 0.43 with the osc state at a constant 540 (the oscillation's sd ~60-75 is unmodelled). Spectrum of 035's oscillation (t 17-30): lines at 10.45-10.95 Hz and 21.1-21.4 Hz (harmonic) over a 0.25 Hz (4 s) envelope, sd 74; lag-1 autocorr 0.79. Model B v4 adds the state variable s: ramp crossing x ~ 140 with z=1 enters osc; a step from x=0 to >= 192 selects smooth; release from either gives R = T(x, d) (719 after 035's oscillation, 722 after 036's smooth hold, both ~T_long(255) = 721.5). Next: does osc persist at 255 for 30 s or decay into smooth?

### 037 - spread in [120.0, 450.0] @0.6 -> 299 HIT [regime 3]

**why:** Run 37: z=1, ramp 0->255 over 12 s, then hold 255 to the end (32 s in the oscillating state). 035 and 036 held the oscillation for 4-5 s at 255; is it a stable attractor that persists for 30 s or a long transient that eventually drops into the smooth 668-673 state (as the onset bursts of 031-034 did within ~1 s)?

**cmds:** `z 1 @1; ramp x=0..255 over=12 @1` for 45.0 s

**prediction:** model B v4: osc persists: spread over the last 3 s in [120, 450] (035/036 sd 60-85 -> 3 s range ~250-350); decay into smooth gives spread < 10 and misses

**observed:** start 723.0, final 567, steady 589, min 318, max 737, range 419, spread 299, period 0.961, t_settle None

**update:** HIT (spread 299): the oscillating state persists for the full 32 s at x=255 (4 s bin means 429-593, sd 38-57, crossing period 0.96 s): a stable attractor coexisting with the smooth fixed point at 668-673, not a metastable transient. Trace skill 0.66 with a constant 540 for the osc mean. Model B v4 stands: s in {smooth, osc} is a genuine state variable. Next: release from osc at a lower x (ramp to 200) to see whether regime 2's rest oscillation is reachable from regime 3.

### 038 - final in [706.0, 724.0] @0.65 -> 712 HIT [regime 3]

**why:** Run 38: z=1, ramp 0->200 over 10 s (enters osc, per 035-037), hold 5 s, release at t=16, watch 34 s. In regime 1 a release from oscillation at 248 (017) put the system into regime 2 (self-oscillation at rest, 7.6 s period, 018-020). In regime 3, releases from oscillation at 255 (035) gave a flat rest 719. Is regime 2 reachable from a release at lower x? Model B v4 says no: rest T(200, 5 s) ~ 716 +/- 6, flat.

**cmds:** `z 1 @1; ramp x=0..200 over=10 @1; x 0 @16; z 0 @16` for 50.0 s

**prediction:** model B v4: flat rest after release, final in [706, 724]; a regime-2 rest oscillation (360-510) would miss by far

**observed:** start 719.0, final 712, steady 712, min 380, max 800, range 420, spread 0, period None, t_settle 0.1

**update:** HIT (final 712): release from the oscillating state at x=200 gives a flat rest (712, zero noise for 34 s), no regime-2 self-oscillation. TL(200) = 712 fits between TL(192) = 715 and TL(224) = 710.5. The osc mean depends on x: ~603-623 at x 160-200 (038), ~510-545 at 255 (035, 037); model v4 now uses Y_OSC(x) linear from 610 (160) to 520 (255). Trace skill 0.29 was low because Y_OSC was a constant 540 during the 160-200 ramp. Next: z=0 ramp to 255 (does z=0 ever oscillate?).

### 039 - range in [0.0, 5.0] @0.65 -> 6 MISS [regime 3]

**why:** Run 39: z=0, ramp 0->255 over 15 s, hold 4 s, release, watch 10 s, from R=712. With z=1 a slow ramp enters the oscillating state at x ~ 140 (035-038). Model B says z is a switch and the z=0 branch is inert (022: +0.8 at 255, regime 1 likewise), so a z=0 ramp should stay flat. If it oscillates, z is not the switch I think it is.

**cmds:** `ramp x=0..255 over=15 @1; x 0 @20` for 30.0 s

**prediction:** model B: flat, y = R + <= 1 throughout: range over the whole run in [0, 5]; any oscillation (range > 100) misses

**observed:** start 712.0, final 716, steady 716, min 711, max 717, range 6, spread 0, period None, t_settle 0.0

**update:** MISS by 1 (range 6): no oscillation under a z=0 ramp (z is a switch for the osc state, as in regime 1), but the z=0 branch is less inert than 022 suggested: y rose to 716.7 at x=255 (+4.7 over R=712, vs +0.8 in 022) and R was left at 716 (+4), where 022 left it unchanged. So z=0 drive raises R slowly (regime 1 saw +1..+2 per drive). Interval [0,5] was too tight for a first-time command; I stated 0.65 and should have widened to [0, 10]. Model: F0 under z=0 is +1..+5 and R += ~+4 per ~20 s of z=0 drive (two runs only). Next: descending path 255 -> 150 with z=1 while smooth: model_b keeps y at L(255); I expect it to rise toward R.

### 040 - claim @0.35: claim: y over t 14-18 (at x=150, z=1) stays within 20 of the 255 level, i.e. median in [649, 689]. I lean against (y rises to ~700-725), hence 0.35 -> yes [regime 3]

**why:** Run 40: z=1, step to 255 (smooth, 669), then x=150 at t=10 for 8 s, then release. 150 is below the step threshold (160 did nothing, 030) but above the ramp-osc threshold (~140, 035-038). Where does y go on the way down? model_b (v4) literally holds y at L(255) = 669 because 150 is 'no effect'; I think that is wrong and y rises toward the rest R ~ 721. Tests the model's structure on a descending path.

**cmds:** `z 1 @1; x 255 @2; x 150 @10; x 0 @18; z 0 @18` for 28.0 s

**prediction:** claim: y over t 14-18 (at x=150, z=1) stays within 20 of the 255 level, i.e. median in [649, 689]. I lean against (y rises to ~700-725), hence 0.35

**observed:** start 716.0, final 719, steady 719, min 444, max 719, range 275, spread 0, period None, t_settle 0.42

**update:** YES (I bet against it at 0.35 and lost, correctly scored). After the 255 step (smooth 669), x=150 with z=1 held y at 678 +/- 1 for 8 s, only +9 above the 255 level, where a step from 0 to 160 did nothing (030). The z=1 smooth branch has hysteresis: once engaged it persists far below the engagement threshold, and its level there (678) is not on the step-from-0 curve L(x) (which would say 'no effect'). So model B needs an 'engaged' flag: entered by a step to >= ~192 (or maybe only >= ~250; 224/240 steps gave 695-703/688, ambiguous), kept until x reaches some x_off < 150, with y = L_eng(x) that is nearly flat (669 at 255, 678 at 150). Release gave 719 (TL(255) 721.5, -2.5). Next: a down-ramp 255 -> 0 to map L_eng(x) and find x_off.

### 041 - claim @0.5: claim: on the way down y is still engaged (below 700) when x passes 100 (t ~ 25.2 s); 040 says engaged at 150; where it lets go is a guess -> yes [regime 3]

**why:** Run 41: z=1, step to 255 (smooth), then ramp x down 255 -> 0 over 25 s from t=10, watch 5 s. 040 showed the engaged smooth level persists at x=150 (678). Maps the descending curve L_eng(x) continuously and finds the disengagement point x_off where y jumps back toward the rest; also asks whether a downward ramp through 140 enters the oscillating state (upward ramps do, 035-038). model_b v4's trace holds 715 from x=192 down to 0 and is expected to be wrong there.

**cmds:** `z 1 @1; x 255 @2; ramp x=255..0 over=25 @10` for 40.0 s

**prediction:** claim: on the way down y is still engaged (below 700) when x passes 100 (t ~ 25.2 s); 040 says engaged at 150; where it lets go is a guess

**observed:** start 719.0, final 707, steady 707, min 575, max 722, range 147, spread 0, period None, t_settle 0.0

**update:** YES (y = 686 at x ~ 100). The descending engaged curve: 667 flat from 255 down to ~184, then a smooth rise 668.6 (163), 671.6 (143), 678 (122), 686.5 (102), 694 (82), 701.5 (61), 706 (41), 707 (20), 707 at x=0: L_eng(x) = 667 + 40 / (1 + exp((x - 101) / 24)) fits within 2. No oscillation on the way down through 140. And no release jump: the slow release leaves R = 707, where a step release from 255 leaves 721.5 (six runs). So the rest after a drive is B + kicks from fast edges: B ~ 707, release step kick ~ +14, onset kick ~ +11 decaying with tau_s = 2 s while driven: this reproduces 732 (0.5 s), 725.5 (2 s), 721.5 (long), 707 (ramped release). Trace skill 0.35 (model held 715 below 192). Next: the same down-ramp for the oscillating branch.

### 042 - claim @0.6: claim: the oscillation persists on the way down at least to x=150 (t ~ 26.3 s): sd of y over t 25-27 > 20 (judged from the CSV) -> no [regime 3]

**why:** Run 42: z=1, ramp 0->255 over 12 s (enters osc, 035-038), hold 3 s, then ramp 255->0 over 25 s, watch 5 s. Mirror of 041 for the oscillating branch: does the oscillation persist on the way down below the 140 entry threshold (hysteresis like the smooth branch's), where does it stop, and what rest does a slow release from osc leave (smooth branch: 707)?

**cmds:** `z 1 @1; ramp x=0..255 over=12 @1; ramp x=255..0 over=25 @16` for 46.0 s

**prediction:** claim: the oscillation persists on the way down at least to x=150 (t ~ 26.3 s): sd of y over t 25-27 > 20 (judged from the CSV)

**observed:** start 707.0, final 706, steady 706, min 440, max 795, range 355, spread 1, period None, t_settle 0.0

**update:** NO: the oscillation did not persist on the way down. It collapsed around x ~ 225 (t 19-20) into a smooth level 681 (sd 0.7) that stayed flat to x ~ 130, then rose along nearly the same curve as 041 (682/687/694/700/704 at 122/102/82/61/41 vs 678/686/694/701/706) to 706 at x=0, again with no release kick. So: the osc branch has no downward hysteresis (the smooth branch does); the smooth plateau is path-dependent (667 after a 255 step, 681 after osc collapse, 688-715 by step to 240-192); below x ~ 120 the descending curve is common. Rest after a slow release: 707, 706 (B = 706.5 +/- 1). Trace skill -0.04 (model kept osc all the way down). Next: a faster down-ramp to separate a static descending curve from an upward rate limit (~2.6 units/s fits both ramps so far).

### 043 - claim @0.55: claim: static curve: y at t=19 is >= 700 (judged from the CSV); a rate limit of ~2.6/s would give ~685 and fail -> no [regime 3]

**why:** Run 43: z=1, step to 255 (smooth), then ramp 255->0 over 8 s (3x faster than 041's 25 s), watch 12 s. In 041 and 042 the rise from the plateau to ~707 ran at ~2.6 units/s, which is either the static curve L_eng(x) sampled at 10 units/s or an upward rate limit. With a 32 units/s ramp, a static curve puts y at 707 within a second of the ramp's end (t=18); a rate limit leaves it ~685 at t=19 and still climbing.

**cmds:** `z 1 @1; x 255 @2; ramp x=255..0 over=8 @10` for 30.0 s

**prediction:** claim: static curve: y at t=19 is >= 700 (judged from the CSV); a rate limit of ~2.6/s would give ~685 and fail

**observed:** start 706.0, final 483, steady 507, min 436, max 799, range 363, spread 65, period None, t_settle None

**update:** NO, and a major event. The 8 s down-ramp did not follow the static descending curve: y stayed ~669 to x ~ 225, then broke into oscillation around x 160-100 (sd 44-78), spiked to ~740 near x = 33, and after x reached 0 (t=18, z still 1) it did NOT settle: 663 -> 551 -> 456 -> 459 -> 507 -> 493 over 2 s bins, a slow wander at x=0 like regime 2's self-oscillation at rest (019: 360-510, period 7.6 s). Releases from osc by a step to 0 (035, 038) and slow ramps to 0 (041, 042) all gave flat rests; this medium-rate ramp through the osc region did not. The rate question (static curve vs 2.6/s limit) is void in practice: the path left the smooth branch. Next: a no-command run to see whether the self-oscillation persists at x=0, z=0.

### 044 - period in [6.0, 9.5] @0.5 -> 4.717 MISS [regime 3]

**why:** Run 44: no commands, 40 s. 043 ended with y wandering 450-510 at x=0 (z=1), not at a rest level, after a fast down-ramp through the oscillating region. Regime 2 (018-020) looked like this: self-oscillation 360-510 with a 7.6 s period at x=0, z=0. Is that state back, does it persist with z=0, and with what period? Look before driving.

**cmds:** `(none)` for 40.0 s

**prediction:** the self-oscillation persists at x=0, z=0 with a period like regime 2's: period in [6.0, 9.5] s (019: 7.66, 020: 7.58); a flat rest gives period None and misses

**observed:** start 692.0, final 718, steady 741, min 588, max 782, range 194, spread 91, period 4.717, t_settle None

**update:** MISS (period 4.72 s vs [6, 9.5]): the self-oscillation at rest is real and persists at x=0, z=0 for 40 s, but it is not regime 2's: band 588-782 (centre ~690, amplitude ~95) and period 4.7 s, vs 360-510 and 7.6 s in 019/020. Slow, smooth (2 s bin sd 5-20), near-sinusoidal. A third kind of rest: fixed point (regime 1 and 3 so far), 7.6 s cycle (regime 2), 4.7 s cycle now. Reached by 043's fast down-ramp through the oscillating region; step and slow-ramp releases never did this (035, 038, 041, 042). Next: the deciding test: does a 255 step still give the smooth 669 and leave a flat rest? If yes, the rest cycle is a second state and the model grows a state variable; if no, the driven response has changed too and I declare a regime.

### 045 - claim @0.5: claim: the driven segment settles smooth: median of y over t 6-10 in [660, 680] with sd < 5 (judged from the CSV) -> no [regime 3]

**why:** Run 45: z=1, step to 255 for 8 s, release, watch 30 s, starting from the 4.7 s rest cycle found in 044. In regime 2 the same drive failed to give the smooth level (020). If the smooth 667-673 level appears and release leaves a flat rest (~721, six earlier runs), the rest cycle is a second state of the same system; if not, the driven response has changed and a regime is declared.

**cmds:** `z 1 @1; x 255 @2; x 0 @10; z 0 @10` for 40.0 s

**prediction:** claim: the driven segment settles smooth: median of y over t 6-10 in [660, 680] with sd < 5 (judged from the CSV)

**observed:** start 628.0, final 547, steady 512, min 395, max 761, range 366, spread 141, period 14.733, t_settle None

**update:** NO: under 255/z=1 y did not settle smooth (2 s bin means 647-662 with sd 17-36: intermittent, like 018's 251 or 020), and after release the rest wandered 420-570 with slow irregular swings of 6-8 s, in regime 2's band (360-510) rather than 044's 588-782. Trace skill -0.55. So since 043 the idle value has moved and stays moved AND the driven response has changed: the same signs as 018-020. Model B's smooth branch and rest kicks no longer apply. Declaring a regime after this run; the change was caused by 043's fast down-ramp (32 units/s) through the oscillating region with z=1. Rebuild starts with probes regime 2 never got: z=0 drive, slow ramp, long idle.

### 046 - spread in [25.0, 250.0] @0.6 -> 40 HIT [regime 4]

**why:** Run 46: z=0, x=255 for 15 s, then watch 25 s, from the regime-4 rest cycle (044, 045). First rebuild probe, and one regime 2 never got: the z=0 branch was inert in regimes 1 and 3 (022, 039: +1..+5 and a small rise in R). Does a z=0 drive touch the rest cycle at all, or restore a flat rest?

**cmds:** `x 255 @1; x 0 @16` for 40.0 s

**prediction:** the cycle persists through and after the z=0 drive: spread over the last 3 s in [25, 250] (044/045 cycles give 40-140 over 3 s); a flat rest (spread < 10) would miss

**observed:** start 446.5, final 718, steady 704, min 261, max 848, range 587, spread 40, period 3.663, t_settle None

**update:** HIT (spread 40). Regime 4 first probe: z=0, x=255 is no longer inert (regimes 1/3: +1..+5): y oscillated violently, 261-848, 2 s bin sd 80-115, drifting upward in mean (490 -> 644) over the 15 s. After release the slow rest cycle continued, band 689-750, period 3.7 s (044: 588-782, 4.7 s). The cycle's centre has been ~480 (043 tail), ~690 (044), ~495 (045 tail), ~720 (046 tail): it moves between runs by hundreds. Regime 4 so far: rest = slow cycle (3.7-4.7 s) whose centre wanders; any drive at 255, either z, gives large fast oscillation. Next: 120 s idle to see the cycle's period, amplitude and centre over minutes.

### 047 - period in [3.0, 6.0] @0.6 -> 11.07 MISS [regime 4]

**why:** Run 47: no commands, 120 s. Regime 4's rest is a slow cycle (044: 4.7 s, 588-782; 046 tail: 3.7 s, 689-750) whose centre has moved between runs (480, 690, 495, 720). Over two minutes with no input: is the period stable, does the amplitude grow or decay, and does the centre drift or step? The regime-4 baseline before more drive.

**cmds:** `(none)` for 120.0 s

**prediction:** period of the cycle in [3.0, 6.0] s (044: 4.72, 046: 3.66); collapse to a fixed point (None) or a regime-2 like 7.6 s would miss

**observed:** start 722.0, final 719, steady 720, min 681, max 758, range 77, spread 8, period 11.07, t_settle 31.02

**update:** MISS (period 11 s is a crossing-count artefact of a decaying signal). The rest cycle DAMPED OUT: 2 s bin means 745/703/733 over the first 30 s, then 719 +/- 2 from t ~ 40 s on, sd 0.5-1.6, t_settle 31 s. y sits at ~720, which is TL(255) = 721.5 from regime 3. So the regime-4 'rest cycle' is a slowly damped mode (decay ~30 s from an amplitude ~30; 044's 40 s showed only slight decay from ~95), excited by 043's fast ramp and re-excited by the drives of 045 and 046. Hypothesis: regime 3 behaviour returns once the mode has decayed, and the 'changed driven response' of 045/046 was drive applied on top of the excited mode. If so, regime 4 was a state, not a new system, and the declaration after 045 was premature; I will say so. Next: the 255 step from this quiet rest.

### 048 - claim @0.55: claim: the driven segment settles smooth: median of y over t 6-10 in [660, 680] with sd < 5 (judged from the CSV); trace from model B, R0 = 720 -> no [regime 4]

**why:** Run 48: z=1, step to 255 for 8 s, release, watch 30 s, from the quiet rest ~720 that 047 decayed to. The same drive gave the smooth 667-673 level in regime 3 (023, 026, 027, 033, 036) and failed in 045 while the rest mode was excited. If the smooth level and a flat rest ~721 return, regime 4 was a transient excited state of the regime-3 system and model B applies again with an added excitation variable.

**cmds:** `z 1 @1; x 255 @2; x 0 @10; z 0 @10` for 40.0 s

**prediction:** claim: the driven segment settles smooth: median of y over t 6-10 in [660, 680] with sd < 5 (judged from the CSV); trace from model B, R0 = 720

**observed:** start 723.0, final 649, steady 705, min 474, max 796, range 322, spread 137, period 7.011, t_settle None

**update:** NO: from the quiet rest ~720 (047), the 255 step gave mean 672 but sd 32-40 over t 2-10 (intermittent, not the smooth 669 of regime 3), and after release the rest cycle was re-excited (658-778, ~7 s). Regime 4 stands: the driven response has changed, not just the rest. Regime 4 so far: rest = damped oscillation about ~720 (period 4-7 s, decay ~30 s), re-excited by any drive; 255/z=1 = intermittent around 670, sd 20-40 (045, 048); 255/z=0 = wild oscillation 260-850 (046). Nothing tried has restored regime 3. Next: the basic probe at 192/z=1 (regime 3: smooth -7; regime 1: full oscillation), then a restoration attempt by the reverse of 043's path.

### 049 - spread in [100.0, 500.0] @0.55 -> 199 HIT [regime 4]

**why:** Run 49: z=1, x=192 held 12 s, the basic mid-x probe for regime 4. Regime 3 gave a smooth -7 (024); regime 1 gave full oscillation (011, 012). Regime 4 at 255 is intermittent (045, 048). Which does 192 look like now? Rest at start is whatever 048's re-excited cycle has decayed to.

**cmds:** `z 1 @1; x 192 @2` for 14.0 s

**prediction:** regime 4 at 192 oscillates like regime 1: spread over the last 3 s in [100, 500]; a regime-3 smooth level (< 10) misses

**observed:** start 700.5, final 502, steady 489, min 369, max 798, range 429, spread 199, period 0.904, t_settle None

**update:** HIT (spread 199): 192/z=1 oscillates fully in regime 4 (mean 485-605, sd 40-75, crossing period 0.9 s), as in regime 1 (011, 012), where regime 3 gave a smooth -7. And 048's driven segment at 255 was not 'smooth with dips' but the 10 Hz oscillating state with a 0.17 Hz envelope (mean 626, sd 67). Regime 4 z=1 branch = the osc state everywhere from 192 up, by step; the smooth fixed point has not been reached by a step since 043. Rest at 049's start was still cycling (748 +/- 38) 1 min after 048. Next: restoration attempt by the slow down-ramp, which in regime 3 captured the smooth branch from osc (042) and left a flat rest (706-707).

### 050 - spread in [0.0, 6.0] @0.5 -> 114 MISS [regime 4]

**why:** Run 50: z=1, step to 255 (regime 4: oscillating, 045/048), hold 6 s, then ramp 255->0 slowly over 25 s, watch 12 s. In regime 3 this slow path collapsed the oscillation into the smooth branch at x ~ 225 (042) and left a flat rest 706-707 (041, 042). If the smooth branch and a flat rest come back this way, regime 3's fixed point still exists and this is the way back; if the rest keeps cycling, it does not.

**cmds:** `z 1 @1; x 255 @2; ramp x=255..0 over=25 @8` for 45.0 s

**prediction:** restoration: flat rest after the slow ramp, spread over the last 3 s in [0, 6]; an excited rest cycle (30-140) misses. 50/50

**observed:** start 512.0, final 359, steady 362, min 347, max 724, range 377, spread 114, period 4.56, t_settle None

**update:** MISS by 108 (spread 114): the slow down-ramp did not capture the smooth branch in regime 4. The oscillation persisted from 255 all the way down (sd 40-70 to x ~ 100, 18 at 61, 11 at 20) and the rest afterwards cycles 350-460 (centre ~400, period 4.6 s), where 047 had the rest mode centred at 720. Regime 3's fixed point is not reachable by the path that found it before (041, 042). Rest centre so far: 480, 690, 495, 720, 720 (047 decayed), ~750 (049 start), 512 (050 start), ~400 (050 end). Next: 60 s idle to see whether the rest mode decays to 720 from ~400 as it did from ~720 in 047, then one more restoration attempt (fast up-ramp, the reverse of 043).

### 051 - steady in [700.0, 740.0] @0.5 -> 481 MISS [regime 4]

**why:** Run 51: no commands, 60 s, from a rest cycling around ~400 after 050. In 047 the rest mode decayed from a centre ~720 to 719 +/- 2 within 40 s. Is 720 the rest mode's fixed point (it decays there from 400 too), or does the centre stay where the last drive left it (~400)? Decides whether regime 4's rest has a level at all.

**cmds:** `(none)` for 60.0 s

**prediction:** the mode decays to a fixed point near 720 as in 047: steady (last 3 s) in [700, 740]; staying near 400 or anywhere else misses. 50/50

**observed:** start 520.5, final 467, steady 481, min 324, max 529, range 205, spread 56, period 6.808, t_settle None

**update:** MISS by 219 (steady 481): from a centre ~400 the rest does NOT decay to 720. It cycled 324-529 with period 6.8 s for the whole 60 s with no sign of decay, i.e. regime 2's rest state (019: 360-505, 7.66 s; 020: 7.58 s) reproduced. So regime 4 has two rest behaviours: a damped mode about 720 (047) and a sustained cycle about ~430 (051), and drives move the system between them. Ledger at 50: overall calibrated (-0.03); regime 3 63% hits at 0.58; regime 4 2/4; claims Brier 0.33. Model C updated in model.md. Next: last restoration attempt (fast up-ramp with z=1, the reverse of 043's path); if the rest still cycles afterwards I stop: the edge is found and nothing tried brings regime 3 back.

### 052 - spread in [20.0, 250.0] @0.65 -> 124 HIT [regime 4]

**why:** Run 52: z=1, ramp 0->255 over 8 s (the reverse of 043's 8 s down-ramp that caused the change), hold 4 s, step release, watch 30 s, from the regime-2-like rest cycle of 051. Last restoration attempt: waiting (047, 051), step drives (045, 048), and the slow down-ramp (050) have not brought back the smooth fixed point or a flat rest. If the rest still cycles after this, the change is permanent as far as I can tell and I stop.

**cmds:** `z 1 @1; ramp x=0..255 over=8 @1; x 0 @13; z 0 @13` for 43.0 s

**prediction:** no restoration: the rest keeps cycling after release, spread over the last 3 s in [20, 250]; a flat rest (< 10) would be the way back and would miss this

**observed:** start 529.0, final 444, steady 386, min 356, max 706, range 350, spread 124, period 7.251, t_settle None

**update:** HIT (spread 124): after the fast up-ramp and step release the rest cycles 356-530 with period 7.25 s, unchanged. Restoration attempts exhausted: waiting 120 s (047), waiting 60 s (051), 255 step from a quiet rest (048), slow down-ramp (050), fast up-ramp (052): none returns the smooth fixed point or a flat rest. The change caused by 043 is permanent within what I can do. Stopping here: the edge is found and named (see session-2.md).
