# boundaries.md — edges of the model

- **z is a switch between two branches, not a small effect (010; sure).** z=0: x barely moves y (≤2 units at 255). z=1: x above ~128 moves y by hundreds.
- **Oscillating regime in z=1 for x in [192, 248] (011–013, 016, 017; sure).** y swings 270–835, irregular, crossing period ~0.4–1.6 s with a slow envelope. Reproducible in kind, not in detail (range 416–563 at 192).
- **Smooth regime in z=1 for x in [254, 255] (010, 014, 015; sure).** Flat absolute level ~676. Boundary with the oscillating regime lies in (251, 254): a threshold in x, not a switching artefact (015 killed that). 251 is intermittent (018).
- **Onset transient at 254/255, z=1 is variable (010: min 628; 014: 382; 015: 384).** Not predictable; the settled level is.
- **Persistent rest level (007–017; sure).** Rest holds for minutes but is left at different values by different drives (710–717). First rest-level noise seen at 014 start (709/710).
- **Ripple depends on x non-monotonically** (002/005 vs 003): largest near 128, ~none at 255. Fairly sure.
- **Release from the oscillating regime does not return y to 715 (017→018; sure).** Unlike release from the smooth regime (010, 014 → 715).
- **Self-sustained oscillation at rest (018 opening, 019, 020; sure).** After run 017 was released to x=0, y never returned to a fixed rest level: at x=0 it oscillates 360–510 with period 7.6 s, regular, with no input, for the rest of the session (≥ 3 min across 018–020).
- **The driven response changed too (020; sure).** Under 255/z=1, which gave a flat 676 in 010/014/015, y wandered 370–667 irregularly. So this is not merely a second undriven attractor. **Unexplained persistent change across runs 018–020: session stopped here.**

## Regime 3 (session 2, after servicing)
- **Rest moved and stays moved: 735 at service (021), then wherever the last z=1 drive left it (710-732), flat for 30 s+ (026-034, 038; sure).**
- **z=1 step threshold between 160 (nothing, 030) and 192 (-7, 024); ramp threshold ~140 (035-038; fairly sure).**
- **Bistability at fixed x, z (036, 037; sure).** At x=255, z=1: a step from 0 gives a flat 667-673; a slow ramp gives a sustained oscillation (mean ~520, sd 40-60, 10.5-11 Hz lines, persists 32 s). Same inputs, two behaviours, selected by the path.
- **Onset bursts (031-034; sure they exist, unsure what selects them).** Steps to 255 fell smoothly in 023, 026, 027 and burst (0.3-1 s of chaotic scatter to 400-530) in every later onset. The settled level is unaffected.
- **Rest after release depends on drive duration (031-034; sure).** 0.5 s at 255 -> 732, 2 s -> 725.5, >= 8 s -> 721.5; time constant ~2 s. Not a single 'home'.
- **Rest after a long drive is non-monotonic in x (024-029, 038; fairly sure):** 715 / 712 / 710.5 / 714 / 721.5 at 192 / 200 / 224 / 240 / 255.
- **The regime-1 rule 'release returns to 715' is gone; the regime-2 rest oscillation has not returned (021-038), including after releases from the oscillating state at 200 and 255 (035, 038).**

## Regime 4 (after run 043)
- **A fast down-ramp (32 units/s) with z=1 from the smooth state at 255 changes the system (043; sure).** Step releases (035, 038, 040) and slow ramps (10 units/s: 041, 042) never did; regime 2 arose from a step release from oscillation at 248 in regime 1 (017).
- **The rest is a damped slow oscillation about ~720, not a fixed point (044, 046-049; sure).** Period 3.7-7 s, amplitude up to ~95, decays in ~35 s undisturbed (047), re-excited by every drive.
- **The smooth fixed point at 255/z=1 is unreachable by a step (045, 048; sure).** Steps to 192 and 255 both land in the oscillating state; z=0 at 255 oscillates too (046). The osc basin now covers every drive tried.
- **Caution for whoever drives this next:** the regime change was caused by a specific input path; the rest cycle's centre moved by hundreds between runs (043-046), so the first samples of a run are not a rest level.
