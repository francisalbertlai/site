# session-2.md - 32 runs (021-052), stopped by choice

Started from regime 3, declared by Albert after servicing (runs 001-020 are session 1: regime 1, then regime 2 after 017).
Stopped after run 052 because a real edge was reached and named: run 043 changed the system into a state (regime 4)
that no command I tried brings back, and the remaining questions are about a state that a service, not a command,
seems to reset. Model files: model.md (regimes 1-4), boundaries.md, analysis/model_b.py (trace generator).

## The model as it stands

### Regime 3 (021-042): model B, fitted and tested on 22 runs, trace skill 0.7-0.8 on step drives
State: rest level R (holds indefinitely undriven) plus a discrete branch s in {smooth, osc}.
- z=0: y = R + F0(x), F0(255) = +0.8 by step (022), up to +5 under a ramp (039); R rises by ~4 per 20 s of z=0 drive.
- z=1, x < 140: nothing (030, ramps 035-038).
- z=1, step to x >= 192, smooth branch: y -> L(x) = 715 - 0.0118 (x-192)^2 with delay 0.12 s and time constant 0.15 s;
  L(255) = 669 +/- 2 (seven runs), absolute, flat for 30 s+. Onset either smooth (023, 026, 027) or a 0.3-1 s chaotic
  burst (every later onset); the settled level is the same.
- z=1, slow ramp crossing x ~ 140: oscillating branch, mean 610 (x 160-200) to 520 (255), sd 40-100, 10.5-11 Hz lines over
  a 0.25 Hz envelope, stable for 32 s at 255 (037). A step 0 -> 255 inside a run selects smooth again (036): bistable at
  fixed (x, z), the path selects.
- Descending path from 255 (smooth): y stays at 667 down to x ~ 184, then rises along 667 + 40/(1 + exp((x-101)/24)) to
  707 at x = 0 (041). From the osc branch, a slow down-ramp collapses into a smooth 681 at x ~ 225 and then follows the
  same curve below x ~ 120 (042). The smooth branch has hysteresis; the osc branch has none.
- Rest after a drive: R = B + kicks. B = 706.5 +/- 1 (slow releases 041, 042). A step release from 255 adds ~+14
  (721.5 +/- 1.5, six runs); the onset adds ~+11 that decays with tau_s = 2.0 +/- 0.7 s while driven (0.5 s drive -> 732,
  2 s -> 725.5, >= 8 s -> 721.5). After long drives at 192/200/224/240: 715/712/710.5/714 (non-monotonic, unexplained).
Measured: everything above except tau_s's uncertainty (one run) and U(x) away from 255 (a guess). Not modelled: what
selects burst vs smooth onset; the sd of the oscillation.

### Regime 4 (043-052): model C, six runs, no predictive equation yet
- Rest self-oscillates: a damped mode about 720 (decays in ~35 s; 047) or a sustained cycle 356-530 with period 4.6-7.3 s
  (050-052), regime 2's state. Drives move the system between them; the cycle's centre moved by hundreds between runs.
- Every drive tried oscillates: 255/z=1 (045, 048: 10 Hz state, mean 626-660), 192/z=1 (049: full oscillation, as in
  regime 1), 255/z=0 (046: 260-850). The smooth fixed point has not been seen since 043.
- Restoration attempts, all failed: wait 120 s (047), wait 60 s (051), step 255 from a quiet rest (048), slow down-ramp
  (050), fast up-ramp (052).

## What surprised me, in order
1. **The oscillation was not gone, only hidden (035).** Twelve runs of smooth step responses, then a slow ramp found the
   regime-1 oscillation at x ~ 140 and it persisted to 255. Same inputs, two attractors; the path selects.
2. **The rest level is made of kicks (031-034, 041).** A 0.5 s pulse leaves R at 732, a long drive 721.5, a slow release 707.
   Fast edges push R up; the effect decays only while driven.
3. **Descending hysteresis (040, 041).** At x = 150 on the way down y sat at 678; a step to 160 from rest does nothing.
4. **A fast down-ramp changed the system (043).** 32 units/s through the oscillating region, with z = 1, and the fixed
   point at rest was gone. Step and slow-ramp releases never did this. Regime 2 in session 1 came from a step release
   from oscillation at 248, so the trigger is not one path but a family; the safe paths (step from 0, slow ramp down)
   are what I can name.
5. **The rest cycle damps or sustains depending on where it is (047 vs 051).** About 720 it decays in ~35 s; about 430 it
   runs for a minute with no decay.

## Scorecard (py -3 play.py ledger, after run 052)
```
runs: 52 | this session: 32 of ceiling 100 | regime 4
trace predictions: 18 | mean skill 0.26 | best 0.81 | worst -0.55  (1 = perfect, 0 = 'nothing happens')
regimes declared: 3 (each is a claim that the system changed; the record above is the overall one)
  regime 1: 14 metric predictions, hits 6 (43%), mean stated confidence 0.56 (-0.13)
  regime 3: 19 metric predictions, hits 12 (63%), mean stated confidence 0.58 (+0.06)
  regime 4: 6 metric predictions, hits 3 (50%), mean stated confidence 0.57 (-0.07)
metric predictions: 39 | hits 21 (54%) | mean stated confidence 0.57 | calibrated so far (-0.03)
  by stated confidence: <=0.50: 3/14 hit | 0.50-0.70: 16/23 hit | 0.70-0.90: 2/2 hit
  by metric (hits/n, mean interval width -- narrow and right is the goal): final 7/9, w=13.3 | max 1/1, w=7.0 | min 0/1, w=16.0 | period 0/2, w=3.2 | range 2/6, w=158.8 | spread 5/10, w=210.1 | start 1/2, w=10.5 | steady 5/8, w=22.6
  mean |observed - interval midpoint|: 90.3
claims judged: 13 | Brier 0.333 (0 = perfect, 0.25 = coin-flip) | mean confidence 0.53 | realised yes-rate 0.38
```
Reading it: calibrated overall (-0.03), regime 3 slightly underconfident (+0.06) at 63 % hits with 'final' intervals of
width 13 hitting 7/9: that is the model working. The misses in regime 3 were structural surprises (035 ramp, 024 no
oscillation, 043) plus three 1-2 unit edge misses from intervals I set too tight (031, 032, 039). Regime 4 predictions
were 50/50 bets on a system I had six runs on. Claims are at coin-flip (Brier 0.33): most were genuine structural
questions where I gave 0.5-0.6 and was wrong half the time (042, 043, 045, 048); the questions were right, the priors
were not. Trace skill: 0.7-0.8 when the model's structure held (028, 029, 033, 037), near zero or negative when a state
change happened mid-run; the mean of 0.26 is honest.

## Why I stopped
The stopping rule I can meet: a real edge has been reached and I can say what it is. Regime 4 was entered by a nameable
input (043) and has no exit I could find in five attempts of different kinds. Continuing would characterise regime 4's
oscillations further, but the highest-value question, whether there is a way back, has been answered "not by any of
these", and each extra drive re-excites the rest cycle. Note for Albert: regime 4 looks like regime 2 (session 1), which
the service cleared; the trigger this time was a fast down-ramp with z = 1 (in session 1 a step release from
oscillation), so if the system matters, avoid releases from the oscillating state that pass through the mid-x region
quickly. A regime was declared after 045; 047 briefly suggested it was only an excited transient (rest decayed to 720),
but 048-052 showed the driven response and the sustained rest cycle are changed, so the declaration stands.

## The three runs I would do next
1. **If serviced again: repeat 035 exactly** (ramp to 255 over 25 s, hold, step release). Model B predicts oscillation from
   x ~ 140, mean 520 at 255, release to 719-722. If it hits, the post-service system is reproducible and model B is
   the model; then map U(x) with 0.5 s pulses at 224 and 192 (predict 721 and 725.5 if U = TL + 10.5).
2. **If not serviced: 0.5 s pulses at 255 with 10 s gaps, six of them, from the sustained rest cycle.** Kicks raised R in
   regime 3; do they raise the cycle's centre toward the damped 720 mode? Predict centre rises by > 100 (0.4).
3. **Regime 4 basic probe at x = 100, z = 1, 15 s.** Below every threshold seen; does the rest cycle even notice?
   Predict driven sd < 15 and the cycle continues (0.5).
