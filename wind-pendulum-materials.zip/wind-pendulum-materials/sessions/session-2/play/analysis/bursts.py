"""Per-drive-segment stats for a run: for each x>0 segment print t-range, x, mean/sd/min/max of y,
y at the moment of release, and the rest reached 1 s after release. Usage: py -3 runs/play/analysis/bursts.py 032 [033 ...]"""
import sys, os
import numpy as np
base = os.path.join(os.path.dirname(__file__), '..')
for rid in sys.argv[1:]:
    d = np.genfromtxt(os.path.join(base, f'{rid}.csv'), delimiter=',', names=True)
    t, x, z, y = d['t'], d['x'], d['z'], d['y']
    on = np.flatnonzero(np.diff((x > 0).astype(int)) == 1) + 1
    off = np.flatnonzero(np.diff((x > 0).astype(int)) == -1) + 1
    print(f'=== run {rid}')
    print(f"{'t_on':>6} {'t_off':>6} {'x':>4} {'z':>1} {'mean':>7} {'sd':>6} {'min':>5} {'max':>5} {'y_rel':>5} {'rest+1s':>7} {'rest+3s':>7}")
    for a in on:
        b = off[off > a][0] if (off > a).any() else len(t) - 1
        seg = y[a:b]
        r1 = y[(t >= t[b] + 1.0) & (t < t[b] + 1.5)]
        r3 = y[(t >= t[b] + 3.0) & (t < t[b] + 3.5)]
        print(f'{t[a]:6.2f} {t[b]:6.2f} {x[a]:4.0f} {z[a]:1.0f} {seg.mean():7.1f} {seg.std():6.1f} {seg.min():5.0f} {seg.max():5.0f} {y[b]:5.0f} '
              f'{(np.median(r1) if len(r1) else np.nan):7.1f} {(np.median(r3) if len(r3) else np.nan):7.1f}')
