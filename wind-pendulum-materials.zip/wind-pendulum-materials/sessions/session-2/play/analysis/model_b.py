"""Model B v5 (regime 3) trace generator. Usage:
  py -3 runs/play/analysis/model_b.py <out.csv> <R0> <duration> "<cmds>"
Writes t,y at 50 Hz to runs/play/analysis/<out.csv>. Reads nothing but its arguments.
Model:
  rest: y = R (holds indefinitely when undriven).
  z=0, x>0: y = R + 0.8 x/255 (R unchanged).
  z=1, x>=X0: y -> L(x) = L0 - GC (x-X0)^2 (absolute, R-independent), lag TAU after delay D.
  z=1, x<X0: no effect (tested 128, 160).
  release from a z=1 drive at x lasting d: R := T(x,d) = U(x) - (U(x)-TL(x)) (1-exp(-(d-0.3)/TAU_S)); y -> R.
  State s in {smooth, osc}: a slow ramp (x steps < RAMP_STEP) crossing X_OSC while z=1 enters osc; y then sits at
  Y_OSC (mean of the oscillation, sd ~60 unmodelled) until x returns to 0 (release -> T as usual) or a step
  from 0 to >= X0 (assumed to select smooth). Onset bursts (chaotic 0.3-1 s transients at 255) are NOT modelled."""
import sys, os, math
import numpy as np
D, TAU = 0.12, 0.15
X0, L0, GC = 192, 715.0, 0.0118
TL = {192: 715, 224: 710.5, 240: 714, 255: 721.5}     # rest after a long (>=8 s) drive at x (measured)
UX = {255: 732}                                        # rest after a brief (0.5 s) drive (measured at 255 only)
TAU_S = 2.0                                            # slow downward effect on R (fitted on 034)
X_OSC, RAMP_STEP = 140, 20                             # osc state: threshold under a ramp (035)
def Y_OSC(x): return 610 - 90 * max(min((x - 160) / 95.0, 1.0), 0.0)   # osc mean: ~610 at 160-200 (038), ~520 at 255 (037)
def L(x, R):
    if x < X0: return R
    return L0 - GC * (x - X0) ** 2
B_REST, KICK_REL, X_SLOW = 707.0, 14.0, 30            # rest baseline; +kick for a step release; releases from x < X_SLOW get no kick (041)
def L_eng(x):                                          # engaged smooth level on a descending path (041)
    return 667.0 + 40.0 / (1.0 + math.exp((x - 101.0) / 24.0))
def TLx(x, R):
    if x < X0: return R
    ks = sorted(TL); return float(np.interp(x, ks, [TL[k] for k in ks]))
def T(x, R, d):
    if x < X0: return R
    tl = TLx(x, R); u = UX.get(x, tl + 10.5)           # guess: U(x) - TL(x) = 10.5 everywhere
    return u - (u - tl) * (1 - math.exp(-max(d - 0.3, 0.0) / TAU_S))
def parse(cmds):
    ev = []
    for c in [s.strip() for s in cmds.split(';') if s.strip()]:
        p = c.split(); at = float([q for q in p if q.startswith('@')][0][1:])
        if p[0] == 'x': ev.append((at, 'x', int(p[1])))
        elif p[0] == 'z': ev.append((at, 'z', int(p[1])))
        elif p[0] == 'pulse':
            kv = dict(q.split('=') for q in p[1:] if '=' in q)
            v, on, off, n = int(kv['x']), float(kv['on']), float(kv['off']), int(kv['n'])
            for k in range(n):
                ev.append((at + k*(on+off), 'x', v)); ev.append((at + k*(on+off) + on, 'x', 0))
        elif p[0] == 'ramp':
            kv = dict(q.split('=') for q in p[1:] if '=' in q)
            v0, v1 = [int(s) for s in kv['x'].split('..')]; over = float(kv['over'])
            for k in range(int(over*10) + 1):
                ev.append((at + k/10.0, 'x', int(round(v0 + (v1 - v0) * k / (over*10)))))
    return sorted(ev)
def simulate(R0, dur, cmds, dt=0.02):
    ev = parse(cmds); ev.append((dur, 'x', 0))
    t = np.arange(0, dur, dt); y = np.zeros_like(t)
    x = z = 0; R = R0; yv = R0; target = R0; t_on = None; x_max = 0; osc = False
    pend = []; j = 0
    for i, ti in enumerate(t):
        while j < len(ev) and ev[j][0] <= ti:
            _, k, v = ev[j]; j += 1
            if k == 'z':
                z = v
                if z == 1 and x >= X0: t_on = ti; x_max = x; pend.append((ti + D, L(x, R)))
                if z == 0 and x > 0: pend.append((ti + D, R + 0.8 * x / 255.0))
            else:
                if z == 1 and v >= X_OSC and x < X_OSC and 0 < v - x < RAMP_STEP: osc = True
                if z == 1 and v >= X0 and x == 0: osc = False
                if z == 1 and osc and v > 0:
                    if t_on is None: t_on = ti
                    x_max = max(x_max, v); pend.append((ti + D, Y_OSC(v)))
                elif z == 1 and v >= X0:
                    if t_on is None: t_on = ti
                    x_max = max(x_max, v); pend.append((ti + D, L(v, R)))
                elif z == 1 and 0 < v < X0 and x_max >= 250:   # engaged, descending: hysteresis curve (041)
                    pend.append((ti + D, L_eng(v)))
                elif z == 1 and v == 0 and (x >= X0 or osc or x_max >= 250):
                    if x < X_SLOW and not osc: R = B_REST                       # slow release: no kick (041)
                    else: R = T(max(x_max, X0), R, ti - t_on)
                    osc = False; t_on = None; x_max = 0; pend.append((ti + D, R))
                elif z == 0: pend.append((ti + D, R + 0.8 * v / 255.0))
                x = v
        while pend and pend[0][0] <= ti: target = pend.pop(0)[1]
        yv += (target - yv) * (dt / TAU)
        y[i] = yv
    return t, y
if __name__ == '__main__':
    out, R0, dur, cmds = sys.argv[1], float(sys.argv[2]), float(sys.argv[3]), sys.argv[4]
    t, y = simulate(R0, dur, cmds)
    p = os.path.join(os.path.dirname(__file__), out)
    with open(p, 'w') as f:
        f.write('t,y\n')
        for a, b in zip(t, y): f.write(f'{a:.2f},{b:.1f}\n')
    print('wrote', p, 'final', round(y[-1], 1), 'min', round(y.min(), 1))
