# model.md — current model of the system

## Regime 4 (runs 046-052; declared by me after 045; caused by run 043) - CURRENT

### What happened
043: z=1, step to 255 (smooth 669), then a ramp 255 -> 0 over 8 s (32 units/s). On the way down y broke into oscillation
(x ~ 160-100), spiked to ~740 near x = 33, and after x = 0 never settled: a slow wander 450-510. Since then:
- **Rest** is a damped oscillation about ~720 rather than a fixed point: 588-782 at 4.7 s (044), 689-750 at 3.7 s (046 tail),
  658-778 at ~7 s (048 tail); it decays to 719 +/- 2 in ~35 s when left alone (047, 120 s) and is re-excited by any drive.
  Its centre has sat at ~480, ~690, ~495, ~720 in successive runs (043-046): it moves between runs by hundreds.
- **z=1, step to 255:** no smooth level. Oscillating state: mean 626-660, sd 20-67, 10 Hz lines with a 0.17 Hz envelope (045, 048).
- **z=1, step to 192:** full oscillation, mean ~530, sd 40-75, crossing period 0.9 s (049) - as regime 1, not regime 3.
- **z=0, x=255:** no longer inert: oscillation 260-850, sd 80-115, mean drifting up over 15 s (046).
- Regime 2 (018-020) had the same signature (rest cycle + lost smooth level) after a release from oscillation; its cycle was
  360-510 at 7.6 s and did not decay in 3 min. Regime 4's decays in ~35 s but comes back with every drive.

### Model C (regime 4), as far as it goes
- Rest: y = 720 + A(t) sin(2 pi t / P), P = 3.7-7 s (not constant), A decays with tau_A ~ 15 s from ~30-95 after a drive.
  Numbers: 720 +/- 3 (047), tau_A a guess from one decay.
- Any drive (either z, x >= 192) puts y in an oscillating state like regime 3's osc (10 Hz + slow envelope), mean 490-660
  depending on x (higher at 255), and re-excites the rest mode on release.
- Untested: x < 192 with z=1; small x with z=0; whether the rest mode's period depends on amplitude.

### Rest modes (047, 051, 052)
Two: a damped mode about 720 (amplitude ~30 -> 2 in ~35 s, 047) and a sustained cycle 324-530 about ~430 with period
4.6-7.3 s (050-052; regime 2's state, 019/020). From ~400 the rest does NOT decay to 720 (051). What selects them is
unknown; drives moved the system from the first to the second (048 -> 050).

### Restoration attempts (is there a way back to regime 3?) - all failed
- Waiting 120 s (047): rest decays to 720 but the next 255 step oscillates (048).
- Slow down-ramp 255 -> 0 (050): oscillation persists all the way down; rest cycles at ~400 afterwards.
- Waiting 60 s from ~400 (051): sustained cycle, no decay.
- Fast up-ramp 0 -> 255 then step release (052): rest cycles 356-530, period 7.25 s.
Conclusion: within the command language, regime 4 is permanent. Session 1's regime 2 was cleared by a service.

## Regime 3 (runs 021-042, session 2; declared by Albert after servicing) - the system as it was before run 043

### Structure (model B, v4; generator: analysis/model_b.py)
State: a rest level R (holds indefinitely undriven) and a discrete state s in {smooth, osc} that matters only while driven.

1. **Undriven:** y = R, noise 0-1 unit. R held for 20-34 s in every run (021, 026-034, 038); no relaxation seen.
2. **z=0, any x:** y = R + F0(x), F0(255) = +0.8 +/- 0.3 (022), +2 spike at an edge; R unchanged (022). Ramp under z=0: run 039.
3. **z=1, x < 140 (step or ramp):** no effect (030 at 160 by step; 035-038 ramps flat up to x ~ 135).
4. **z=1, step from x=0 to x >= 192, s = smooth:** y -> L(x) after a delay D = 0.12 s with time constant tau = 0.15 s,
   L(x) = 715 - 0.0118 (x - 192)^2   [fitted on 024, 025, 028, 029, 023/026/027/033/036; absolute, independent of R over R = 710-735]
   measured: L(192) = 715, L(224) = 703/695, L(240) = 688, L(255) = 667-673 (mean 669 +/- 2). Flat for >= 30 s (033).
   The onset is either a smooth fall (023, 026, 027) or a chaotic burst of 0.3-1 s (031-034: 12 of 12 later onsets) with
   minima 400-530: a transient visit to the osc state. Not predictable yet; the settled level is the same either way.
5. **z=1, slow ramp (<= 2 units per 0.1 s) crossing x ~ 140:** s -> osc: y oscillates; mean ~610 at x 160-200 falling to
   ~520 at 255; sd 40-100; range 320-850; spectral lines 10.5-11 Hz and 21 Hz over a 0.25 Hz envelope; crossing period
   ~1 s (035-038). Persists >= 32 s at x = 255 (037): a stable attractor. A step 0 -> 255 inside a run selects smooth
   again (036). Bistable at fixed (x, z).
6. **Release (x -> 0) after a z=1 drive of duration d at x (either s):** y -> R' in 0.3-0.45 s (S-shaped), with
   R' = T(x, d) = U(x) - (U(x) - TL(x)) (1 - exp(-(d - 0.3) / tau_s)),   tau_s = 2.0 +/- 0.7 s (034)
   TL(x) (long drive): 715 (192), 710.5 (224 x2), 714 (240), 712 (200 via ramp, 038), 721.5 +/- 1.5 (255 x6, both states).
   U(255) = 732 +/- 1 (031, 032); U at other x is a guess (TL + 10.5). TL is non-monotonic in x; unexplained.

### Parameters
| name | value | +/- | fitted on | tested on | residual |
|---|---|---|---|---|---|
| R at service | 735 | 0 | init, 021 | 022, 023 | 0 |
| F0(255) | +0.8 | 0.3 | 022 | - | - |
| L(255) | 669 | 2 | 023, 026, 027 | 033 (667), 036 (673) | <= 4 |
| L(x) curvature | 0.0118 | 0.002 | 224, 240, 255 | 028 (695 vs 703) | 8 |
| D, tau (onset/release) | 0.12 s, 0.15 s | 0.05 | 023-027 | traces 028-029 (skill 0.72-0.81) | - |
| TL(255) | 721.5 | 1.5 | 026, 027 | 023, 033, 035, 036 | <= 2.5 |
| U(255) | 732 | 1 | 031, 032 | - | - |
| tau_s | 2.0 s | 0.7 | 034 | - | - |
| osc mean at 255 | 520 | 40 | 037 | 035 (545) | 25 |
| osc mean at 160-200 | 610 | 40 | 038 | - | - |
| osc threshold under ramp | 140 | 10 | 035, 036 | 037, 038 | - |

### Trace scores so far (skill = 1 - RMS/RMS_lazy)
028 0.72, 029 0.81, 030 -0.05 (flat run, nothing to predict), 031 0.40, 032 0.20, 033 0.68, 034 0.25, 035 0.12 (osc unmodelled then),
036 0.43, 037 0.66, 038 0.29. Losses come from onset bursts and the oscillation's own sd (40-100), which the model carries as a mean.

### What model B predicts for untried commands
- z=0 ramp to 255: flat, R + <= 1 (0.65). If it oscillates, z is not a switch (run 039).
- Step to 176 with z=1: flat (0.6); the step branch starts between 160 and 192.
- Step down 255 -> 150 while smooth: y rises to ~R (0.5).
- Ramp to 255 then a 1 s dip to x=100 (not 0) and back: stays osc (0.5) - the reset may need x=0.

### Open questions (ranked by value)
1. What selects burst vs smooth onset, and osc vs smooth generally (where is the basin boundary in the path)?
2. Why is TL(x) non-monotonic (715, 712, 710.5, 714, 721.5)? What is U(x) away from 255?
3. Does z=0 ever oscillate (ramp, 039)?
4. Does the osc state's mean/period depend on x in a lawful way (fit across 035-038)?
5. Is there any way back to regime 1 or 2? Nothing tried so far restores either (035-038 releases all flat).

### What changed from regime 1 (model A -> model B)
Held: z=0 inert; z=1 threshold-like in x; a smooth level at 255 (676 -> 669); release in ~0.45 s; R persistent undriven;
the oscillation itself (range, irregularity, ~1 s crossing period) looks like regime 1's.
Moved: R 715 -> 735 (now wanders 710-732 with drive); a **step** to 192-251 lands smooth (was oscillating), the oscillation
needs a slow ramp; rest after drive is a duration-dependent T(x, d), not 'home 715'. Regime 2's 7.6 s rest oscillation has
not appeared (releases from osc at 200 and 255 both gave flat rests, 035, 038).

## Regime 1 and 2 record (runs 001-020, session 1) - the system as it was

### Structure
y depends on z as a switch between two very different branches, plus a persistent rest level R.
Time constants: fast (<= 0.6 s) for drive response; R holds for minutes.

### Branch z=0 (runs 002, 003, 006, 007) - nearly inert
y = R + F0(x) + ripple(x); F0(255) = +1.5 +/- 0.5 (003: +1, 007: +2); F0(128) = +0.3 +/- 0.2 (002, 005);
onset spike +3 for ~0.3 s at a 0->255 step (003, 006); ripple sd 0.6 at x=128 (lines 3.8/9.8/13.6 Hz), 0.25 at 255, 0 at rest.

### Branch z=1 - three regimes in x (runs 005, 010-018)
| x | regime | y while driven | evidence |
|---|---|---|---|
| 128 | flat | R (+ripple as z=0) | 005 |
| 192-248 | oscillating | irregular, mean 500-550 (240: 605), sd 85-110, excursions 270-835, crossing periods 0.35-1.6 s plus a slow envelope of 5-9 s | 011, 012, 013, 016, 017 |
| 251 | intermittent | mostly at ~681 with dips; mean 664, sd 46 | 018 |
| 254-255 | smooth | absolute level 676 +/- 4 (672, 676, 680) in ~0.6 s after a variable onset undershoot (min 382-628) | 010, 014, 015 |
Thresholds for z=1: flat->oscillating in (128, 192); oscillating->smooth in (251, 254).
Release from the smooth regime returned y to 715 in ~0.5 s (010, 014). Release from the oscillating regime did not (017->018).

### Rest level R (runs 001-017)
Held exactly for minutes undriven (009: 180 s). z=0 drives 715->716->717; 255/z=1 drives -> 715; oscillating drives -> 710-714.

### Regime 2 (018-020): after 017's release, y self-oscillated at rest, 360-510, period 7.6 s (019, 020), and 255/z=1 no
longer gave the smooth 676 (020). Session 1 stopped there. Albert serviced the system; regime 3 declared.

### Parameters (regime 1)
| name | value | uncertainty | fitted on | tested on | residual |
|---|---|---|---|---|---|
| R home | 715 | 0 | init, 001 | 010, 014, 015 returns | 0 |
| F0(255) | +1.5 | +/-0.5 | 003, 007 | 006 | <= 1 |
| F0(128) | +0.3 | +/-0.2 | 002, 005 | - | - |
| smooth level (z=1, x >= 254) | 676 | +/-4 | 010, 014 | 015 | +4 |
| settle time (smooth) | 0.6 s | +/-0.2 | 010, 014, 015 | - | - |
| oscillation mean (192-248) | 530 | +/-40 | 011-013, 017 | 016 (605: +75, near threshold) | - |
| oscillation range (12 s) | 416-563 | - | 011, 013 | 012 HIT | - |
| self-oscillation at rest (post-018) | 360-510, period 7.6 s | +/-0.1 s | 019 | 020 (7.58 s) | 0.08 s |
